window.config = {
  servers: {
    // 本地环境地址
    // default: 'http://47.107.235.17:1000/QCCVAS-BIZ-GOODS',
    // user: 'http://47.107.235.17:1000/QCCVAS-BIZ-USER',
    // base: 'http://47.107.235.17:1000/QCCVAS-BIZ-BASE',
    // code: 'http://47.107.235.17:1000/QCCVAS-BIZ-CODE',
    // order: 'http://47.107.235.17:1000/QCCVAS-BIZ-ORDER'
    // 本地环境地址
    default: 'QCCVAS-BIZ-GOODS',
    user: 'QCCVAS-BIZ-USER',
    base: 'QCCVAS-BIZ-BASE',
    code: 'QCCVAS-BIZ-CODE',
    order: 'QCCVAS-BIZ-ORDER',
    statistics: 'QCCVAS-BIZ-STATISTICS'
    // 开发环境地址
    // default: 'http://apiui.qccvas.com/gateway-nginx/QCCVAS-BIZ-GOODS',
    // user: 'http://apiui.qccvas.com/gateway-nginx/QCCVAS-BIZ-USER',
    // base: 'http://apiui.qccvas.com/gateway-nginx/QCCVAS-BIZ-BASE',
    // code: 'http://apiui.qccvas.com/gateway-nginx/QCCVAS-BIZ-CODE',
    // order: 'http://apiui.qccvas.com/gateway-nginx/QCCVAS-BIZ-ORDER'
  },
  forApp: true, // 发包改成true
  userInfo: {
    serverUrl: 'http://47.112.98.170:1000/',
    tenantId: 'leebong',
    userName: 'leebong',
    password: '123456'
  }
}
