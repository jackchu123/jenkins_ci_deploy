webpackJsonp([14],{

/***/ "0iPh":
/***/ (function(module, exports) {

module.exports = $;

/***/ }),

/***/ "0xDb":
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _index = __webpack_require__("jFiy");

var _index2 = _interopRequireDefault(_index);

var _index3 = __webpack_require__("ySQA");

var _index4 = _interopRequireDefault(_index3);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = {
  common: _index2.default,
  business: _index4.default
};

/***/ }),

/***/ "2/a5":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
Object.defineProperty(__webpack_exports__, "__esModule", { value: true });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__babel_loader_node_modules_vue_loader_lib_selector_type_script_index_0_scanCodeIn_vue__ = __webpack_require__("di9n");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__babel_loader_node_modules_vue_loader_lib_selector_type_script_index_0_scanCodeIn_vue___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0__babel_loader_node_modules_vue_loader_lib_selector_type_script_index_0_scanCodeIn_vue__);
/* harmony namespace reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in __WEBPACK_IMPORTED_MODULE_0__babel_loader_node_modules_vue_loader_lib_selector_type_script_index_0_scanCodeIn_vue__) if(__WEBPACK_IMPORT_KEY__ !== 'default') (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return __WEBPACK_IMPORTED_MODULE_0__babel_loader_node_modules_vue_loader_lib_selector_type_script_index_0_scanCodeIn_vue__[key]; }) }(__WEBPACK_IMPORT_KEY__));
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__node_modules_vue_loader_lib_template_compiler_index_id_data_v_59bfb43e_hasScoped_true_transformToRequire_video_src_poster_source_src_img_src_image_xlink_href_buble_transforms_node_modules_vue_loader_lib_selector_type_template_index_0_scanCodeIn_vue__ = __webpack_require__("SEaI");
function injectStyle (ssrContext) {
  __webpack_require__("i2KX")
}
var normalizeComponent = __webpack_require__("VU/8")
/* script */


/* template */

/* template functional */
var __vue_template_functional__ = false
/* styles */
var __vue_styles__ = injectStyle
/* scopeId */
var __vue_scopeId__ = "data-v-59bfb43e"
/* moduleIdentifier (server only) */
var __vue_module_identifier__ = null
var Component = normalizeComponent(
  __WEBPACK_IMPORTED_MODULE_0__babel_loader_node_modules_vue_loader_lib_selector_type_script_index_0_scanCodeIn_vue___default.a,
  __WEBPACK_IMPORTED_MODULE_1__node_modules_vue_loader_lib_template_compiler_index_id_data_v_59bfb43e_hasScoped_true_transformToRequire_video_src_poster_source_src_img_src_image_xlink_href_buble_transforms_node_modules_vue_loader_lib_selector_type_template_index_0_scanCodeIn_vue__["a" /* default */],
  __vue_template_functional__,
  __vue_styles__,
  __vue_scopeId__,
  __vue_module_identifier__
)

/* harmony default export */ __webpack_exports__["default"] = (Component.exports);


/***/ }),

/***/ "2/kW":
/***/ (function(module, exports) {

// removed by extract-text-webpack-plugin

/***/ }),

/***/ "2GmJ":
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var MAX_FONT_SIZE = 42;

document.addEventListener('DOMContentLoaded', function () {
  var html = document.querySelector('html');
  var fontSize = window.innerWidth / 10;
  fontSize = fontSize > MAX_FONT_SIZE ? MAX_FONT_SIZE : fontSize;
  html.style.fontSize = fontSize + 'px';
});

/***/ }),

/***/ "2wmj":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
Object.defineProperty(__webpack_exports__, "__esModule", { value: true });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__babel_loader_node_modules_vue_loader_lib_selector_type_script_index_0_scanCode_vue__ = __webpack_require__("5Fcw");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__babel_loader_node_modules_vue_loader_lib_selector_type_script_index_0_scanCode_vue___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0__babel_loader_node_modules_vue_loader_lib_selector_type_script_index_0_scanCode_vue__);
/* harmony namespace reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in __WEBPACK_IMPORTED_MODULE_0__babel_loader_node_modules_vue_loader_lib_selector_type_script_index_0_scanCode_vue__) if(__WEBPACK_IMPORT_KEY__ !== 'default') (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return __WEBPACK_IMPORTED_MODULE_0__babel_loader_node_modules_vue_loader_lib_selector_type_script_index_0_scanCode_vue__[key]; }) }(__WEBPACK_IMPORT_KEY__));
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__node_modules_vue_loader_lib_template_compiler_index_id_data_v_d388e56c_hasScoped_true_transformToRequire_video_src_poster_source_src_img_src_image_xlink_href_buble_transforms_node_modules_vue_loader_lib_selector_type_template_index_0_scanCode_vue__ = __webpack_require__("FCDO");
function injectStyle (ssrContext) {
  __webpack_require__("PXRN")
}
var normalizeComponent = __webpack_require__("VU/8")
/* script */


/* template */

/* template functional */
var __vue_template_functional__ = false
/* styles */
var __vue_styles__ = injectStyle
/* scopeId */
var __vue_scopeId__ = "data-v-d388e56c"
/* moduleIdentifier (server only) */
var __vue_module_identifier__ = null
var Component = normalizeComponent(
  __WEBPACK_IMPORTED_MODULE_0__babel_loader_node_modules_vue_loader_lib_selector_type_script_index_0_scanCode_vue___default.a,
  __WEBPACK_IMPORTED_MODULE_1__node_modules_vue_loader_lib_template_compiler_index_id_data_v_d388e56c_hasScoped_true_transformToRequire_video_src_poster_source_src_img_src_image_xlink_href_buble_transforms_node_modules_vue_loader_lib_selector_type_template_index_0_scanCode_vue__["a" /* default */],
  __vue_template_functional__,
  __vue_styles__,
  __vue_scopeId__,
  __vue_module_identifier__
)

/* harmony default export */ __webpack_exports__["default"] = (Component.exports);


/***/ }),

/***/ "3pX5":
/***/ (function(module, exports, __webpack_require__) {

"use strict";


module.exports = {
  Base: {
    // 临时登录方法
    tempLogin: {
      path: '/login/app',
      method: 'POST',
      server: 'user'
    },
    // 获取数据字典
    getDictionary: {
      path: '',
      method: 'POST',
      server: ''
    }
  }
};

/***/ }),

/***/ "4D68":
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = {
  /**
     * @func
     * @desc 用于将后台返回的字段类型转化为 string, int, double, date
     * @param {String} coType - 必选，后台返回的字段类型
     * @returns {String} 返回转化后的字段类型
     */
  changeCoType: function changeCoType(coType) {
    var returnStr = '';
    if (coType !== null && coType !== '') {
      var tCoType = coType.toUpperCase();
      if (tCoType === 'VARCHAR' || tCoType === 'VARCHAR2' || tCoType === 'CHAR' || tCoType.indexOf('VARCHAR') > -1 || tCoType.indexOf('LOB') > -1) {
        returnStr = 'string';
      }
      if (tCoType === 'LONG' || tCoType === 'NUMBER' || tCoType === 'DECIMAL' || tCoType === 'INTEGER') {
        returnStr = 'int';
      }
      if (tCoType.indexOf('NUMBER') > -1 && tCoType === 'NUMBER' || tCoType.indexOf('DECIMAL') > -1 && tCoType === 'DECIMAL' || tCoType === 'FLOAT') {
        returnStr = 'double';
      }
      if (tCoType.indexOf('DATE') > -1 || tCoType.indexOf('TIME') > -1) {
        returnStr = 'date';
      }
      if (coType === null || coType === '') {
        return coType;
      }
    }
    return returnStr;
  }
};

/***/ }),

/***/ "4J5h":
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _vue = __webpack_require__("lRwf");

var _vue2 = _interopRequireDefault(_vue);

var _vueRouter = __webpack_require__("pRNm");

var _vueRouter2 = _interopRequireDefault(_vueRouter);

var _scanCodeIn = __webpack_require__("2/a5");

var _scanCodeIn2 = _interopRequireDefault(_scanCodeIn);

var _scanCode = __webpack_require__("2wmj");

var _scanCode2 = _interopRequireDefault(_scanCode);

var _scanCodeRecord = __webpack_require__("dHgB");

var _scanCodeRecord2 = _interopRequireDefault(_scanCodeRecord);

var _selectOrgan = __webpack_require__("77y4");

var _selectOrgan2 = _interopRequireDefault(_selectOrgan);

var _PageTransition = __webpack_require__("XHtf");

var _PageTransition2 = _interopRequireDefault(_PageTransition);

var _utils = __webpack_require__("0xDb");

var _utils2 = _interopRequireDefault(_utils);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

_vueRouter2.default.prototype.goBack = function (route) {
  this.isBack = true;
  if (route.path === '/') return _utils2.default.business.AppUtils.existApplet();
  window.history.go(-1);
};

_vue2.default.use(_vueRouter2.default);
var routes = [{
  path: '/',
  name: 'pageTransition',
  component: _PageTransition2.default,
  children: [{
    path: '/',
    component: _scanCodeIn2.default,
    name: 'scanCodeIn',
    meta: {
      title: '整件入库',
      showHeader: true
    }
  }, {
    path: '/selectOrgan',
    component: _selectOrgan2.default,
    name: 'selectOrgan',
    meta: {
      title: '选择组织 ',
      showHeader: true
    }
  }, {
    path: '/scanCode',
    component: _scanCode2.default,
    name: 'scanCode',
    meta: {
      title: '扫码列表',
      showHeader: false
    }
  }, {
    path: '/scanCodeRecord',
    component: _scanCodeRecord2.default,
    name: 'scanCodeRecord',
    meta: {
      title: '扫码记录',
      showHeader: true
    }
  }]
}];

// 定义路由实例
var router = new _vueRouter2.default({
  // mode: 'history',
  routes: routes
});

/**
 * 处理路由配置项
 * @param {} conf 配置项
 */
// function handleRouterConfig (conf) {
//   let path = '/' + conf.path
//   let name = conf.path.replace(new RegExp('\\/', 'g'), '_')
//   let component = resolve => require(['../views/' + conf.component], resolve)
//
//   let route = { path, name, component }
//
//   if (conf.children && conf.children instanceof Array) {
//     route.children = []
//     for (let child of conf.children) {
//       let childRoute = handleRouterConfig(child)
//       if (typeof childRoute !== 'undefined') {
//         route.children.push(childRoute)
//       }
//     }
//   }
//   return route
// }

exports.default = router;

/***/ }),

/***/ "4ml/":
/***/ (function(module, exports) {

// removed by extract-text-webpack-plugin

/***/ }),

/***/ "5Fcw":
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _stringify = __webpack_require__("mvHQ");

var _stringify2 = _interopRequireDefault(_stringify);

var _extends2 = __webpack_require__("Dd8w");

var _extends3 = _interopRequireDefault(_extends2);

var _vant = __webpack_require__("Fd2+");

var _vuex = __webpack_require__("SJI6");

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

exports.default = {
  name: 'scanRecord',
  computed: (0, _extends3.default)({}, (0, _vuex.mapGetters)({
    outOrganInfo: 'global.outOrganInfo',
    inOrganInfo: 'global.inOrganInfo',
    outWareHouseInfo: 'global.outWareHouseInfo',
    inWareHouseInfo: 'global.inWareHouseInfo',
    isInitScanView: 'global.isInitScanView',
    user: 'global.user'
  })),
  data: function data() {
    return {
      scannedInfo: {
        vid: '',
        cid: '',
        code: '',
        codeType: 1
      },
      scanRecordList: [],
      positionInfo: this.$util.business.LocalUtils.getPositionInfo(), // 位置信息
      systemInfo: this.$util.business.LocalUtils.getSystemInfo(),
      scanViewParam: {
        mode: 'QR',
        height: 30,
        message: '',
        isPullable: true,
        header: '',
        fixed: true
      },
      total: 0
    };
  },
  activated: function activated() {
    var _this = this;

    /* for (let i = 0; i < 10; i++) {
      this.scanRecordList.push({code: i})
    } */
    this.registerHandler();
    // 回到页面打开摄像头
    if (!this.isInitScanView) {
      this.$util.business.AppUtils.showScanView(true, function () {
        _this.$util.business.AppUtils.changeScanView(_this.scanViewParam.height, _this.scanViewParam.message, _this.scanViewParam.isPullable, _this.scanViewParam.header, _this.scanViewParam.fixed, function (result) {});
      });
    }
  },
  deactivated: function deactivated() {
    // 离开页面关闭摄像头
    this.$util.business.AppUtils.showScanView(false, function (result) {});
    this.$util.business.AppUtils.syncScanResult();
  },
  created: function created() {
    var _this2 = this;

    this.scanViewParam.header = this.$route.meta.title; // 将header传给原生设备
    // 初始化摄像头
    if (this.isInitScanView) {
      this.$util.business.AppUtils.initScanView(this.scanViewParam.mode, this.scanViewParam.height, this.scanViewParam.message, this.scanViewParam.isPullable, this.scanViewParam.header, this.scanViewParam.fixed, function (result) {
        if (result) _this2.$store.commit('global.changeIsInitScanView', false);
      });
    }
  },

  methods: {
    // 注册native调用的js方法
    registerHandler: function registerHandler() {
      var _this3 = this;

      this.$util.business.AppUtils.syncScanResult(function (data, cb) {
        _this3.scannedInfo = data;
        _this3.codeScan();
      });
    },
    codeScan: function codeScan() {
      var _this4 = this;

      var scanParam = {
        lon: this.positionInfo.longitude || '',
        lat: this.positionInfo.latitude || '',
        address: this.positionInfo.addr || '',
        deviceType: this.systemInfo.model || '',
        imei: this.systemInfo.imei,
        /* inOrgId: this.outOrganInfo.id,
        inOrgName: this.outOrganInfo.name,
        outWarehouseId: this.outWareHouseInfo.id,
        outWarehouseName: this.outWareHouseInfo.warehouseName, */
        inWarehouseId: this.inWareHouseInfo.id,
        inWarehouseName: this.inWareHouseInfo.warehouseName
      };
      scanParam.codeList = [];
      var code = {};
      code.vid = this.scannedInfo.vid;
      code.cid = this.scannedInfo.cid;
      code.code = this.scannedInfo.code;
      code.codeType = this.scannedInfo.codeType;
      scanParam.codeList.push(code);
      var httpTimeStart = new Date().getTime();
      this.$backend.request(this.$api.scanCodeIn.scanIn, scanParam).then(function (res) {
        var httpTimeEnd = new Date().getTime();
        _this4.$store.commit('global.changeScanFlag', false);
        if (res.success) {
          _this4.total += 1;
          res.data.successFlag = 0;
          _this4.$util.business.AppUtils.voiceAlert('WarehousingSuccessful');
          /* this.getScanRecordList() */
        } else {
          if (res.data !== undefined) res.data.successFlag = 1;
          _this4.$util.business.AppUtils.voiceAlert('WarehousingFail');
          if (window.config.forApp) {
            _this4.$util.business.AppUtils.openMessageBox('提示', '', res.message, '', '确定', false, function (result) {});
          } else {
            (0, _vant.Toast)(res.message);
          }
        }
        if (res.data !== undefined) {
          res.data.time = httpTimeEnd - httpTimeStart;
          _this4.scanRecordList.unshift(JSON.parse((0, _stringify2.default)(res.data)));
        }
      });
    }
  }
};

/***/ }),

/***/ "5pKY":
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _promise = __webpack_require__("//Fk");

var _promise2 = _interopRequireDefault(_promise);

var _typeof2 = __webpack_require__("pFYg");

var _typeof3 = _interopRequireDefault(_typeof2);

var _stringify = __webpack_require__("mvHQ");

var _stringify2 = _interopRequireDefault(_stringify);

var _vue = __webpack_require__("lRwf");

var _vue2 = _interopRequireDefault(_vue);

var _vueResource = __webpack_require__("f/Qh");

var _vueResource2 = _interopRequireDefault(_vueResource);

var _session = __webpack_require__("hDMw");

var _session2 = _interopRequireDefault(_session);

var _string = __webpack_require__("TDeA");

var _string2 = _interopRequireDefault(_string);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

// import userInfo from '../conf/basedata/userInfo'
// import local from '../utils/business/local'

/* import config from './../utils/config' */
_vue2.default.use(_vueResource2.default);

function getApiConf(value) {
  if (value) {
    if (typeof value === 'string') {
      return {
        path: value,
        method: 'GET'
      };
    } else {
      if (!value) {
        throw new Error('Api未配置' + (0, _stringify2.default)(value));
      }
      if ((typeof value === 'undefined' ? 'undefined' : (0, _typeof3.default)(value)) !== 'object') {
        throw new Error('Api配置错误' + (0, _stringify2.default)(value));
      }
      if (!value.method) {
        throw new Error('Api配置错误，缺少method属性' + (0, _stringify2.default)(value));
      }
      if (!value.path) {
        throw new Error('Api配置错误，缺少path属性' + (0, _stringify2.default)(value));
      }
      return {
        path: value.path,
        method: value.method.toUpperCase(),
        server: value.server
      };
    }
  }
  throw new Error('Api path is null');
}

function _getUrl(api) {
  if (false) {
    return api.path;
  } else {
    // 此处配置中转服务器
    var server = api.server || 'default';
    /* if (session.getLoginUser().serviceUrl && session.getLoginUser().serviceUrl !== '' && api.server === 'transfer') {
      return session.getLoginUser().serviceUrl + api.path
    } */
    var url = _session2.default.getLoginUser().serverUrl;
    if (url.slice(url.length - 1) === '/') {} else {
      url += '/';
    }
    return url + window.config.servers[server === 'transfer' ? 'default' : server] + api.path;
  }
}

function buildQuery(json) {
  if (!json) {
    return '';
  }
  if (_string2.default.isString(json)) return json;
  var query = '?';
  for (var i in json) {
    query += i + '=' + encodeURIComponent(json[i]) + '&';
  }
  if (query.charAt(query.length - 1) === '&') {
    query = query.substr(0, query.length - 1);
  }
  return query;
}

function _request(settings) {
  var api = settings.api;
  var data = settings.data;
  var options = settings.options || {};
  var query = settings.query;
  api = getApiConf(api);
  var url = _getUrl(api);
  if (settings.options !== undefined) {
    _vue2.default.http.options.emulateJSON = true;
  } else {
    _vue2.default.http.options.emulateJSON = false;
  }
  if (api.method === 'GET') {
    url += buildQuery(data);
    return _vue2.default.http.get(url, options);
  } else if (api.method === 'POST') {
    url += buildQuery(query);
    return _vue2.default.http.post(url, data, options);
  } else if (api.method === 'PUT') {
    url += buildQuery(query);
    return _vue2.default.http.put(url, data, options);
  } else if (api.method === 'DELETE') {
    url += buildQuery(data);
    return _vue2.default.http.delete(url, null, options);
  } else {
    throw new Error('Http method not support => ' + api.method);
  }
}

/**
 * 请求代理类
 */
exports.default = {
  /**
   * 获取url
   */
  getUrl: function getUrl(apiKey, data) {
    var api = getApiConf(apiKey);
    var url = _getUrl(api);
    if ((typeof data === 'undefined' ? 'undefined' : (0, _typeof3.default)(data)) === 'object') {
      url += buildQuery(data);
    }
    return url;
  },

  /**
   * 请求后端
   * @param apiKey 获取URL用，即定义在src/conf/api.js中的api的Key
   * @param data JSON数据
   * @param options ajax附件参数，主要是http header，用的比较少
   */
  request: function request(api, data, options, query) {
    var isShowLoad = arguments.length > 4 && arguments[4] !== undefined ? arguments[4] : true;

    return new _promise2.default(function (resolve, reject) {
      _request({
        api: api,
        data: data,
        options: options,
        query: query
      }).then(function (response) {
        resolve(response.data);
      }, function (response) {
        reject(response);
      });
    });
  },

  /**
      * @param {
     * api:''//piKey 获取URL用，即定义在src/conf/api.js中的api的Key
     *  data: JSNO对象，POST或者PUT到服务端的JOSON数据，如果是GET或者Delete则实际转换成url参数
     *  query: FormData
     * }
     */
  send: function send(settings) {
    var isShowLoading = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : true;

    return new _promise2.default(function (resolve, reject) {
      _request(settings).then(function (response) {
        resolve(response.data);
      }, function (response) {
        reject(response);
      });
    });
  },

  /**
   * 转换错误
   * @param {*} error
   */
  convertError: function convertError(error) {
    var ret = { code: -1 };
    var response = error.response;
    if (response) {
      ret.code = response.status;
      var url = response.config.url;
      if (response.status === 504) {
        ret.msg = '服务器网关超时，请联系管理员，请求：' + url;
      } else if (response.status === 404) {
        ret.msg = '服务未启动或未找到接口，请求：' + url;
      } else {
        ret.msg = '服务器繁忙，请稍后再试，请求：' + url;
      }
    } else {
      ret.msg = '无法连接服务器，请检查您的网络';
    }
    return ret;
  }
};

/***/ }),

/***/ "6zCF":
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.actions = exports.mutations = exports.getters = exports.state = undefined;

var _defineProperty2 = __webpack_require__("bOdI");

var _defineProperty3 = _interopRequireDefault(_defineProperty2);

var _getters, _mutations;

var _session = __webpack_require__("hDMw");

var _session2 = _interopRequireDefault(_session);

var _local = __webpack_require__("FITS");

var _local2 = _interopRequireDefault(_local);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var NS = 'global.';

var state = exports.state = {
  global: {
    user: null,
    userid: '',
    isLoading: false,
    isPDA: true,
    scanMode: 'QCC',
    isInitScanView: true, // 判断是否第一次加载扫码框
    scanViewStatus: true, // 扫码框状态
    scanFlag: false, // true为扫码未处理完成
    timeVisible: false,
    outOrganInfo: {}, // 发货组织
    inOrganInfo: {}, // 收货组织
    outWareHouseInfo: {}, // 发货仓库scanFlag
    inWareHouseInfo: {}, // 收货组织
    outStockGoods: [],
    outInDetails: {}, // 出入库单详情
    isShowKeyBoard: false, // 键盘未展示
    batchScanRecord: [], // 批次扫码记录
    showEditRemarks: 0, // 0不可输入备注 1输入多条备注  2只能输入一条备注
    orderStockConfig: {}, // 收发货设置
    organLevelNum: 0, // 选择组织的层级数
    url: '' // 跳转的URL链接
  }
};

var getters = exports.getters = (_getters = {}, (0, _defineProperty3.default)(_getters, NS + 'outInDetails', function (state) {
  return state.global.outInDetails;
}), (0, _defineProperty3.default)(_getters, NS + 'outStockGoods', function (state) {
  return state.global.outStockGoods;
}), (0, _defineProperty3.default)(_getters, NS + 'orderStockConfig', function (state) {
  return state.global.orderStockConfig;
}), (0, _defineProperty3.default)(_getters, NS + 'organLevelNum', function (state) {
  return state.global.organLevelNum;
}), (0, _defineProperty3.default)(_getters, NS + 'url', function (state) {
  return state.global.url;
}), (0, _defineProperty3.default)(_getters, NS + 'batchScanRecord', function (state) {
  return state.global.batchScanRecord;
}), (0, _defineProperty3.default)(_getters, NS + 'outOrganInfo', function (state) {
  return state.global.outOrganInfo;
}), (0, _defineProperty3.default)(_getters, NS + 'showEditRemarks', function (state) {
  return state.global.showEditRemarks;
}), (0, _defineProperty3.default)(_getters, NS + 'isShowKeyBoard', function (state) {
  return state.global.isShowKeyBoard;
}), (0, _defineProperty3.default)(_getters, NS + 'inOrganInfo', function (state) {
  return state.global.inOrganInfo;
}), (0, _defineProperty3.default)(_getters, NS + 'outWareHouseInfo', function (state) {
  return state.global.outWareHouseInfo;
}), (0, _defineProperty3.default)(_getters, NS + 'inWareHouseInfo', function (state) {
  return state.global.inWareHouseInfo;
}), (0, _defineProperty3.default)(_getters, NS + 'timeVisible', function (state) {
  return state.global.timeVisible;
}), (0, _defineProperty3.default)(_getters, NS + 'user', function (state) {
  state.global.user = _session2.default.getLoginUser();
  return state.global.user;
}), (0, _defineProperty3.default)(_getters, NS + 'userid', function (state) {
  return state.global.userid;
}), (0, _defineProperty3.default)(_getters, NS + 'isLoading', function (state) {
  return state.global.isLoading;
}), (0, _defineProperty3.default)(_getters, NS + 'isPDA', function (state) {
  state.global.isPDA = _local2.default.getIsPDA();
  return state.global.isPDA;
}), (0, _defineProperty3.default)(_getters, NS + 'scanMode', function (state) {
  return state.global.scanMode;
}), (0, _defineProperty3.default)(_getters, NS + 'isInitScanView', function (state) {
  return state.global.isInitScanView;
}), (0, _defineProperty3.default)(_getters, NS + 'scanViewStatus', function (state) {
  return state.global.scanViewStatus;
}), (0, _defineProperty3.default)(_getters, NS + 'scanFlag', function (state) {
  return state.global.scanFlag;
}), _getters);

var mutations = exports.mutations = (_mutations = {}, (0, _defineProperty3.default)(_mutations, NS + 'changeOutInDetails', function (state, outInDetails) {
  state.global.outInDetails = outInDetails;
}), (0, _defineProperty3.default)(_mutations, NS + 'changeOutStockGoods', function (state, outStockGoods) {
  state.global.outStockGoods = outStockGoods;
}), (0, _defineProperty3.default)(_mutations, NS + 'changeBatchScanRecord', function (state, batchScanRecord) {
  state.global.batchScanRecord = batchScanRecord;
}), (0, _defineProperty3.default)(_mutations, NS + 'changeOrderStockConfig', function (state, orderStockConfig) {
  state.global.orderStockConfig = orderStockConfig;
}), (0, _defineProperty3.default)(_mutations, NS + 'changeOrganLevelNum', function (state, organLevelNum) {
  state.global.organLevelNum = organLevelNum;
}), (0, _defineProperty3.default)(_mutations, NS + 'changeUrl', function (state, url) {
  state.global.url = url;
}), (0, _defineProperty3.default)(_mutations, NS + 'changeShowEditRemarks', function (state, showEditRemarks) {
  state.global.showEditRemarks = showEditRemarks;
}), (0, _defineProperty3.default)(_mutations, NS + 'changeOutOrganInfo', function (state, outOrganInfo) {
  state.global.outOrganInfo = outOrganInfo;
}), (0, _defineProperty3.default)(_mutations, NS + 'changeShowKeyBoard', function (state, isShowKeyBoard) {
  state.global.isShowKeyBoard = isShowKeyBoard;
}), (0, _defineProperty3.default)(_mutations, NS + 'changeInOrganInfo', function (state, inOrganInfo) {
  state.global.inOrganInfo = inOrganInfo;
}), (0, _defineProperty3.default)(_mutations, NS + 'changeOutWareHouseInfo', function (state, outWareHouseInfo) {
  state.global.outWareHouseInfo = outWareHouseInfo;
}), (0, _defineProperty3.default)(_mutations, NS + 'changeInWareHouseInfo', function (state, inWareHouseInfo) {
  state.global.inWareHouseInfo = inWareHouseInfo;
}), (0, _defineProperty3.default)(_mutations, NS + 'changeTimeVisible', function (state, timeVisible) {
  state.global.timeVisible = timeVisible;
}), (0, _defineProperty3.default)(_mutations, NS + 'changeUser', function (state, user) {
  state.global.user = user;
  _session2.default.setLoginUser(user);
}), (0, _defineProperty3.default)(_mutations, NS + 'changeUserid', function (state, userid) {
  state.global.userid = userid;
}), (0, _defineProperty3.default)(_mutations, NS + 'changeIsLoading', function (state, flag) {
  state.global.isLoading = flag;
}), (0, _defineProperty3.default)(_mutations, NS + 'changeIsPDA', function (state, flag) {
  state.global.isPDA = flag;
}), (0, _defineProperty3.default)(_mutations, NS + 'changeScanMode', function (state, flag) {
  state.global.scanMode = flag;
}), (0, _defineProperty3.default)(_mutations, NS + 'changeIsInitScanView', function (state, flag) {
  state.global.isInitScanView = flag;
}), (0, _defineProperty3.default)(_mutations, NS + 'changeScanViewStatus', function (state, flag) {
  state.global.scanViewStatus = flag;
}), (0, _defineProperty3.default)(_mutations, NS + 'changeScanFlag', function (state, flag) {
  state.global.scanFlag = flag;
}), _mutations);

var actions = exports.actions = {};

/***/ }),

/***/ "77y4":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
Object.defineProperty(__webpack_exports__, "__esModule", { value: true });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__babel_loader_node_modules_vue_loader_lib_selector_type_script_index_0_selectOrgan_vue__ = __webpack_require__("SgIK");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__babel_loader_node_modules_vue_loader_lib_selector_type_script_index_0_selectOrgan_vue___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0__babel_loader_node_modules_vue_loader_lib_selector_type_script_index_0_selectOrgan_vue__);
/* harmony namespace reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in __WEBPACK_IMPORTED_MODULE_0__babel_loader_node_modules_vue_loader_lib_selector_type_script_index_0_selectOrgan_vue__) if(__WEBPACK_IMPORT_KEY__ !== 'default') (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return __WEBPACK_IMPORTED_MODULE_0__babel_loader_node_modules_vue_loader_lib_selector_type_script_index_0_selectOrgan_vue__[key]; }) }(__WEBPACK_IMPORT_KEY__));
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__node_modules_vue_loader_lib_template_compiler_index_id_data_v_01e83348_hasScoped_true_transformToRequire_video_src_poster_source_src_img_src_image_xlink_href_buble_transforms_node_modules_vue_loader_lib_selector_type_template_index_0_selectOrgan_vue__ = __webpack_require__("k/Mv");
function injectStyle (ssrContext) {
  __webpack_require__("FX6q")
  __webpack_require__("R9Oq")
}
var normalizeComponent = __webpack_require__("VU/8")
/* script */


/* template */

/* template functional */
var __vue_template_functional__ = false
/* styles */
var __vue_styles__ = injectStyle
/* scopeId */
var __vue_scopeId__ = "data-v-01e83348"
/* moduleIdentifier (server only) */
var __vue_module_identifier__ = null
var Component = normalizeComponent(
  __WEBPACK_IMPORTED_MODULE_0__babel_loader_node_modules_vue_loader_lib_selector_type_script_index_0_selectOrgan_vue___default.a,
  __WEBPACK_IMPORTED_MODULE_1__node_modules_vue_loader_lib_template_compiler_index_id_data_v_01e83348_hasScoped_true_transformToRequire_video_src_poster_source_src_img_src_image_xlink_href_buble_transforms_node_modules_vue_loader_lib_selector_type_template_index_0_selectOrgan_vue__["a" /* default */],
  __vue_template_functional__,
  __vue_styles__,
  __vue_scopeId__,
  __vue_module_identifier__
)

/* harmony default export */ __webpack_exports__["default"] = (Component.exports);


/***/ }),

/***/ "B0cl":
/***/ (function(module, exports) {

module.exports = {"userInfo":{"serviceUrl":"","username":"Julian","nickName":"Julian","tenantId":"Julian","roleType":2,"companyType":0,"token":"ZXlKaGJHY2lPaUpTVXpJMU5pSjkuZXlKemRXSWlPaUpxYVdVaUxDSjFjMlZ5U1dRaU9qWTJNVGMwTlRZNU56WXpNamMyTURZeU56SXNJblJsYm1GdWRFbGtJam9pYW1sbElpd2libWxqYTA1aGJXVWlPaUpxYVdVaUxDSndjbTlrZFdOMFNXUWlPaklzSW5WelpYSnVZVzFsSWpvaWFtbGxJaXdpYkc5bmFXNU5iMlJsSWpvaVVFTWlMQ0pqY21WaGRHVkVZWFJsSWpveE5UY3lNalUxTWpnM05qSTVMQ0pqYjIxd1lXNTVWSGx3WlNJNk1Dd2ljbTlzWlZSNWNHVWlPaklzSW05eVowbGtJam8yTmpFM05EVTFOekExTURFM01qZzJOalUyTENKMWMyVnlWSGx3WlNJNklqQWlmUS5PUjg2c1BTbUpmdGFya2RfN3Q0azVzaTIxRENMQWpvQkctSEdpZTBiRVNoWnM4ZDU5N09uVGlNSEtSZVhtTXoyemxyUlZueVQ2X3o3bzUtaUItSzlnOFZ5UzRBR053OWVmaXhKUHRHbnZuZnI1dWZYNFdUNGpCVkN6Uy1rODJFTnlLZnZmd0o2bUZZTDBuMzRsQml1aC1Qa2NsTDh1b1IwSDQwRDRkZUZVbnc=","loginFlag":false,"expire":1440,"orgId":"6579126089719759000","userId":"1223"},"positionInfo":{"longitude":"100.12","latitude":"100.3","addr":"中国深圳"},"systemInfo":{"appVersion":"1.0","imei":"869881012802909","model":"QCC S8","osType":"0","osVersion":"6.0","sdkVersion":"23","isPDA":false}}

/***/ }),

/***/ "CN9/":
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _extends2 = __webpack_require__("Dd8w");

var _extends3 = _interopRequireDefault(_extends2);

var _vant = __webpack_require__("Fd2+");

var _vue = __webpack_require__("lRwf");

var _vue2 = _interopRequireDefault(_vue);

var _vuex = __webpack_require__("SJI6");

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = {
  name: 'App',
  computed: (0, _extends3.default)({}, (0, _vuex.mapGetters)({
    isLoading: 'global.isLoading',
    scanFlag: 'global.scanFlag'
  })),
  data: function data() {
    return {};
  },

  watch: {
    /* isLoading (val, oldVal) {
              val ? Indicator.open() : Indicator.close()
            }, */
    scanFlag: function scanFlag(val, oldVal) {
      this.$util.business.AppUtils.setScanStatus(!val);
    }
  },
  created: function created() {
    var _this = this;

    this.initVueResource();
    this.$util.business.AppUtils.goBackHistory(function () {
      _this.goBack();
    });
  },

  methods: {
    selectTime: function selectTime() {
      this.$store.commit('global.changeTimeVisible', true);
    },
    initVueResource: function initVueResource() {
      var _this2 = this;

      _vue2.default.http.interceptors.push(function (request, next) {
        _this2.$store.commit('global.changeIsLoading', true);
        next(function (response) {
          _this2.$store.commit('global.changeIsLoading', false);
          if (response.status === 200 || response.status === 304) {
            return response;
          } else if (response.status === 401) {
            var me = _this2;
            me.$util.business.AppUtils.openMessageBox('提示', '', '会话超时，请重新登录', '', '确定', false, function (result) {
              me.$util.business.AppUtils.tokenFail(function (result) {});
            });
            _this2.$store.commit('global.changeScanFlag', false); // 解锁
          } else if (response.status === 0) {
            if (window.config.forApp) {
              _this2.$util.business.AppUtils.openMessageBox('提示', '', '网络异常,请尝试重连网络', '', '确定', false, function (result) {});
            } else {
              (0, _vant.Toast)({ message: '网络异常,请尝试重连网络!' });
            }
            _this2.$store.commit('global.changeScanFlag', false); // 解锁
          } else {
            (0, _vant.Toast)({ message: '服务端异常，请联系技术支持!' });
            _this2.$store.commit('global.changeScanFlag', false); // 解锁
          }
        });
      });
    },
    goBack: function goBack() {
      if (this.$route.path === '/') return this.$util.business.AppUtils.existApplet();
      this.$router.goBack(this.$route);
    }
  }
}; //
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

/***/ }),

/***/ "CS8j":
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _typeof2 = __webpack_require__("pFYg");

var _typeof3 = _interopRequireDefault(_typeof2);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = {
  // 获取标签的真实属性值 包含小数
  // tag 标签对象
  // attr 要获取的属性值
  // isNumber 是否转换为number类型
  getTagComputedStyle: function getTagComputedStyle(tag, attr, isNumber) {
    if (!tag || !tag.nodeName || (typeof tag === 'undefined' ? 'undefined' : (0, _typeof3.default)(tag)) !== 'object') {
      return isNumber ? 0 : '';
    }
    var attrValue = window.getComputedStyle(tag)[attr];
    if (attrValue.indexOf('px') !== -1) {
      attrValue = attrValue.substring(0, attrValue.length - 2);
    }
    return isNumber ? Number(attrValue) : attrValue;
  },
  getStyle: function getStyle(obj, attr) {
    if (obj.currentStyle) {
      return obj.currentStyle[attr];
    } else {
      return document.defaultView.getComputedStyle(obj, null)[attr];
    }
  },
  setBodyFontSize: function setBodyFontSize(p) {
    var width = window.innerWidth;

    var px = width / 120;

    var body = document.getElementsByTagName('layout.css')[0];

    body.style.fontSize = px + 'px';
  },
  offsetTop: function offsetTop($event) {
    var target = $event.nodeName ? $event : $event.target;
    var offsetTop = 0;
    while (target.previousElementSibling !== null) {
      target = target.previousElementSibling;
      offsetTop += target.offsetHeight;
      if (target.style.marginTop !== '') {
        offsetTop += parseFloat(target.style.marginTop);
      }
      if (target.style.marginBottom !== '') {
        offsetTop += target.style.marginBottom;
      }
    }
    return offsetTop;
  },

  //
  offset: function offset($event) {
    var target = $event.nodeName ? $event : $event.target;
    var site = {
      left: target.offsetLeft + 'px',
      top: target.offsetTop + 'px'
    };
    return site;
  },
  position: function position($event) {
    var target = $event.nodeName ? $event : $event.target;
    var stTarget = $event.nodeName ? $event : $event.target;
    var scrollTop = 0;
    var site = {
      left: target.offsetLeft,
      top: target.offsetTop - scrollTop
    };
    while (target.offsetParent) {
      target = target.offsetParent;
      site.left += target.offsetLeft;
      site.top += target.offsetTop;
    }
    while (stTarget.parentNode && stTarget.parentNode.nodeName.toLowerCase() !== 'layout.css') {
      stTarget = stTarget.parentNode;
      scrollTop += stTarget.scrollTop;
    }
    site.top -= scrollTop;
    return site;
  }
};

/***/ }),

/***/ "Dh9P":
/***/ (function(module, exports) {

module.exports = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABoAAAAaCAYAAACpSkzOAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyZpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuNi1jMTQ1IDc5LjE2MzQ5OSwgMjAxOC8wOC8xMy0xNjo0MDoyMiAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENDIDIwMTkgKFdpbmRvd3MpIiB4bXBNTTpJbnN0YW5jZUlEPSJ4bXAuaWlkOkQxMzc2RjY4NzhCNTExRUFCRDg1ODZBMzYyRURDOTI2IiB4bXBNTTpEb2N1bWVudElEPSJ4bXAuZGlkOkQxMzc2RjY5NzhCNTExRUFCRDg1ODZBMzYyRURDOTI2Ij4gPHhtcE1NOkRlcml2ZWRGcm9tIHN0UmVmOmluc3RhbmNlSUQ9InhtcC5paWQ6RDEzNzZGNjY3OEI1MTFFQUJEODU4NkEzNjJFREM5MjYiIHN0UmVmOmRvY3VtZW50SUQ9InhtcC5kaWQ6RDEzNzZGNjc3OEI1MTFFQUJEODU4NkEzNjJFREM5MjYiLz4gPC9yZGY6RGVzY3JpcHRpb24+IDwvcmRmOlJERj4gPC94OnhtcG1ldGE+IDw/eHBhY2tldCBlbmQ9InIiPz6oCrIBAAADBElEQVR42qRWXWxLYRh+d/qztsuQlawhxgTTCRPJdIvZECPiArtzIS6WIMSFO/FzIUZ2KwshrsQtRsTELBsxpZFIOrJh/mNiobLVetrt9Mf7fvvanZ5+55ydeJMnbb+e9336/j1fi8a6fGBiKxF7ENsR1QgvP48gBhHdiDuI90ZBigyImhDnEJtgdvYUcQbxRPSlJDhzIa4g+iyQAH+2j/u6zIjKEL2IQ5QtWLci7tvLYwmJPIguRD38v9XzWB4R0UVEQOTlWHgUipe35525195g5wYW4DHziKjxrXoetrmrweFrzDuzl9WA5Flsllkrj50jalP3RCqpBZf/sq63bd5OkNwLIDX+ejY9a2M/DFGDaMjPYAMUL90Lkx/aIaN8K/C2z2+aHs8qLF1VfvlS0Y8QH9ivPqLYNUTUYrXTVMbknzcYdHjmrLwB0vFRSMsjIpcWu8VdYWWzlVaCHG4D5celmSy9QVB+9sHU1wsit0bq0SorRMXLDvLy1c00wlHByDPKuJ5blaTSLvOS4Tg7yusgMXydTV2OyFnOXtPyJz1Xr2Qlm+SvezD5pROH5AT77FxykmfXDJlkDFJjD3R9Ja7CszKawMTQEfZeGe3HodjC+1MLyYjhqEeI6K3pMjhKC85o9G1zKllWdu8aJHppFOKdxOVdaC7/eSjdPADORduE2U197wZ39TF8L+tNW+4KIaLbhQs5PVGS24fBumBqpEfcs9/PcktqYreIKIzoV58mhk5BtCcAsVAza3xG+SvcJ8+6s9irF6x0WtFVGcUOZ6fuNFVDXRaR9GSN+lJS24Ekz0F+hVL1+Sa4Vhxgiq6tML91c6JK1+8186GoAM/6TtYX6k9W0yjr+GAH7lg9lAQeMVHmRjEfa++j44iQeKyjrA/ZLEl+smOeNRqGieA+fGYC0jE2gSEeU/jnhFTivt4FaMGIZJd6R7XKQF/QFl5V98yCZbjvVq0QiCQojjjMCYMWSIKcgHzlgpUxcKQB2cjVfTdiB8Kv+QM5hHiIuGumMP8EGAC8b/J5iCUCjAAAAABJRU5ErkJggg=="

/***/ }),

/***/ "DsYT":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
Object.defineProperty(__webpack_exports__, "__esModule", { value: true });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__babel_loader_node_modules_vue_loader_lib_selector_type_script_index_0_app_vue__ = __webpack_require__("CN9/");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__babel_loader_node_modules_vue_loader_lib_selector_type_script_index_0_app_vue___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0__babel_loader_node_modules_vue_loader_lib_selector_type_script_index_0_app_vue__);
/* harmony namespace reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in __WEBPACK_IMPORTED_MODULE_0__babel_loader_node_modules_vue_loader_lib_selector_type_script_index_0_app_vue__) if(__WEBPACK_IMPORT_KEY__ !== 'default') (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return __WEBPACK_IMPORTED_MODULE_0__babel_loader_node_modules_vue_loader_lib_selector_type_script_index_0_app_vue__[key]; }) }(__WEBPACK_IMPORT_KEY__));
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__node_modules_vue_loader_lib_template_compiler_index_id_data_v_2b672cb8_hasScoped_false_transformToRequire_video_src_poster_source_src_img_src_image_xlink_href_buble_transforms_node_modules_vue_loader_lib_selector_type_template_index_0_app_vue__ = __webpack_require__("z0u7");
function injectStyle (ssrContext) {
  __webpack_require__("2/kW")
}
var normalizeComponent = __webpack_require__("VU/8")
/* script */


/* template */

/* template functional */
var __vue_template_functional__ = false
/* styles */
var __vue_styles__ = injectStyle
/* scopeId */
var __vue_scopeId__ = null
/* moduleIdentifier (server only) */
var __vue_module_identifier__ = null
var Component = normalizeComponent(
  __WEBPACK_IMPORTED_MODULE_0__babel_loader_node_modules_vue_loader_lib_selector_type_script_index_0_app_vue___default.a,
  __WEBPACK_IMPORTED_MODULE_1__node_modules_vue_loader_lib_template_compiler_index_id_data_v_2b672cb8_hasScoped_false_transformToRequire_video_src_poster_source_src_img_src_image_xlink_href_buble_transforms_node_modules_vue_loader_lib_selector_type_template_index_0_app_vue__["a" /* default */],
  __vue_template_functional__,
  __vue_styles__,
  __vue_scopeId__,
  __vue_module_identifier__
)

/* harmony default export */ __webpack_exports__["default"] = (Component.exports);


/***/ }),

/***/ "F7Wx":
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
//
//
//
//
//
//
//
//
//

exports.default = {
  data: function data() {
    return {
      transitionName: 'slide-left'
    };
  },
  beforeRouteUpdate: function beforeRouteUpdate(to, from, next) {
    var isBack = this.$router.isBack;
    if (isBack) {
      this.transitionName = 'slide-right';
    } else {
      this.transitionName = 'slide-left';
    }
    this.$router.isBack = false;
    next();
  }
};

/***/ }),

/***/ "FCDO":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
var render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('div',{attrs:{"id":"wholeCodeIn"}},[_c('div',{staticClass:"search-input"},[_c('van-search',{attrs:{"placeholder":"请录入码值"},on:{"search":_vm.codeScan},model:{value:(_vm.scannedInfo.code),callback:function ($$v) {_vm.$set(_vm.scannedInfo, "code", $$v)},expression:"scannedInfo.code"}}),_vm._v(" "),_c('span',{staticClass:"search-button",on:{"click":_vm.codeScan}},[_vm._v("录入")])],1),_vm._v(" "),(_vm.scanRecordList.length>0)?_c('div',{staticClass:"scan-list"},[_c('p',{staticClass:"scan-num"},[_c('span',[_vm._v("当前已扫码数量")]),_vm._v(" "),_c('span',[_vm._v(_vm._s(_vm.total))])]),_vm._v(" "),_c('ul',{staticClass:"list-item"},_vm._l((_vm.scanRecordList),function(record,index){return _c('li',{key:index},[_c('div',[(record.goodsInfo!=null)?_c('p',[_vm._v(_vm._s(record.goodsInfo.sku.name)),_c('span',{staticClass:"yellow-text"},[_vm._v("("+_vm._s(record.goodsInfo.unit)+")")])]):_vm._e(),_vm._v(" "),_c('p',{staticClass:"gray-text"},[_c('span',[_vm._v(_vm._s(_vm.$util.common.ObjectUtils.filterCode(record.codeInfo.codes)))]),_vm._v(" "),_c('span',[_vm._v("耗时:"+_vm._s(record.time)+"ms")])])]),_vm._v(" "),(record.successFlag==0)?_c('div',{staticClass:"green-text"},[_vm._v("入库成功")]):_c('div',{staticClass:"red-text"},[_vm._v("入库失败")])])}),0)]):_c('div',{staticClass:"empty-list"},[_c('img',{attrs:{"src":__webpack_require__("u8EM"),"alt":""}}),_vm._v(" "),_c('p',{staticClass:"gray-text"},[_vm._v("暂无记录")])])])}
var staticRenderFns = []
var esExports = { render: render, staticRenderFns: staticRenderFns }
/* harmony default export */ __webpack_exports__["a"] = (esExports);

/***/ }),

/***/ "FITS":
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _stringify = __webpack_require__("mvHQ");

var _stringify2 = _interopRequireDefault(_stringify);

var _typeof2 = __webpack_require__("pFYg");

var _typeof3 = _interopRequireDefault(_typeof2);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var CODE_SEGMENT = 'CODE_SEGMENT';
var ALL_WRAPPER = 'ALL_WRAPPER';
var WAREHOUSE_LIST = 'WAREHOUSE_LIST';
var SYSTEM_INFO = 'SYSTEM_INFO';
var GOODS_LIST = 'GOODS_LIST';
var HAND_GOODS_LIST = 'HAND_GOODS_LIST';
var APP_HAND_ORDER_DATA = 'APP_HAND_ORDER_DATA';
var POSITION_INFO = 'POSITION_INFO';
var USER_SELECT_DATA = 'USER_SELECT_DATA';

exports.default = {
  setCodeSegment: function setCodeSegment(code) {
    if ((typeof code === 'undefined' ? 'undefined' : (0, _typeof3.default)(code)) === 'object') {
      window.localStorage.setItem(CODE_SEGMENT, (0, _stringify2.default)(code));
    } else {
      window.localStorage.setItem(CODE_SEGMENT, '');
    }
  },
  getCodeSegment: function getCodeSegment() {
    var jsonStr = window.localStorage.getItem(CODE_SEGMENT);
    if (jsonStr && jsonStr !== '') {
      try {
        return JSON.parse(jsonStr);
      } catch (e) {
        console.error(e);
        return null;
      }
    }
    return null;
  },
  setGoodList: function setGoodList(good) {
    if ((typeof good === 'undefined' ? 'undefined' : (0, _typeof3.default)(good)) === 'object') {
      window.localStorage.setItem(GOODS_LIST, (0, _stringify2.default)(good));
    } else {
      window.localStorage.setItem(GOODS_LIST, '');
    }
  },
  getGoodList: function getGoodList() {
    var jsonStr = window.localStorage.getItem(GOODS_LIST);
    if (jsonStr && jsonStr !== '') {
      try {
        return JSON.parse(jsonStr);
      } catch (e) {
        console.error(e);
        return null;
      }
    }
    return null;
  },
  setHandGoodList: function setHandGoodList(good) {
    if ((typeof good === 'undefined' ? 'undefined' : (0, _typeof3.default)(good)) === 'object') {
      window.localStorage.setItem(HAND_GOODS_LIST, (0, _stringify2.default)(good));
    } else {
      window.localStorage.setItem(HAND_GOODS_LIST, '');
    }
  },
  getHandGoodList: function getHandGoodList() {
    var jsonStr = window.localStorage.getItem(HAND_GOODS_LIST);
    if (jsonStr && jsonStr !== '') {
      try {
        return JSON.parse(jsonStr);
      } catch (e) {
        console.error(e);
        return null;
      }
    }
    return null;
  },
  setAppHandOrderData: function setAppHandOrderData(data) {
    if ((typeof data === 'undefined' ? 'undefined' : (0, _typeof3.default)(data)) === 'object') {
      window.localStorage.setItem(APP_HAND_ORDER_DATA, (0, _stringify2.default)(data));
    } else {
      window.localStorage.setItem(APP_HAND_ORDER_DATA, '');
    }
  },
  getAppHandOrderData: function getAppHandOrderData() {
    var jsonStr = window.localStorage.getItem(APP_HAND_ORDER_DATA);
    if (jsonStr && jsonStr !== '') {
      try {
        return JSON.parse(jsonStr);
      } catch (e) {
        console.error(e);
        return null;
      }
    }
    return null;
  },
  removeCodeSegment: function removeCodeSegment() {
    window.localStorage.removeItem(CODE_SEGMENT);
  },
  setAllWrapper: function setAllWrapper(code) {
    if ((typeof code === 'undefined' ? 'undefined' : (0, _typeof3.default)(code)) === 'object') {
      window.localStorage.setItem(ALL_WRAPPER, (0, _stringify2.default)(code));
    } else {
      window.localStorage.setItem(ALL_WRAPPER, '');
    }
  },
  getAllWrapper: function getAllWrapper() {
    var jsonStr = window.localStorage.getItem(ALL_WRAPPER);
    if (jsonStr && jsonStr !== '') {
      try {
        return JSON.parse(jsonStr);
      } catch (e) {
        console.error(e);
        return [];
      }
    }
    return [];
  },
  removeAllWrapper: function removeAllWrapper() {
    window.localStorage.removeItem(ALL_WRAPPER);
  },
  setWarehouseList: function setWarehouseList(list) {
    if ((typeof list === 'undefined' ? 'undefined' : (0, _typeof3.default)(list)) === 'object') {
      window.localStorage.setItem(WAREHOUSE_LIST, (0, _stringify2.default)(list));
    } else {
      window.localStorage.setItem(WAREHOUSE_LIST, '');
    }
  },
  getWarehouseList: function getWarehouseList() {
    var jsonStr = window.localStorage.getItem(WAREHOUSE_LIST);
    if (jsonStr && jsonStr !== '') {
      try {
        return JSON.parse(jsonStr);
      } catch (e) {
        console.error(e);
        return null;
      }
    }
    return null;
  },
  removeWarehouseList: function removeWarehouseList() {
    window.localStorage.removeItem(WAREHOUSE_LIST);
  },
  setSystemInfo: function setSystemInfo(info) {
    if ((typeof info === 'undefined' ? 'undefined' : (0, _typeof3.default)(info)) === 'object') {
      window.localStorage.setItem(SYSTEM_INFO, (0, _stringify2.default)(info));
    } else {
      window.localStorage.setItem(SYSTEM_INFO, '');
    }
  },
  getSystemInfo: function getSystemInfo() {
    var jsonStr = window.localStorage.getItem(SYSTEM_INFO);
    if (jsonStr && jsonStr !== '') {
      try {
        return JSON.parse(jsonStr);
      } catch (e) {
        console.error(e);
        return null;
      }
    }
    return null;
  },
  setPositionInfo: function setPositionInfo(info) {
    if ((typeof info === 'undefined' ? 'undefined' : (0, _typeof3.default)(info)) === 'object') {
      window.localStorage.setItem(POSITION_INFO, (0, _stringify2.default)(info));
    } else {
      window.localStorage.setItem(POSITION_INFO, '');
    }
  },
  getPositionInfo: function getPositionInfo() {
    var jsonStr = window.localStorage.getItem(POSITION_INFO);
    if (jsonStr && jsonStr !== '') {
      try {
        return JSON.parse(jsonStr);
      } catch (e) {
        console.error(e);
        return null;
      }
    }
    return null;
  },
  setUserSelectData: function setUserSelectData(info) {
    if ((typeof info === 'undefined' ? 'undefined' : (0, _typeof3.default)(info)) === 'object') {
      window.localStorage.setItem(USER_SELECT_DATA, (0, _stringify2.default)(info));
    } else {
      window.localStorage.setItem(USER_SELECT_DATA, '');
    }
  },
  getUserSelectData: function getUserSelectData() {
    var jsonStr = window.localStorage.getItem(USER_SELECT_DATA);
    if (jsonStr && jsonStr !== '') {
      try {
        return JSON.parse(jsonStr);
      } catch (e) {
        console.error(e);
        return null;
      }
    }
    return null;
  },
  removeSystemInfo: function removeSystemInfo() {
    window.localStorage.removeItem(SYSTEM_INFO);
  },
  getIsPDA: function getIsPDA() {
    // I/LoginActivity: 设备信息: {"appVersion":"1.0","imei":"869881012802909","model":"QCC S8","osType":"0","osVersion":"6.0","sdkVersion":"23"}
    // I/Webview2Activity: 设备信息: {"appVersion":"1.0","imei":"A1000012665FC7","model":"70 series","osType":"0","osVersion":"6.0","sdkVersion":"23"}
    // I/Webview2Activity: 设备信息: {"appVersion":"1.0","imei":"866828020962038","model":"PDT-90F","osType":"0","osVersion":"5.1","sdkVersion":"22"}
    var systemInfo = this.getSystemInfo();
    // window.alert(JSON.stringify(systemInfo))
    var PDAModelList = ['QCC S8', '70 series', '70 Series', 'PDT-90F', 'MC33', 'msm8909'];
    return systemInfo.isPDA === undefined ? PDAModelList.indexOf(systemInfo.model) > -1 : systemInfo.isPDA;
  }
};

/***/ }),

/***/ "FX6q":
/***/ (function(module, exports) {

// removed by extract-text-webpack-plugin

/***/ }),

/***/ "G0M6":
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _defineProperty2 = __webpack_require__("bOdI");

var _defineProperty3 = _interopRequireDefault(_defineProperty2);

var _getters, _mutations;

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var NS = 'outOrder.';
exports.default = {
  state: {
    outOrder: {
      chooseOrgan: {}, // 已选组织
      chooseWareHouse: {}, // 已选仓库
      chooseRemarksInfo: [], // 评论列表
      chooseGoodsList: [], // 已选商品列表
      chooseDeliverWareHouse: {}, // 选择发货仓库
      timeVisible: false // 是否打开时间选择框
    }
  },
  getters: (_getters = {}, (0, _defineProperty3.default)(_getters, NS + 'organInfo', function (state) {
    return state.outOrder.chooseOrgan;
  }), (0, _defineProperty3.default)(_getters, NS + 'wareHouseInfo', function (state) {
    return state.outOrder.chooseWareHouse;
  }), (0, _defineProperty3.default)(_getters, NS + 'deliverWareHouseInfo', function (state) {
    return state.outOrder.chooseDeliverWareHouse;
  }), (0, _defineProperty3.default)(_getters, NS + 'remarksInfo', function (state) {
    return state.outOrder.chooseRemarksInfo;
  }), (0, _defineProperty3.default)(_getters, NS + 'goodsList', function (state) {
    return state.outOrder.chooseGoodsList;
  }), (0, _defineProperty3.default)(_getters, NS + 'timeVisible', function (state) {
    return state.outOrder.timeVisible;
  }), _getters),
  mutations: (_mutations = {}, (0, _defineProperty3.default)(_mutations, NS + 'changeOrganInfo', function (state, organ) {
    state.outOrder.chooseOrgan = organ;
  }), (0, _defineProperty3.default)(_mutations, NS + 'changeWareHouseInfo', function (state, wareHouse) {
    state.outOrder.chooseWareHouse = wareHouse;
  }), (0, _defineProperty3.default)(_mutations, NS + 'changeDeliverWareHouseInfo', function (state, wareHouse) {
    state.outOrder.chooseDeliverWareHouse = wareHouse;
  }), (0, _defineProperty3.default)(_mutations, NS + 'changeRemarksInfo', function (state, remarksInfo) {
    state.outOrder.chooseRemarksInfo = remarksInfo;
  }), (0, _defineProperty3.default)(_mutations, NS + 'changeGoodsList', function (state, goodsList) {
    state.outOrder.chooseGoodsList = goodsList;
  }), (0, _defineProperty3.default)(_mutations, NS + 'changeTimeVisible', function (state, timeVisible) {
    state.outOrder.timeVisible = timeVisible;
  }), _mutations)
};

/***/ }),

/***/ "IUrY":
/***/ (function(module, exports) {

// removed by extract-text-webpack-plugin

/***/ }),

/***/ "IcnI":
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _vue = __webpack_require__("lRwf");

var _vue2 = _interopRequireDefault(_vue);

var _vuex = __webpack_require__("SJI6");

var _vuex2 = _interopRequireDefault(_vuex);

var _global = __webpack_require__("6zCF");

var _pack = __webpack_require__("wkJh");

var _pack2 = _interopRequireDefault(_pack);

var _batchSearch = __webpack_require__("f6Gb");

var _batchSearch2 = _interopRequireDefault(_batchSearch);

var _outOrder = __webpack_require__("G0M6");

var _outOrder2 = _interopRequireDefault(_outOrder);

var _scanOutOrder = __webpack_require__("bBFl");

var _scanOutOrder2 = _interopRequireDefault(_scanOutOrder);

var _stockStatistics = __webpack_require__("kqKe");

var _stockStatistics2 = _interopRequireDefault(_stockStatistics);

var _disassociate = __webpack_require__("uGmS");

var _disassociate2 = _interopRequireDefault(_disassociate);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

_vue2.default.use(_vuex2.default);
var store = new _vuex2.default.Store({
  actions: _global.actions,
  state: _global.state,
  getters: _global.getters,
  mutations: _global.mutations,
  modules: {
    pack: _pack2.default,
    batchSearch: _batchSearch2.default,
    outOrder: _outOrder2.default,
    scanOutOrder: _scanOutOrder2.default,
    stockStatistics: _stockStatistics2.default,
    disassociate: _disassociate2.default
  }
});

exports.default = store;

/***/ }),

/***/ "M7S5":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
var render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('div',[_c('transition',{attrs:{"name":_vm.transitionName}},[_c('keep-alive',[_c('router-view',{staticClass:"child-view"})],1)],1)],1)}
var staticRenderFns = []
var esExports = { render: render, staticRenderFns: staticRenderFns }
/* harmony default export */ __webpack_exports__["a"] = (esExports);

/***/ }),

/***/ "Mlnd":
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = {
  //   @func
  //     * @desc 阿拉伯数字单位转换，并保留 n 位小数：1 0000 -> 1 万，1 0000 0000 -> 亿，以此类推。
  // * @param {Number} num - 需要转换的数字
  // * @param {Number} digit - 需保留的小数位数，默认保留两位小数
  // * @returns {String} 转换后的数字
  unitConvert: function unitConvert(num, digit) {
    var unit = '';
    var newNum = '';
    // 默认保留两位小数
    if (digit === null || typeof digit === 'undefined') {
      digit = 2;
    }
    // 判断 num 是否为空
    if (num === null || typeof num === 'undefined') {
      return;
    }
    // 判断 num 是否为数字
    if (!isNaN(num)) {
      if (num < 10000) {
        // 小于 1 0000，原样输出
        newNum = num;
      } else if (num >= 10000 && num < 100000000) {
        // 大于 1 0000 小于 1 0000 0000
        unit = '万';
        newNum = (num / 10000).toFixed(digit) + unit;
      } else if (num >= 100000000) {
        // 大于 1 0000 0000
        unit = '亿';
        newNum = (num / 100000000).toFixed(digit) + unit;
      }
      return newNum;
    } else {
      return num;
    }
  },

  /* 比较两个数的大小,返回true或者false */
  compareNum: function compareNum(num1, num2) {
    var a = num1 + '';
    var b = num2 + '';
    if (a.length > b.length) {
      return true;
    }
    if (a.length < b.length) {
      return false;
    }
    if (a.length > 0 && a.length <= 12) {
      return parseInt(a) >= parseInt(b);
    }
    if (a.length > 12 && a.length <= 24) {
      if (parseInt(a.substring(0, 12)) !== parseInt(b.substring(0, 12))) {
        return parseInt(a.substring(0, 12)) >= parseInt(b.substring(0, 12));
      } else {
        return parseInt(a.substring(12, a.length)) >= parseInt(b.substring(12, b.length));
      }
    }
    if (a.length > 24 && a.length <= 36) {
      if (parseInt(a.substring(0, 12)) !== parseInt(b.substring(0, 12))) {
        return parseInt(a.substring(0, 12)) >= parseInt(b.substring(0, 12));
      } else if (parseInt(a.substring(12, 24)) !== parseInt(b.substring(12, 24))) {
        return parseInt(a.substring(12, 24)) >= parseInt(b.substring(12, 24));
      } else {
        return parseInt(a.substring(24, a.length)) >= parseInt(b.substring(24, b.length));
      }
    }
  }
};

/***/ }),

/***/ "NpB5":
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _map = __webpack_require__("ifoU");

var _map2 = _interopRequireDefault(_map);

exports.default = function (router) {
  router.beforeEach(function (to, from, next) {
    try {
      beforeRouteEnter(to, from, next);
    } catch (e) {
      console.error(e);
    }
  });
};

var _business = __webpack_require__("ySQA");

var _business2 = _interopRequireDefault(_business);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

// 过滤的路由name
var filters = ['login', 'error', '500', '400'];

// 过滤的路由map
var filterMap = new _map2.default();
filters.forEach(function (item) {
  filterMap.set(item, true);
});

/**
 * 路由跳转之前
 */
function beforeRouteEnter(to, from, next) {
  document.body.scrollTop = 0;
  // 某些过滤的请求，包括login,error等
  if (isFilter(to.name)) {
    next();
    return;
  }
  if (from.name === null) return loadBaseData(next, to);
  next();
}

/**
 * 是否在过滤范围内
 */
function isFilter(name) {
  return filterMap.get(name);
}

/**
 * 加载基础数据
 */
function loadBaseData(next, to) {
  // 请求基础数据
  _business2.default.AppUtils.getData(function () {
    next();
  });
}

/***/ }),

/***/ "PXRN":
/***/ (function(module, exports) {

// removed by extract-text-webpack-plugin

/***/ }),

/***/ "R9Oq":
/***/ (function(module, exports) {

// removed by extract-text-webpack-plugin

/***/ }),

/***/ "SEaI":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
var render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('div',{attrs:{"id":"scanCodeIn"}},[_c('div',{staticClass:"select-organ"},[_vm._m(0),_vm._v(" "),_c('div',[_c('div',{staticClass:"organ-name"},[_c('p',[_c('span',[_vm._v(_vm._s(_vm.user.orgName))])]),_vm._v(" "),_c('p',[(_vm.inWareHouseInfo.id==undefined)?_c('span',[_vm._v("接收仓库:")]):_c('span',[_vm._v(_vm._s(_vm.inWareHouseInfo.warehouseName))])])]),_vm._v(" "),_c('div',{staticClass:"to-select-organ arrow-right",on:{"click":function($event){return _vm.toSelectOrgan(1)}}})])]),_vm._v(" "),_c('div',{staticClass:"content"}),_vm._v(" "),_c('div',{staticClass:"oper-button"},[_c('div',{staticClass:"blue-button-larger",on:{"click":_vm.toScan}},[_vm._v("开始扫码")]),_vm._v(" "),_c('div',{staticClass:"gray-text",staticStyle:{"text-align":"center"},on:{"click":_vm.toHistory}},[_vm._v("查看历史记录")])])])}
var staticRenderFns = [function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('div',[_c('img',{staticClass:"in-icon",attrs:{"src":__webpack_require__("Dh9P"),"alt":""}}),_vm._v(" "),_c('p',{staticClass:"gray-text"},[_vm._v("接收组织信息")])])}]
var esExports = { render: render, staticRenderFns: staticRenderFns }
/* harmony default export */ __webpack_exports__["a"] = (esExports);

/***/ }),

/***/ "SJI6":
/***/ (function(module, exports) {

module.exports = Vuex;

/***/ }),

/***/ "SgIK":
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _getIterator2 = __webpack_require__("BO1k");

var _getIterator3 = _interopRequireDefault(_getIterator2);

var _extends2 = __webpack_require__("Dd8w");

var _extends3 = _interopRequireDefault(_extends2);

var _vant = __webpack_require__("Fd2+");

var _vuex = __webpack_require__("SJI6");

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

exports.default = {
  name: 'sureOrder',
  computed: (0, _extends3.default)({}, (0, _vuex.mapGetters)({
    user: 'global.user',
    outWareHouseInfo: 'global.outWareHouseInfo',
    inWareHouseInfo: 'global.inWareHouseInfo',
    outOrganInfo: 'global.outOrganInfo',
    inOrganInfo: 'global.inOrganInfo',
    orderStockConfig: 'global.orderStockConfig',
    organLevelNum: 'global.organLevelNum'
  })),
  data: function data() {
    return {
      defaultSelect: 0,
      organList: [{
        text: '经销商',
        dot: true,
        value: 0,
        children: []
      }, {
        text: '工厂',
        dot: true,
        value: 1,
        children: []
      }, {
        text: '企业',
        dot: true,
        value: 2,
        children: []
      }],
      organListTemp: {
        org0: [],
        org1: [],
        org2: []
      },
      pageTotal: '',
      finished: false,
      loading: false,
      queryListParam: {
        current: 1,
        rows: 20,
        order: 'createDate',
        asc: false,
        keyString: '',
        parentId: '',
        orgType: '',
        displayFlag: true
      },
      parentIdList: []
    };
  },

  /*
    * $route.params.flag
    * 0 出  1进
    * $route.params.organFlag 0 下级  1上级  2自己  roleType 2企业用户  3 经销商用户 4 工厂用户
    * */
  activated: function activated() {
    switch (this.user.roleType) {
      case 2:
        this.defaultSelect = 2;
        this.queryListParam.orgType = 0;
        break;
      case 3:
        this.defaultSelect = 0;
        this.queryListParam.orgType = 3;
        break;
      case 4:
        this.defaultSelect = 1;
        this.queryListParam.orgType = 2;
        break;
    }
    this.queryListParam.parentId = '';
    this.$store.commit('global.changeOrganLevelNum', 0);
    this.clearFilter();
    this.clearOrganData();
    this.getOrganList(this.$route.params.organFlag);
  },
  created: function created() {},

  watch: {
    organLevelNum: function organLevelNum(newValue, oldValue) {
      console.log('newValue' + newValue);
      console.log('oldValue' + oldValue);
      if (oldValue > newValue) {
        this.parentIdList.pop();
      }
      if (newValue >= 0) {
        this.getOrganList(this.$route.params.organFlag);
      }
    }
  },
  methods: {
    changeType: function changeType(value) {
      this.clearFilter();
      this.$store.commit('global.changeOrganLevelNum', 0);
      this.parentIdList = [];
      this.getOrganList(this.$route.params.organFlag);
    },
    getLowerOrgan: function getLowerOrgan(wareHouse) {
      this.clearFilter();
      var num = this.organLevelNum + 1;
      this.$store.commit('global.changeOrganLevelNum', num);
      this.parentIdList.push(wareHouse.orgId);
    },
    clearFilter: function clearFilter() {
      try {
        document.getElementById('organ-list').scrollTop = 0;
      } catch (e) {
        console.log(e);
      }
      this.finished = false;
      this.loading = false;
      this.queryListParam.keyString = '';
      this.queryListParam.current = 1;
    },
    isShowArrow: function isShowArrow() {
      if (this.orderStockConfig.skipLevel === 1 && (this.user.roleType === 3 || this.user.roleType === 2) && this.$route.params.flag === 1 && this.$route.params.type === 'scanCodeOut' && this.defaultSelect === 0) {
        return true;
      } else {
        return false;
      }
    },
    onLoad: function onLoad() {
      console.log('下拉');
      this.queryListParam.current++;
      if (this.queryListParam.current > this.pageTotal) {
        this.finished = true;
        return;
      }
      this.getOrganList(this.$route.params.organFlag, true);
    },

    // 企业用户不限制  退货单,入库单不限制  允许工厂用户发给经销商时不限制
    showType: function showType() {
      return (this.user.roleType === 2 || this.$route.params.type === 'inStockOrder' || this.$route.params.type === 'returnOrder' || this.orderStockConfig.factoryToDealer === 1 && this.user.roleType === 4 && this.$route.params.flag === 1 && this.$route.params.type === 'scanCodeOut') && this.$route.params.type !== 'traceAudit';
    },
    filterData: function filterData() {
      this.queryListParam.current = 1;
      /* this.queryListParam.parentId = '' */
      try {
        document.getElementById('organ-list').scrollTop = 0;
      } catch (e) {
        console.log(e);
      }
      this.finished = false;
      this.getOrganList(this.$route.params.organFlag);
      /* if (this.search.keyword === '') {
        this.organList[0].children = this.organListTemp.org0
        this.organList[1].children = this.organListTemp.org1
        this.organList[2].children = this.organListTemp.org2
        return
      }
      console.log(this.organListTemp.org0)
      console.log(this.organListTemp.org1)
      console.log(this.organListTemp.org2)
      this.organList[0].children = this.organListTemp.org0.filter((item) => {
        return item.orgName.indexOf(this.search.keyword) !== -1 || item.warehouseName.indexOf(this.search.keyword) !== -1
      })
      this.organList[1].children = this.organListTemp.org1.filter((item) => {
        return item.orgName.indexOf(this.search.keyword) !== -1 || item.warehouseName.indexOf(this.search.keyword) !== -1
      })
      this.organList[2].children = this.organListTemp.org2.filter((item) => {
        return item.orgName.indexOf(this.search.keyword) !== -1 || item.warehouseName.indexOf(this.search.keyword) !== -1
      }) */
    },
    selectWareHouse: function selectWareHouse(item) {
      var num = this.organLevelNum - 1;
      this.$store.commit('global.changeOrganLevelNum', num);
      var wareHouseInfo = {};
      wareHouseInfo.id = item.warehouseId;
      wareHouseInfo.warehouseName = item.warehouseName;
      var organInfo = {};
      organInfo.id = item.orgId;
      organInfo.name = item.orgName;
      if (this.$route.params.flag === 0) {
        this.$store.commit('global.changeOutWareHouseInfo', wareHouseInfo);
        this.$store.commit('global.changeOutOrganInfo', organInfo);
        /* this.$store.commit('global.changeOutWareHouseInfo', item) */
      } else {
        this.$store.commit('global.changeInWareHouseInfo', wareHouseInfo);
        this.$store.commit('global.changeInOrganInfo', organInfo);
      }
      window.history.go(-1);
    },
    addClass: function addClass(data, num) {
      this.$nextTick(function () {
        if (document.getElementsByClassName('van-dropdown-item__content')[0] !== undefined) {
          console.log(data);
          document.getElementsByClassName('van-dropdown-item__content')[0].children[num].style.display = data;
        }
      });
    },
    openDropdownMenu: function openDropdownMenu() {
      this.addClass('', 0);
      this.addClass('', 1);
      // 如果是登陆用户是企业,而且是出库单,扫码出库应用,且为接收组织选项,那么不展示工厂
      // 如果是登陆用户是企业,而且是出库单,扫码出库应用,且为发货组织选项,那么不展示经销商
      if (this.user.roleType === 2 && this.$route.params.flag === 1 && this.$route.params.type === 'scanCodeOut') {
        console.log(1);
        this.addClass('none', 1);
      } else if (this.user.roleType === 2 && this.$route.params.flag === 0 && this.$route.params.type === 'scanCodeOut') {
        console.log(2);
        this.addClass('none', 0);
      }
    },
    clearOrganData: function clearOrganData() {
      var _iteratorNormalCompletion = true;
      var _didIteratorError = false;
      var _iteratorError = undefined;

      try {
        for (var _iterator = (0, _getIterator3.default)(this.organList), _step; !(_iteratorNormalCompletion = (_step = _iterator.next()).done); _iteratorNormalCompletion = true) {
          var organ = _step.value;

          organ.children = [];
        }
      } catch (err) {
        _didIteratorError = true;
        _iteratorError = err;
      } finally {
        try {
          if (!_iteratorNormalCompletion && _iterator.return) {
            _iterator.return();
          }
        } finally {
          if (_didIteratorError) {
            throw _iteratorError;
          }
        }
      }
    },
    getOrganList: function getOrganList(data, flag) {
      var _this = this;

      switch (this.defaultSelect) {
        case 0:
          this.queryListParam.orgType = 3;
          break;
        case 1:
          this.queryListParam.orgType = 2;
          break;
        case 2:
          this.queryListParam.orgType = 0;
          break;
      }
      this.queryListParam.parentId = this.parentIdList.length > 0 ? this.parentIdList[this.parentIdList.length - 1] : this.user.roleType === 2 && this.defaultSelect === 0 && this.$route.params.type === 'scanCodeOut' ? this.user.orgId : '';
      var url = this.$commonApi.common.directLowerOrg;
      if (data === 1) {
        url = this.$commonApi.common.EqualOrg;
      } else if (data === 2) {
        url = this.$commonApi.common.currentOrg;
        console.log(this.user);
      } else if (this.$route.params.type === 'traceAudit') {
        // 溯源稽应用查经销商
        this.defaultSelect = 0;
        this.queryListParam.orgType = 3;
        url = this.$commonApi.common.directLowerOrgOrAll;
      }
      // 跨级发货
      if (this.orderStockConfig.skipLevel === 1 && (this.user.roleType === 3 || this.user.roleType === 2) && this.$route.params.flag === 1 && this.$route.params.type === 'scanCodeOut') {
        url = this.$commonApi.common.allLowerOrg;
      }
      // 工厂发货给经销商
      if (this.orderStockConfig.factoryToDealer === 1 && this.user.roleType === 4 && this.$route.params.flag === 1 && this.$route.params.type === 'scanCodeOut') {
        url = this.$commonApi.common.factoryAndDealer;
      }
      this.queryListParam.orgId = '';
      if (this.$route.params.orgId !== undefined) {
        this.queryListParam.orgId = this.$route.params.orgId;
      }
      if (this.$route.params.flag === 0) {
        this.queryListParam.displayFlag = false;
      } else {
        this.queryListParam.displayFlag = true;
      }
      this.$backend.request(url, this.queryListParam).then(function (result) {
        _this.loading = false;
        if (result) {
          _this.pageTotal = Math.ceil(result.total / _this.queryListParam.rows);
          if (!flag) {
            _this.clearOrganData();
          }
          if (_this.$route.params.type === 'traceAudit') {
            result.rows.forEach(function (item) {
              if (item.orgName === null) {
                item.orgName = '';
              }
              if (item.warehouseName === null) {
                item.warehouseName = '';
              }
              _this.organList[0].children.push(item);
            });
          } else {
            result.rows.forEach(function (item) {
              if (item.orgName === null) {
                item.orgName = '';
              }
              if (item.warehouseName === null) {
                item.warehouseName = '';
              }
              if (item.orgType === 0) {
                _this.organList[2].children.push(item);
              } else if (item.orgType === 2) {
                _this.organList[1].children.push(item);
              } else {
                _this.organList[0].children.push(item);
              }
            });
          }
        } else {
          (0, _vant.Toast)(result.message);
        }
      });
    }
  }
};

/***/ }),

/***/ "TDeA":
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _typeof2 = __webpack_require__("pFYg");

var _typeof3 = _interopRequireDefault(_typeof2);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = {
  //   判断中英文字符串长度 并截取对应长度的字符串
  //     * @param  {[type]} str    [字符串]
  // * @param  {[type]} length [要截取的长度,如果不填写则不截图 默认返回字符串长度]
  // * @return {[type]}        [字符串长度或截取后的字符串]
  subStrLength: function subStrLength(str, startLen, endLen) {
    if (str === undefined || str === null || !str) {
      return 0;
    }
    var byteLen = 0;
    var subStr = '';
    var len = str.length;
    if (typeof startLen === 'number') {
      if (typeof endLen === 'number') {
        for (var _i = 0; _i < len; _i++) {
          byteLen += str.charCodeAt(_i) > 255 ? 2 : 1;
          if (byteLen > endLen) {
            return subStr;
          }
          if (byteLen >= startLen) {
            subStr += str.charAt(_i);
          }
        }
      } else {
        for (var _i2 = 0; _i2 < len; _i2++) {
          byteLen += str.charCodeAt(_i2) > 255 ? 2 : 1;
          if (byteLen > startLen) {
            return subStr;
          }
          subStr += str.charAt(_i2);
        }
      }
      return subStr;
    }
    for (var i = 0; i < len; i++) {
      byteLen += str.charCodeAt(i) > 255 ? 2 : 1;
    }
    return byteLen;
  },

  /**
     * 字符串第一个字母转大写
     */
  firstLetterToUpperCase: function firstLetterToUpperCase(str) {
    if (typeof str !== 'string') {
      return str;
    }
    return str.toString()[0].toUpperCase() + str.toString().slice(1);
  },

  /**
     * 数字转添加间隔符的字符串  如1234567 转换后就是1,234,567
     * @param  {[type]} num       [description]
     * @param  {[type]} separator [description]
     * @return {[type]}           [description]
     */
  numberToString: function numberToString(num, separator) {
    if (num === undefined || isNaN(num)) {
      return '';
    }
    var str = num + '';
    str = str.split('').reverse().join('');
    if (str.length > 3) {
      var newStr = '';
      for (var i = 0; i < parseInt(str.length / 3) + 1; i++) {
        newStr += str.substring(i * 3, str.length < (i + 1) * 3 ? str.length : (i + 1) * 3) + separator;
      }
      if (str.length % 3 === 0) {
        newStr = newStr.substring(0, newStr.length - 1);
      }
      return newStr.substring(0, newStr.length - 1).split('').reverse().join('');
    }
    return num;
  },
  // 判断字符串是否为空
  isEmpty: function isEmpty(str) {
    if (str instanceof Array) {
      return str.length === 0;
    }
    if (typeof str === 'number') {
      str = str + '';
    }
    if (str !== undefined && str !== null && str !== '') {
      return false;
    }
    return true;
  },
  guid: function guid() {
    return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function (c) {
      var r = Math.random() * 16 | 0;
      var v = c === 'x' ? r : r & 0x3 | 0x8;
      return v.toString(16);
    });
  },
  getUUID: function getUUID() {
    var guid = this.guid();
    return guid.replace(/-/g, '');
  },
  isString: function isString(str) {
    return str instanceof String || (typeof str === 'undefined' ? 'undefined' : (0, _typeof3.default)(str)).toLowerCase() === 'string';
  }
};

/***/ }),

/***/ "W7eX":
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _instance = __webpack_require__("4J5h");

var _instance2 = _interopRequireDefault(_instance);

var _handler = __webpack_require__("NpB5");

var _handler2 = _interopRequireDefault(_handler);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

(0, _handler2.default)(_instance2.default);

exports.default = _instance2.default;

/***/ }),

/***/ "XHtf":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
Object.defineProperty(__webpack_exports__, "__esModule", { value: true });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__babel_loader_node_modules_vue_loader_lib_selector_type_script_index_0_PageTransition_vue__ = __webpack_require__("F7Wx");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__babel_loader_node_modules_vue_loader_lib_selector_type_script_index_0_PageTransition_vue___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0__babel_loader_node_modules_vue_loader_lib_selector_type_script_index_0_PageTransition_vue__);
/* harmony namespace reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in __WEBPACK_IMPORTED_MODULE_0__babel_loader_node_modules_vue_loader_lib_selector_type_script_index_0_PageTransition_vue__) if(__WEBPACK_IMPORT_KEY__ !== 'default') (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return __WEBPACK_IMPORTED_MODULE_0__babel_loader_node_modules_vue_loader_lib_selector_type_script_index_0_PageTransition_vue__[key]; }) }(__WEBPACK_IMPORT_KEY__));
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__node_modules_vue_loader_lib_template_compiler_index_id_data_v_1b1f73ed_hasScoped_true_transformToRequire_video_src_poster_source_src_img_src_image_xlink_href_buble_transforms_node_modules_vue_loader_lib_selector_type_template_index_0_PageTransition_vue__ = __webpack_require__("M7S5");
function injectStyle (ssrContext) {
  __webpack_require__("t3Hx")
}
var normalizeComponent = __webpack_require__("VU/8")
/* script */


/* template */

/* template functional */
var __vue_template_functional__ = false
/* styles */
var __vue_styles__ = injectStyle
/* scopeId */
var __vue_scopeId__ = "data-v-1b1f73ed"
/* moduleIdentifier (server only) */
var __vue_module_identifier__ = null
var Component = normalizeComponent(
  __WEBPACK_IMPORTED_MODULE_0__babel_loader_node_modules_vue_loader_lib_selector_type_script_index_0_PageTransition_vue___default.a,
  __WEBPACK_IMPORTED_MODULE_1__node_modules_vue_loader_lib_template_compiler_index_id_data_v_1b1f73ed_hasScoped_true_transformToRequire_video_src_poster_source_src_img_src_image_xlink_href_buble_transforms_node_modules_vue_loader_lib_selector_type_template_index_0_PageTransition_vue__["a" /* default */],
  __vue_template_functional__,
  __vue_styles__,
  __vue_scopeId__,
  __vue_module_identifier__
)

/* harmony default export */ __webpack_exports__["default"] = (Component.exports);


/***/ }),

/***/ "a4s+":
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = {
  // 计算2点之间直线中所有的坐标,
  // * len 是取其中多少的坐标数
  // * order 取值的顺序 true:升序 false:降序
  getCoordinates: function getCoordinates(a, b) {
    var dx = void 0;
    var dy = void 0;
    var h = void 0;
    var x = void 0;
    var y = void 0;
    var t = void 0;
    var ret = [];
    if (a.x > b.x) {
      a.x = [b.x, b.x = a.x][0];
      a.y = [b.y, b.y = a.y][0];
    }
    dx = b.x - a.x;
    dy = b.y - a.y;
    x = a.x;
    y = a.y;
    if (!dx) {
      t = a.y > b.y ? -1 : 1;
      while (y !== b.y) {
        ret.push([x, y]);
        y += t;
      }
      return ret.slice(0);
    }
    if (!dy) {
      while (x !== b.x) {
        ret.push([x, y]);
        x++;
      }
      return ret.slice(0);
    }
    if (dy > 0) {
      if (dy <= dx) {
        h = 2 * dy - dx;
        ret.push([x, y]);
        while (x !== b.x) {
          if (h < 0) {
            h += 2 * dy;
          } else {
            y++;
            h += 2 * (dy - dx);
          }
          x++;
          ret.push([x, y]);
        }
      } else {
        h = 2 * dx - dy;
        ret.push([x, y]);
        while (y !== b.y) {
          if (h < 0) {
            h += 2 * dx;
          } else {
            ++x;
            h += 2 * (dx - dy);
          }
          y++;
          ret.push([x, y]);
        }
      }
    } else {
      t = -dy;
      if (t <= dx) {
        h = 2 * dy + dx;
        ret.push([x, y]);
        while (x !== b.x) {
          if (h < 0) {
            h += 2 * (dy + dx);
            y--;
          } else {
            h += 2 * dy;
          }
          x++;
          ret.push([x, y]);
        }
      } else {
        dy = -dy;
        dx = -dx;
        y = b.y;
        x = b.x;
        ret.push([x, y]);
        h = 2 * dx + dy;
        while (y !== a.y) {
          if (h < 0) {
            h += 2 * (dx + dy);
            x--;
          } else {
            h += 2 * dx;
          }
          y++;
          ret.push([x, y]);
        }
      }
    }
    return ret.slice(0);
  },

  // 获取两点之间的直线的角度
  getAngle: function getAngle(a, b) {
    // 两点的x、y值
    var x = b.x - a.x;
    var y = b.y - a.y;
    var hypotenuse = Math.sqrt(Math.pow(x, 2) + Math.pow(y, 2));
    // 斜边长度
    var cos = x / hypotenuse;
    var radian = Math.acos(cos);
    // 求出弧度
    var angle = 180 / (Math.PI / radian);
    // 用弧度算出角度
    if (y < 0) {
      angle = -angle;
    } else if (y === 0 && x < 0) {
      angle = 180;
    }
    return angle;
  },

  // 判断线段是否和矩形相交
  isLineIntersectRectangle: function isLineIntersectRectangle(line, graphics) {
    var lineHeight = line.y0 - line.y1;
    var lineWidth = line.x1 - line.x0; // 计算叉乘
    var c = line.x0 * line.y1 - line.x1 * line.y0;
    if (lineHeight * graphics.leftTopX + lineWidth * graphics.leftTopY + c >= 0 && lineHeight * graphics.rightBottomX + lineWidth * graphics.rightBottomY + c <= 0 || lineHeight * graphics.leftTopX + lineWidth * graphics.leftTopY + c <= 0 && lineHeight * graphics.rightBottomX + lineWidth * graphics.rightBottomY + c >= 0 || lineHeight * graphics.leftTopX + lineWidth * graphics.rightBottomY + c >= 0 && lineHeight * graphics.rightBottomX + lineWidth * graphics.leftTopY + c <= 0 || lineHeight * graphics.leftTopX + lineWidth * graphics.rightBottomY + c <= 0 && lineHeight * graphics.rightBottomX + lineWidth * graphics.leftTopY + c >= 0) {
      if (graphics.leftTopX > graphics.rightBottomX) {
        var temp = graphics.leftTopX;
        graphics.leftTopX = graphics.rightBottomX;
        graphics.rightBottomX = temp;
      }
      if (graphics.leftTopY < graphics.rightBottomY) {
        var _temp = graphics.leftTopY;
        graphics.leftTopY = graphics.rightBottomY;
        graphics.rightBottomY = _temp;
      }
      if (line.x0 < graphics.leftTopX && line.x1 < graphics.leftTopX || line.x0 > graphics.rightBottomX && line.x1 > graphics.rightBottomX || line.y0 > graphics.leftTopY && line.y1 > graphics.leftTopY || line.y0 < graphics.rightBottomY && line.y1 < graphics.rightBottomY) {
        return false;
      } else {
        return true;
      }
    } else {
      return false;
    }
  },

  // 判断图形是否相交
  graphicsIntersection: function graphicsIntersection(graphics1, graphics2) {
    if (graphics1.x > graphics2.x + graphics2.w || graphics2.x > graphics1.x + graphics1.w || graphics1.y > graphics2.y + graphics2.h || graphics2.y > graphics1.y + graphics1.h) {
      return false;
    } else {
      return true;
    }
  },

  // 判断坐标是在特定范围内
  coordinateInScope: function coordinateInScope(coordinate, graphics) {
    if (coordinate.x >= graphics.x && coordinate.x <= graphics.x + graphics.w && coordinate.y >= graphics.y && coordinate.y <= graphics.y + graphics.h) {
      return true;
    } else {
      return false;
    }
  },

  /**
     * 计算当前坐标是否在圆的范围内
     * coordinate 坐标 x y
     * circular 圆的心坐标 x y 半径 r
     */
  coordinateInCircular: function coordinateInCircular(coordinate, circular) {
    if ((circular.x - coordinate.x) * (circular.x - coordinate.x) + (circular.y - coordinate.y) * (circular.y - coordinate.y) < circular.r * circular.r) {
      return true;
    }
    return false;
  },

  /**
     * 通过直线的开始和结束点的左边计算中心点的坐标
     */
  getLineCenterCoordinate: function getLineCenterCoordinate(start, end) {
    return {
      x: (start.x + end.x) / 2,
      y: (start.y + end.y) / 2
    };
  }
};

/***/ }),

/***/ "bBFl":
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _defineProperty2 = __webpack_require__("bOdI");

var _defineProperty3 = _interopRequireDefault(_defineProperty2);

var _getters, _mutations;

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var NS = 'scanOutOrder.';
exports.default = {
  state: {
    scanOutOrder: {
      scanType: { text: '按件出库', value: 0 }, // 扫码模式
      orderType: { text: '全部订单', value: -1 // 订单类型
      } }
  },
  getters: (_getters = {}, (0, _defineProperty3.default)(_getters, NS + 'scanType', function (state) {
    return state.scanOutOrder.scanType;
  }), (0, _defineProperty3.default)(_getters, NS + 'orderType', function (state) {
    return state.scanOutOrder.orderType;
  }), _getters),
  mutations: (_mutations = {}, (0, _defineProperty3.default)(_mutations, NS + 'changeScanType', function (state, scanType) {
    state.scanOutOrder.scanType = scanType;
  }), (0, _defineProperty3.default)(_mutations, NS + 'changeOrderType', function (state, orderType) {
    state.scanOutOrder.orderType = orderType;
  }), _mutations)
};

/***/ }),

/***/ "c+K/":
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = {
  /**
     * 数组求和
     */
  sum: function sum(arr) {
    var count = 0;
    if (arr instanceof Array) {
      for (var i = 0; i < arr.length; i++) {
        if (typeof arr[i] === 'string' || typeof arr[i] === 'number') {
          count += parseFloat(arr[i]);
        }
      }
    }
    return count;
  },
  addItem: function addItem(arr, number) {
    if (arr instanceof Array) {
      for (var i = 0; i < number; i++) {
        arr.push([]);
      }
      return arr;
    }
    return arr;
  },

  /**
     * 数组每项的值为空则用_now对应的值替换
     */
  replaceItem: function replaceItem(_old, _now) {
    if (_old instanceof Array && _now instanceof Array) {
      for (var i = 0; i < _old.length; i++) {
        if (this.$util.stringUtil.isEmpty(_old[i]) && _now.length > i) {
          _old[i] = _now[i];
        }
      }
    }
    return _old;
  },

  /**
     * 数组去重复
     * @param arr {type=Array} 要去重复的数组
     */
  unique: function unique(arr) {
    var result = [];
    var hash = {};
    for (var i = 0, elem; (elem = arr[i]) != null; i++) {
      if (!hash[elem]) {
        result.push(elem);
        hash[elem] = true;
      }
    }
    return result;
  },

  /**
     * 数组赋值 适用于值得数组
     * @author Bruce.yang
     * @param {Array} arr 数组
     * @param {String} val 要赋予的值
     * @return {Array} 返回改变值后的数组
     */
  changeValue: function changeValue(arr, val) {
    arr.forEach(function (dom, index) {
      arr[index] = val;
    });
    return arr;
  },

  /**
     * @desc 数组转树
     * @param {Array} arr - 需要转化的数组
     * @param {String} id - 节点 ID
     * @param {String} pId - 父节点 ID
     * @param {String} children - 子级属性名
     * @return {Array} 返回树结构数组
     */
  arrayToTree: function arrayToTree(arr) {
    var id = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 'id';
    var pId = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : 'pId';
    var children = arguments.length > 3 && arguments[3] !== undefined ? arguments[3] : 'children';

    var res = [];
    var hash = {};
    var len = 0;
    if (arr && arr.length > 0) {
      len = arr.length;
    }
    for (var i = 0; i < len; i++) {
      hash[arr[i][id]] = arr[i];
    }
    for (var j = 0; j < len; j++) {
      var obj = arr[j];
      var hashVP = hash[obj[pId]];
      if (hashVP) {
        !hashVP[children] && (hashVP[children] = []);
        hashVP[children].push(obj);
      } else {
        res.push(obj);
      }
    }
    return res;
  },
  remove: function remove(arr, val) {
    var index = arr.indexOf(val);
    if (index > -1) {
      arr.splice(index, 1);
    }
  },

  // 根据field进行分组
  groupArr: function groupArr(list, field, name, code) {
    var fieldList = [];
    var att = [];
    list.map(function (e) {
      fieldList.push(e[field]);
    });
    fieldList = fieldList.filter(function (e, i, self) {
      return self.indexOf(e) === i;
    });
    for (var j = 0; j < fieldList.length; j++) {
      var arr = list.filter(function (e) {
        return e[field] === fieldList[j];
      });
      att.push({
        name: arr[0][name],
        code: arr[0][code],
        list: arr
      });
    }
    return att;
  }
};

/***/ }),

/***/ "dHgB":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
Object.defineProperty(__webpack_exports__, "__esModule", { value: true });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__babel_loader_node_modules_vue_loader_lib_selector_type_script_index_0_scanCodeRecord_vue__ = __webpack_require__("dwwW");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__babel_loader_node_modules_vue_loader_lib_selector_type_script_index_0_scanCodeRecord_vue___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0__babel_loader_node_modules_vue_loader_lib_selector_type_script_index_0_scanCodeRecord_vue__);
/* harmony namespace reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in __WEBPACK_IMPORTED_MODULE_0__babel_loader_node_modules_vue_loader_lib_selector_type_script_index_0_scanCodeRecord_vue__) if(__WEBPACK_IMPORT_KEY__ !== 'default') (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return __WEBPACK_IMPORTED_MODULE_0__babel_loader_node_modules_vue_loader_lib_selector_type_script_index_0_scanCodeRecord_vue__[key]; }) }(__WEBPACK_IMPORT_KEY__));
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__node_modules_vue_loader_lib_template_compiler_index_id_data_v_362e8e77_hasScoped_true_transformToRequire_video_src_poster_source_src_img_src_image_xlink_href_buble_transforms_node_modules_vue_loader_lib_selector_type_template_index_0_scanCodeRecord_vue__ = __webpack_require__("uAb1");
function injectStyle (ssrContext) {
  __webpack_require__("IUrY")
}
var normalizeComponent = __webpack_require__("VU/8")
/* script */


/* template */

/* template functional */
var __vue_template_functional__ = false
/* styles */
var __vue_styles__ = injectStyle
/* scopeId */
var __vue_scopeId__ = "data-v-362e8e77"
/* moduleIdentifier (server only) */
var __vue_module_identifier__ = null
var Component = normalizeComponent(
  __WEBPACK_IMPORTED_MODULE_0__babel_loader_node_modules_vue_loader_lib_selector_type_script_index_0_scanCodeRecord_vue___default.a,
  __WEBPACK_IMPORTED_MODULE_1__node_modules_vue_loader_lib_template_compiler_index_id_data_v_362e8e77_hasScoped_true_transformToRequire_video_src_poster_source_src_img_src_image_xlink_href_buble_transforms_node_modules_vue_loader_lib_selector_type_template_index_0_scanCodeRecord_vue__["a" /* default */],
  __vue_template_functional__,
  __vue_styles__,
  __vue_scopeId__,
  __vue_module_identifier__
)

/* harmony default export */ __webpack_exports__["default"] = (Component.exports);


/***/ }),

/***/ "di9n":
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _extends2 = __webpack_require__("Dd8w");

var _extends3 = _interopRequireDefault(_extends2);

var _vuex = __webpack_require__("SJI6");

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = {
  name: 'sureOrder',
  computed: (0, _extends3.default)({}, (0, _vuex.mapGetters)({
    outOrganInfo: 'global.outOrganInfo',
    inOrganInfo: 'global.inOrganInfo',
    outWareHouseInfo: 'global.outWareHouseInfo',
    inWareHouseInfo: 'global.inWareHouseInfo',
    isInitScanView: 'global.isInitScanView',
    user: 'global.user'
  })),
  data: function data() {
    return {};
  },
  activated: function activated() {},
  deactivated: function deactivated() {},
  created: function created() {},

  components: {},
  methods: {
    toHistory: function toHistory() {
      this.$router.push({ name: 'scanCodeRecord' });
    },
    toScan: function toScan() {
      if (this.$util.common.ObjectUtils.isObj(this.inWareHouseInfo)) {
        this.$util.business.AppUtils.openMessageBox('提示', '', '仓库不能为空', '', '确定', false, function (result) {});
        return;
      }
      this.$router.push({ name: 'scanCode' });
    },
    toSelectOrgan: function toSelectOrgan(data) {
      this.$router.push({ name: 'selectOrgan', params: { flag: data, organFlag: 2, orgId: this.user.orgId } });
    }
  },
  watch: {}
}; //
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

/***/ }),

/***/ "dwwW":
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _extends2 = __webpack_require__("Dd8w");

var _extends3 = _interopRequireDefault(_extends2);

var _vuex = __webpack_require__("SJI6");

var _vant = __webpack_require__("Fd2+");

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

exports.default = {
  name: 'scanRecord',
  computed: (0, _extends3.default)({}, (0, _vuex.mapGetters)({})),
  data: function data() {
    return {
      scanRecordList: [],
      search: {
        operateType: ''
      }
    };
  },
  activated: function activated() {
    this.getScanRecordList();
    /* for (let i = 0; i < 10; i++) {
      this.scanRecordList.push({code: i})
    } */
  },
  deactivated: function deactivated() {},
  created: function created() {},

  methods: {
    getScanRecordList: function getScanRecordList() {
      var _this = this;

      /* this.search.inOrgId = this.outOrganInfo.id */
      this.search.operateType = '17';
      this.$backend.request(this.$api.scanCodeIn.scanRecord, this.search).then(function (result) {
        if (result.success) {
          _this.scanRecordList = result.data;
        } else {
          (0, _vant.Toast)(result.message);
        }
      });
    }
  }
};

/***/ }),

/***/ "f/Qh":
/***/ (function(module, exports) {

module.exports = VueResource;

/***/ }),

/***/ "f5zX":
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _keys = __webpack_require__("fZjL");

var _keys2 = _interopRequireDefault(_keys);

var _getIterator2 = __webpack_require__("BO1k");

var _getIterator3 = _interopRequireDefault(_getIterator2);

var _map = __webpack_require__("ifoU");

var _map2 = _interopRequireDefault(_map);

var _typeof2 = __webpack_require__("pFYg");

var _typeof3 = _interopRequireDefault(_typeof2);

var _vant = __webpack_require__("Fd2+");

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = {
  // 对象拷贝
  deepCopy: function deepCopy(p, d) {
    var c = void 0;
    if (p instanceof Array) {
      c = d || [];
    } else {
      c = d || {};
    }
    for (var i in p) {
      if ((0, _typeof3.default)(p[i]) === 'object' && p[i] !== null) {
        c[i] = p[i].constructor === Array ? [] : {};
        this.deepCopy(p[i], c[i]);
      } else {
        c[i] = p[i];
      }
    }
    return c;
  },

  // es6 Map
  // json对象转Map对象
  jsonToMap: function jsonToMap(obj) {
    var newMap = new _map2.default();
    var _iteratorNormalCompletion = true;
    var _didIteratorError = false;
    var _iteratorError = undefined;

    try {
      for (var _iterator = (0, _getIterator3.default)((0, _keys2.default)(obj)), _step; !(_iteratorNormalCompletion = (_step = _iterator.next()).done); _iteratorNormalCompletion = true) {
        var k = _step.value;

        newMap.set(obj[k][0], obj[k][1]);
      }
    } catch (err) {
      _didIteratorError = true;
      _iteratorError = err;
    } finally {
      try {
        if (!_iteratorNormalCompletion && _iterator.return) {
          _iterator.return();
        }
      } finally {
        if (_didIteratorError) {
          throw _iteratorError;
        }
      }
    }

    return newMap;
  },
  isObj: function isObj(obj) {
    var arr = (0, _keys2.default)(obj);
    return arr.length === 0;
  },
  copy: function copy(data) {
    var range = document.createRange();
    range.selectNode(document.getElementById(data));
    var selection = window.getSelection();
    if (selection.rangeCount > 0) selection.removeAllRanges();
    selection.addRange(range);
    (0, _vant.Toast)('成功复制到剪切板');
    document.execCommand('copy');
  },

  // 复制成功
  onCopySuccess: function onCopySuccess(e) {
    (0, _vant.Toast)('成功复制到剪切板！');
  },

  // 复制失败
  onCopyError: function onCopyError(e) {
    (0, _vant.Toast)('复制失败！');
  },
  getImgToBase64: function getImgToBase64(url, callback) {
    var canvas = document.createElement('canvas');
    var ctx = canvas.getContext('2d');
    var img = new Image();
    img.crossOrigin = 'Anonymous';
    img.onload = function () {
      canvas.height = img.height;
      canvas.width = img.width;
      ctx.drawImage(img, 0, 0);
      var dataURL = canvas.toDataURL('image/png');
      callback(dataURL);
      canvas = null;
    };
    img.src = url;
  },
  dataURLtoFile: function dataURLtoFile(dataurl, filename) {
    var arr = dataurl.split(',');var mime = arr[0].match(/:(.*?);/)[1];
    var bstr = atob(arr[1]);var n = bstr.length;var u8arr = new Uint8Array(n);
    while (n--) {
      u8arr[n] = bstr.charCodeAt(n);
    }
    return new File([u8arr], filename, { type: mime });
  },
  filterCode: function filterCode(operateCode) {
    for (var code in operateCode) {
      if (operateCode[code] !== null) {
        return code === 'qcc' ? operateCode[code].tpid : operateCode[code];
      }
    }
  }
};

/***/ }),

/***/ "f6Gb":
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _defineProperty2 = __webpack_require__("bOdI");

var _defineProperty3 = _interopRequireDefault(_defineProperty2);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var NS = 'batchSearch.';

exports.default = {
  state: {
    batchSearch: {
      chosenStock: null // 选择库存统计
    }
  },
  getters: (0, _defineProperty3.default)({}, NS + 'chosenStock', function (state) {
    return state.batchSearch.chosenStock;
  }),
  mutations: (0, _defineProperty3.default)({}, NS + 'changeChosenStock', function (state, stock) {
    state.batchSearch.chosenStock = stock;
  })
};

/***/ }),

/***/ "f7If":
/***/ (function(module, exports, __webpack_require__) {

"use strict";


module.exports = {
  // 打包关联
  scanCodeIn: {
    // 无单收货
    scanIn: {
      path: '/scanOutIn/scanInByPiece',
      method: 'put',
      server: 'code'
    },
    // 扫码记录
    scanRecord: {
      path: '/codeLog/scanOutInBatch',
      method: 'get',
      server: 'code'
    },
    // 组织列表
    directLowerOrg: {
      path: '/organization/directLowerOrg',
      method: 'GET',
      server: 'user'
    },
    // 根据id获取仓库列表
    getWarehouseList: {
      path: '/warehouse/orgWarehouse',
      method: 'GET',
      server: 'base'
    }
  }
};

/***/ }),

/***/ "hCOg":
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
// import api from '../../conf/api'
// import backend from '../../utils/backend'

exports.default = {
  // 查询企业下所有码段
  // initAllCodeSegment () {
  //   return backend.request(api.Pack.getAllCodeSegment, {}).then((res) => {
  //     this.$util.business.LocalUtils.setCodeSegmnet(res)
  //   })
  // }
};

/***/ }),

/***/ "hDMw":
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _stringify = __webpack_require__("mvHQ");

var _stringify2 = _interopRequireDefault(_stringify);

var _typeof2 = __webpack_require__("pFYg");

var _typeof3 = _interopRequireDefault(_typeof2);

var _vue = __webpack_require__("lRwf");

var _vue2 = _interopRequireDefault(_vue);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var LOGIN_USER = 'LOGIN_USER';

exports.default = {
  setLoginUser: function setLoginUser(user) {
    if ((typeof user === 'undefined' ? 'undefined' : (0, _typeof3.default)(user)) === 'object') {
      _vue2.default.http.headers.common['Authorization'] = user.token;
      _vue2.default.http.headers.common['Username'] = user.username;
      _vue2.default.http.headers.common['TenantId'] = user.tenantId;
      window.sessionStorage.setItem(LOGIN_USER, (0, _stringify2.default)(user));
    } else {
      window.sessionStorage.setItem(LOGIN_USER, '');
    }
  },
  getLoginUser: function getLoginUser() {
    var jsonstr = window.sessionStorage.getItem(LOGIN_USER);
    if (jsonstr && jsonstr !== '') {
      try {
        return JSON.parse(jsonstr);
      } catch (e) {
        console.error(e);
        return null;
      }
    }
    return null;
  },

  // @desc 将数据存进 sessionStorage 里
  // @param {String} key - 存储的 key
  // @param {Object|String|Number|Boolean} value - 需要存储的数据
  setData: function setData(key, value) {
    if (typeof key !== 'string') {
      throw new Error('key must be a string!');
    }
    if ((typeof value === 'undefined' ? 'undefined' : (0, _typeof3.default)(value)) === 'object') {
      value = (0, _stringify2.default)(value);
    }
    window.sessionStorage.setItem(key, value);
  },

  // @desc 获取 sessionStorage 里存储的数据
  // @param {String} key - 通过 key 获取对于的数据
  getData: function getData(key) {
    if (typeof key !== 'string') {
      throw new Error('key must be a string!');
    }
    try {
      return JSON.parse(window.sessionStorage.getItem(key));
    } catch (e) {
      return window.sessionStorage.getItem(key);
    }
  }
};

/***/ }),

/***/ "i2KX":
/***/ (function(module, exports) {

// removed by extract-text-webpack-plugin

/***/ }),

/***/ "i8Gx":
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = {
  // 计算时间差
  getDatePoor: function getDatePoor(start, end) {
    end = end || new Date();
    var startTime = new Date(start).getTime();
    var endTime = new Date(end).getTime();
    if (startTime > endTime) {
      var curTime = new Date().getTime();
      return curTime - startTime;
    }
    return endTime - startTime;
  },

  // 秒转天时分秒
  secondToDate: function secondToDate(second) {
    if (!second) {
      return '';
    }
    second = parseInt(second);
    var s = 0;
    var m = 0;
    var h = 0;
    var d = 0;
    s = second % 60;
    m = parseInt(second / 60);
    if (m >= 60) {
      h = parseInt(m / 60);
      m = m % 60;
    }
    if (h >= 24) {
      d = parseInt(h / 24);
    }
    h = h % 24;
    if (d !== 0) {
      return d + '天' + h + '时' + m + '分' + s + '秒';
    }
    if (h !== 0) {
      return h + '时' + m + '分' + s + '秒';
    }
    if (m !== 0) {
      return m + '分' + s + '秒';
    }
    return s + '秒';
  },

  // 日期格式化
  dateFormat: function dateFormat() {
    var date = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : new Date();
    var fmt = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 'yyyy-MM-dd hh:mm:ss';

    date = typeof date === 'number' ? new Date(date) : date;
    var o = {
      'M+': date.getMonth() + 1,
      'd+': date.getDate(),
      'h+': date.getHours(),
      'm+': date.getMinutes(),
      's+': date.getSeconds(),
      'q+': Math.floor((date.getMonth() + 3) / 3),
      'S': date.getMilliseconds()
    };
    if (/(y+)/.test(fmt)) {
      fmt = fmt.replace(RegExp.$1, (date.getFullYear() + '').substr(4 - RegExp.$1.length));
    }
    for (var k in o) {
      if (new RegExp('(' + k + ')').test(fmt)) {
        fmt = fmt.replace(RegExp.$1, RegExp.$1.length === 1 ? o[k] : ('00' + o[k]).substr(('' + o[k]).length));
      }
    }
    return fmt;
  },

  // 添加减少年  返回新的日期对象
  addYear: function addYear(date) {
    var year = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 0;

    if (Math.abs(year) === 0) {
      return date;
    }
    return new Date(date.getFullYear() + year, date.getMonth(), date.getDate(), date.getHours(), date.getMinutes(), date.getSeconds());
  },

  /**
     * 添加减少月  返回新的日期对象
     */
  addMonth: function addMonth(date) {
    var month = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 0;

    if (Math.abs(month) === 0) {
      return date;
    }
    return new Date(date.getFullYear(), date.getMonth() + month, date.getDate(), date.getHours(), date.getMinutes(), date.getSeconds());
  },

  /**
     * 添加减少天数  返回新的日期对象
     */
  addDate: function addDate(date) {
    var days = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 0;

    if (Math.abs(days) === 0) {
      return date;
    }
    return new Date(date.getFullYear(), date.getMonth(), date.getDate() + days, date.getHours(), date.getMinutes(), date.getSeconds());
  },

  /**
     * 添加减少小时  返回新的日期对象
     */
  addHour: function addHour(date) {
    var hour = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 0;

    if (Math.abs(hour) === 0) {
      return date;
    }
    return new Date(date.getFullYear(), date.getMonth(), date.getDate(), date.getHours() + hour, date.getMinutes(), date.getSeconds());
  },

  /**
     * 添加减少分钟  返回新的日期对象
     */
  addMinute: function addMinute(date) {
    var minute = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 0;

    if (Math.abs(minute) === 0) {
      return date;
    }
    return new Date(date.getFullYear(), date.getMonth(), date.getDate(), date.getHours(), date.getMinutes() + minute, date.getSeconds());
  },

  /**
     * 添加减少秒钟  返回新的日期对象
     */
  addSecond: function addSecond(date) {
    var second = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 0;

    if (Math.abs(second) === 0) {
      return date;
    }
    return new Date(date.getFullYear(), date.getMonth(), date.getDate(), date.getHours(), date.getMinutes(), date.getSeconds() + second);
  },
  dateFormat2: function dateFormat2(d, istime) {
    if (!d) return null;
    if (typeof d === 'number') {
      d = new Date(d);
    }
    var year = d.getFullYear();
    var month = this.fixzero(d.getMonth() + 1, 2);
    var date = this.fixzero(d.getDate(), 2);
    var str = year + '-' + month + '-' + date;
    if (istime) {
      var hour = this.fixzero(d.getHours(), 2);
      var min = this.fixzero(d.getMinutes(), 2);
      var sec = this.fixzero(d.getSeconds(), 2);
      str += ' ' + hour + ':' + min + ':' + sec;
    }
    return str;
  },
  dateParse: function dateParse(s, istime) {
    var d = new Date();
    var year = s.substring(0, 4);
    var month = s.substring(5, 7) - 1;
    var date = s.substring(8, 10);
    d.setFullYear(year, month, date);
    if (istime) {
      var hour = s.substring(11, 13);
      var min = s.substring(14, 16);
      var sec = s.substring(17, 19);
      d.setHours(hour, min, sec, 0);
    }
    return d;
  },

  /**
     * 补零
     */
  fixzero: function fixzero(s, size) {
    s = s.toString();
    if (s.length === size) return s;
    var dest = '';
    for (var i = 0; i < size - s.length; i++) {
      dest += '0';
    }
    return dest + s;
  },

  // 获取 近七天sevenDays 近一月oneMonth 近三月threeMonth 近六月sixMonth
  getTimeRegion: function getTimeRegion(flag) {
    var fmt = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 'yyyy-MM-dd hh:mm:ss';

    var date = new Date();
    var time = '';
    switch (flag) {
      case 'sevenDays':
        time = this.dateFormat(new Date(date.getTime() - 7 * 24 * 60 * 60 * 1000), fmt);
        break;
      case 'oneMonth':
        time = this.dateFormat(new Date(date.getTime() - 30 * 24 * 60 * 60 * 1000));
        break;
      case 'threeMonth':
        time = this.dateFormat(new Date(date.getTime() - 90 * 24 * 60 * 60 * 1000));
        break;
      case 'sixMonth':
        time = this.dateFormat(new Date(date.getTime() - 180 * 24 * 60 * 60 * 1000));
        break;
    }
    return time;
  },
  forMatData: function forMatData(date) {
    // 补0   例如 2018/7/10 14:7:2  补完后为 2018/07/10 14:07:02
    function addZero(num) {
      if (num < 10) {
        return '0' + num;
      }
      return num;
    }
    // 按自定义拼接格式返回
    return date.getFullYear() + '-' + addZero(date.getMonth() + 1) + '-' + addZero(date.getDate()) + ' ' + addZero(date.getHours()) + ':' + addZero(date.getMinutes()) + ':' + addZero(date.getSeconds());
  }
};

/***/ }),

/***/ "ivU6":
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
// import store from '../../store'
// import api from '../../conf/api'
// import backend from '../backend'

exports.default = {
  logout: function logout() {
    // store.dispatch('global.setUser', null)
    // backend.request(api.user.logout)
  }
};

/***/ }),

/***/ "jFiy":
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var _object = __webpack_require__("f5zX");

var _object2 = _interopRequireDefault(_object);

var _date = __webpack_require__("i8Gx");

var _date2 = _interopRequireDefault(_date);

var _string = __webpack_require__("TDeA");

var _string2 = _interopRequireDefault(_string);

var _dom = __webpack_require__("CS8j");

var _dom2 = _interopRequireDefault(_dom);

var _formula = __webpack_require__("a4s+");

var _formula2 = _interopRequireDefault(_formula);

var _canvas = __webpack_require__("ph76");

var _canvas2 = _interopRequireDefault(_canvas);

var _array = __webpack_require__("c+K/");

var _array2 = _interopRequireDefault(_array);

var _convert = __webpack_require__("4D68");

var _convert2 = _interopRequireDefault(_convert);

var _number = __webpack_require__("Mlnd");

var _number2 = _interopRequireDefault(_number);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

module.exports = {
  ObjectUtils: _object2.default,
  DateUtils: _date2.default,
  StringUtils: _string2.default,
  DomUtils: _dom2.default,
  FormulaUtils: _formula2.default,
  CanvasUtils: _canvas2.default,
  ArrayUtils: _array2.default,
  ConvertUtils: _convert2.default,
  NumberUtils: _number2.default
};

/***/ }),

/***/ "k/Mv":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
var render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('div',{attrs:{"id":"selectOrgan"}},[_c('div',{staticClass:"search-filter"},[(_vm.showType())?_c('van-dropdown-menu',[_c('van-dropdown-item',{attrs:{"options":_vm.organList},on:{"open":_vm.openDropdownMenu,"change":_vm.changeType},model:{value:(_vm.defaultSelect),callback:function ($$v) {_vm.defaultSelect=$$v},expression:"defaultSelect"}})],1):_vm._e(),_vm._v(" "),_c('van-search',{attrs:{"placeholder":"请输入搜索关键词"},on:{"search":_vm.filterData},model:{value:(_vm.queryListParam.keyString),callback:function ($$v) {_vm.$set(_vm.queryListParam, "keyString", $$v)},expression:"queryListParam.keyString"}}),_vm._v(" "),_c('span',{staticClass:"search-button",on:{"click":_vm.filterData}},[_vm._v("搜索")])],1),_vm._v(" "),(_vm.organList[_vm.defaultSelect].children.length>0)?_c('div',{staticClass:"content",attrs:{"id":"organ-list"}},[_c('van-list',{attrs:{"finished":_vm.finished,"finished-text":"没有更多了...","offset":20,"immediate-check":false},on:{"load":_vm.onLoad},model:{value:(_vm.loading),callback:function ($$v) {_vm.loading=$$v},expression:"loading"}},[(_vm.$route.params.type !== 'traceAudit')?_c('ul',{staticClass:"organ-list"},_vm._l((_vm.organList[_vm.defaultSelect].children),function(wareHouse,index){return _c('li',{key:index,staticClass:"flex-between",class:{'active': _vm.$route.params.flag==0?wareHouse.warehouseId===_vm.outWareHouseInfo.id:wareHouse.warehouseId===_vm.inWareHouseInfo.id }},[_c('div',{staticStyle:{"flex":"1"},on:{"click":function($event){return _vm.selectWareHouse(wareHouse)}}},[_c('p',[_vm._v(_vm._s(wareHouse.orgName))]),_vm._v(" "),_c('p',[_vm._v(_vm._s(wareHouse.warehouseName))])]),_vm._v(" "),(_vm.isShowArrow())?_c('div',{staticClass:"min-width-60",staticStyle:{"text-align":"right"}},[_c('span',{staticClass:"arrow-right blue-text",on:{"click":function($event){return _vm.getLowerOrgan(wareHouse)}}},[_vm._v("下级")])]):_vm._e()])}),0):_c('ul',{staticClass:"organ-list"},_vm._l((_vm.organList[_vm.defaultSelect].children),function(wareHouse,index){return _c('li',{key:index,class:{'active': _vm.$route.params.flag==0?wareHouse.orgId===_vm.outOrganInfo.id:wareHouse.orgId===_vm.inOrganInfo.id },on:{"click":function($event){return _vm.selectWareHouse(wareHouse)}}},[_c('p',[_vm._v(_vm._s(wareHouse.orgName))])])}),0)])],1):_c('div',{staticClass:"empty-list"},[_c('img',{attrs:{"src":__webpack_require__("u8EM"),"alt":""}}),_vm._v(" "),_c('p',{staticClass:"gray-text"},[_vm._v("暂无仓库信息")])])])}
var staticRenderFns = []
var esExports = { render: render, staticRenderFns: staticRenderFns }
/* harmony default export */ __webpack_exports__["a"] = (esExports);

/***/ }),

/***/ "kqKe":
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _defineProperty2 = __webpack_require__("bOdI");

var _defineProperty3 = _interopRequireDefault(_defineProperty2);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var NS = 'stockStatistics.';

exports.default = {
  state: {
    stockStatistics: {
      popupVisible: false // 搜索弹出框
    }
  },
  getters: (0, _defineProperty3.default)({}, NS + 'popupVisible', function (state) {
    return state.stockStatistics.popupVisible;
  }),
  mutations: (0, _defineProperty3.default)({}, NS + 'changePopupVisible', function (state, status) {
    state.stockStatistics.popupVisible = status;
  })
};

/***/ }),

/***/ "lRwf":
/***/ (function(module, exports) {

module.exports = Vue;

/***/ }),

/***/ "oXLK":
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var basedata = {
  getFlag: function getFlag() {
    return window.config.forApp;
  }
  /**
     * 请求后端数据
     */
  // request () {
  //   let getAllCodeSegment = backend.request(api.Pack.getAllCodeSegment, {})
  //   let getTempList = backend.request(api.Pack.getTempList, {})
  //   let getAllWrapper = backend.request(api.Pack.selectAllWrapper, {})
  //   return Promise.all([getAllCodeSegment, getTempList, getAllWrapper]).then(result => {
  //     if (result) {
  //       local.setCodeSegment(result[0])
  //       local.setScannedCode(result[1])
  //       local.setAllWrapper(result[2])
  //     } else {
  //       return Promise.reject(result)
  //     }
  //   }, error => {
  //     let err = backend.convertError(error)
  //     return Promise.reject(err)
  //   })
  // }

};

module.exports = {
  basedata: basedata
};

/***/ }),

/***/ "ofE0":
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var _vue = __webpack_require__("lRwf");

var _vue2 = _interopRequireDefault(_vue);

var _app = __webpack_require__("DsYT");

var _app2 = _interopRequireDefault(_app);

var _router = __webpack_require__("W7eX");

var _router2 = _interopRequireDefault(_router);

var _jquery = __webpack_require__("0iPh");

var _jquery2 = _interopRequireDefault(_jquery);

var _vant = __webpack_require__("Fd2+");

var _vant2 = _interopRequireDefault(_vant);

__webpack_require__("4ml/");

var _backend = __webpack_require__("5pKY");

var _backend2 = _interopRequireDefault(_backend);

var _store = __webpack_require__("IcnI");

var _store2 = _interopRequireDefault(_store);

var _index = __webpack_require__("0xDb");

var _index2 = _interopRequireDefault(_index);

var _wholeCodeIn = __webpack_require__("f7If");

var _wholeCodeIn2 = _interopRequireDefault(_wholeCodeIn);

var _common = __webpack_require__("ya2q");

var _common2 = _interopRequireDefault(_common);

var _basedata = __webpack_require__("oXLK");

__webpack_require__("2GmJ");

var _vueClipboard = __webpack_require__("wvfG");

var _vueClipboard2 = _interopRequireDefault(_vueClipboard);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

/* import '../../assets/css/common/index.css' */
// The Vue build version to load with the `import` command
// (runtime-only or standalone) has been set in webpack.base.conf with an alias.
_vue2.default.use(_vueClipboard2.default);
_vue2.default.config.productionTip = false;
_vue2.default.use(_vant2.default);

Object.defineProperty(_vue2.default.prototype, '$backend', {
  get: function get() {
    return _backend2.default;
  }
});

Object.defineProperty(_vue2.default.prototype, '$util', {
  get: function get() {
    return _index2.default;
  }
});

Object.defineProperty(_vue2.default.prototype, '$api', {
  get: function get() {
    return _wholeCodeIn2.default;
  }
});

Object.defineProperty(_vue2.default.prototype, '$commonApi', {
  get: function get() {
    return _common2.default;
  }
});

Object.defineProperty(_vue2.default.prototype, '$basedata', {
  get: function get() {
    return _basedata.basedata;
  }
});

Object.defineProperty(_vue2.default.prototype, '$', {
  get: function get() {
    return _jquery2.default;
  }
});

/* eslint-disable no-new */
new _vue2.default({
  el: '#app',
  store: _store2.default,
  router: _router2.default,
  components: { App: _app2.default },
  template: '<App/>'
});

/***/ }),

/***/ "pRNm":
/***/ (function(module, exports) {

module.exports = VueRouter;

/***/ }),

/***/ "ph76":
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = {
  /**
     * canvas 画图方法
     */
  drawImg: function drawImg(ctx, option) {
    var image = new window.Image();
    image.src = option.src;
    ctx.drawImage(image, option.sx, option.sy, option.sw, option.sh, option.x, option.y, option.w, option.h);
  },
  /**
     * canvas 画图方法 用户画布中画canvas
     */
  drawCanvas: function drawCanvas(ctx, canvas, option) {
    ctx.drawImage(canvas, option.sx, option.sy, option.sw, option.sh, option.x, option.y, option.w, option.h);
  },
  /**
     * canvas 画圆方法
     */
  drawCircular: function drawCircular(ctx, option) {
    ctx.beginPath();
    /**
     * 设置弧线的颜色
     * @type {[type]}
     */
    ctx.strokeStyle = option.strokeStyle;
    /**
          * 设置背景颜色rgba(141, 141, 141, 1)
          * @type {[type]}
          */
    ctx.fillStyle = option.fillStyle;
    /**
      * option.x,    圆心的x轴坐标值
      * option.y,    圆心的y轴坐标值
      * option.r     圆的半径
      */
    var sAngle = option.sAngle || 0;
    var eAngle = option.eAngle || 2;
    ctx.arc(option.x, option.y, option.r, sAngle * Math.PI, eAngle * Math.PI);
    ctx.closePath();
    ctx.stroke();
    ctx.fill();
  },

  /**
     * 画圆角矩形
     * @type {[type]}
     */
  drawRoundedRect: function drawRoundedRect(ctx, temp) {
    var roundedRect = function roundedRect(ctx, x, y, w, h, radius) {
      if (w > 0) {
        ctx.moveTo(x + radius, y);
      } else {
        ctx.moveTo(x - radius, y);
      }
      ctx.arcTo(x + w, y, x + w, y + h, radius);
      ctx.arcTo(x + w, y + h, x, y + h, radius);
      ctx.arcTo(x, y + h, x, y, radius);
      if (w > 0) {
        ctx.arcTo(x, y, x + radius, y, radius);
      } else {
        ctx.arcTo(x, y, x - radius, y, radius);
      }
    };
    ctx.beginPath();
    roundedRect(ctx, temp.x, temp.y, temp.w, temp.h, temp.radius);
    ctx.strokeStyle = temp.strokeStyle;
    ctx.fillStyle = temp.fillStyle;
    ctx.stroke();
    ctx.fill();
  },
  /**
     * canvas 写文字方法
     */
  fillText: function fillText(ctx, option, text, x, y) {
    ctx.font = option.font;
    ctx.fillStyle = option.fillStyle;
    if (option.textAlign) {
      ctx.textAlign = option.textAlign;
    } else {
      ctx.textAlign = 'start';
    }
    if (option.textBaseline) {
      ctx.textBaseline = option.textBaseline;
    } else {
      ctx.textBaseline = 'top';
    }
    ctx.fillText(text, x, y);
  },
  /**
     * canvas 画线
     */
  drawLine: function drawLine(ctx, option) {
    /**
         * 设置填充颜色
         * @type {String}
         */
    ctx.strokeStyle = option.fillStyle;
    ctx.lineWidth = option.lineWidth ? option.lineWidth : 1;
    ctx.beginPath();
    /**
         * 将画笔移到x0,y0处
         */
    ctx.moveTo(option.x0, option.y0);
    /**
         * 从x0,y0到x1,y1画一条线
         */
    ctx.lineTo(option.x1, option.y1);
    ctx.closePath();
    ctx.stroke();
    ctx.fill();
  },
  /**
     * canvas 画横向带箭头的线
     */
  drawArrowLine: function drawArrowLine(ctx, option) {
    /**
         * 设置填充颜色
         * @type {String}
         */
    ctx.strokeStyle = option.fillStyle;
    ctx.lineWidth = option.lineWidth;
    ctx.fillStyle = option.fillStyle;
    ctx.beginPath();
    /**
         * 将画笔移到x0,y0处
         */
    ctx.moveTo(option.x0, option.y0);
    /**
         * 从x0,y0到x1,y1画一条线
         */
    ctx.lineTo(option.x1 - 1, option.y1);
    ctx.closePath();
    ctx.stroke();
    ctx.beginPath();
    /**
         * 从x1,y1画两5像素的条线形成箭头
         */
    ctx.lineTo(option.x1 - option.r, option.y1 + option.r * 2 / 3);
    ctx.lineTo(option.x1 - 1, option.y1);
    ctx.lineTo(option.x1 - option.r, option.y1 - option.r * 2 / 3);
    ctx.closePath();
    ctx.stroke();
    ctx.fill();
  },
  /**
     * 缩放
     */
  resizeImage: function resizeImage(image, width, height) {
    var canvas = document.createElement('canvas');
    var ctx = canvas.getContext('2d');
    canvas.width = width;
    canvas.height = height;
    ctx.drawImage(image, 0, 0, width, height);
    var dataUrl = canvas.toDataURL('image/jpeg');
    var dest = new window.Image();
    dest.src = dataUrl;
    return dest;
  },

  /**
     * 压缩
     */
  compressImage: function compressImage(image) {
    var maxWidth = 1024;
    var maxHeight = 1536;
    var scale = 0;
    var nwidth = image.width;
    var nheight = image.height;
    // 压缩
    if (image.width > maxWidth) {
      nwidth = maxWidth;
      scale = image.width / image.height;
      nheight = parseInt(nwidth / scale);
      image = this.resizeImage(image, nwidth, nheight);
    }
    if (image.height > maxHeight) {
      nheight = maxHeight;
      scale = image.height / image.width;
      nwidth = parseInt(nheight / scale);
      image = this.resizeImage(image, nwidth, nheight);
    }
    var size = image.width * image.height;
    if (size > 1024 * 300) {
      var canvas = document.createElement('canvas');
      var ctx = canvas.getContext('2d');
      canvas.width = image.width;
      canvas.height = image.height;
      ctx.drawImage(image, 0, 0, image.width, image.height);
      var dataUrl = canvas.toDataURL('image/jpeg', 0.9);
      image.src = dataUrl;
    }
    return image;
  }
};

/***/ }),

/***/ "svz7":
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _session = __webpack_require__("hDMw");

var _session2 = _interopRequireDefault(_session);

var _baseData = __webpack_require__("B0cl");

var _baseData2 = _interopRequireDefault(_baseData);

var _local = __webpack_require__("FITS");

var _local2 = _interopRequireDefault(_local);

var _store = __webpack_require__("IcnI");

var _store2 = _interopRequireDefault(_store);

var _backend = __webpack_require__("5pKY");

var _backend2 = _interopRequireDefault(_backend);

var _basedata = __webpack_require__("3pX5");

var _basedata2 = _interopRequireDefault(_basedata);

var _vue = __webpack_require__("lRwf");

var _vue2 = _interopRequireDefault(_vue);

var _mintUi = __webpack_require__("Au9i");

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = {
  /**
    *  初始化JsBridge
    */
  setupWebViewJavascriptBridge: function setupWebViewJavascriptBridge(callback) {
    var u = navigator.userAgent;
    // android终端
    var isAndroid = u.indexOf('Android') > -1 || u.indexOf('Adr') > -1;
    // ios终端
    var isiOS = !!u.match(/\(i[^;]+;( U;)? CPU.+Mac OS X/);
    if (isAndroid) {
      if (window.WebViewJavascriptBridge) {
        callback(window.WebViewJavascriptBridge);
      } else {
        document.addEventListener('WebViewJavascriptBridgeReady', function () {
          callback(window.WebViewJavascriptBridge);
        }, false);
      }
    } else if (isiOS) {
      if (window.WebViewJavascriptBridge) {
        return callback(window.WebViewJavascriptBridge);
      }
      if (window.WVJBCallbacks) {
        return window.WVJBCallbacks.push(callback);
      }
      // 创建一个 WVJBCallbacks 全局属性数组，并将 callback 插入到数组中。
      window.WVJBCallbacks = [callback];
      // 创建一个 iframe 元素
      var WVJBIframe = document.createElement('iframe');
      // 不显示
      WVJBIframe.style.display = 'none';
      // 设置 iframe 的 src 属性
      WVJBIframe.src = 'wvjbscheme://__BRIDGE_LOADED__';
      // 把 iframe 添加到当前文导航上。
      document.documentElement.appendChild(WVJBIframe);
      setTimeout(function () {
        document.documentElement.removeChild(WVJBIframe);
      }, 0);
    }
  },
  getData: function getData(callback) {
    var _this = this;

    if (window.config.forApp) {
      // 请求用户数据、手机系统数据、位置数据
      // let getList = [new Promise(this.getUserInfo), new Promise(this.getSystemInfo), new Promise(this.getPositionInfo)]
      this.setupWebViewJavascriptBridge(function (bridge) {
        _this.getUserInfo(bridge);
        _this.getSystemInfo(bridge, callback);
        _this.getPositionInfo(bridge);
      });
    } else {
      // session.setLoginUser(baseData.userInfo)
      /* 本地调试配置路径 */
      var data = {};
      data.serverUrl = window.config.userInfo.serverUrl;
      _session2.default.setLoginUser(data);
      _local2.default.setPositionInfo(_baseData2.default.positionInfo);
      _local2.default.setSystemInfo(_baseData2.default.systemInfo);
      this.tempLogin().then(function () {
        if (callback) callback();
      });
    }
  },

  // 请求用户数据
  getUserInfo: function getUserInfo(bridge) {
    bridge.callHandler('getUserInfo', {}, function (dataFromOC) {
      var dataInfo = JSON.parse(dataFromOC);
      if (dataInfo.resultCode === '0') {
        _session2.default.setLoginUser(dataInfo.data);
      }
    });
  },

  // 临时登录方法
  tempLogin: function tempLogin() {
    _vue2.default.http.headers.common['TenantId'] = window.config.userInfo.tenantId;
    return _backend2.default.request(_basedata2.default.Base.tempLogin, {
      userName: window.config.userInfo.userName,
      password: window.config.userInfo.password,
      tenantId: window.config.userInfo.tenantId
    }).then(function (res) {
      if (res.resultCode === '0') {
        /* res.data.orgName = '程礼邦工厂' */
        res.data.serverUrl = window.config.userInfo.serverUrl;
        _session2.default.setLoginUser(res.data);
      }
    });
  },

  /* H5应用写日志 */
  writeError: function writeError(data, callback) {
    this.setupWebViewJavascriptBridge(function (bridge) {
      bridge.callHandler('error', { data: data }, function (result) {
        if (callback) callback(result);
      });
    });
  },

  // 请求手机系统数据
  getSystemInfo: function getSystemInfo(bridge, callback) {
    bridge.callHandler('getSystemInfo', {}, function (dataFromOC) {
      // window.alert(dataFromOC)
      var dataInfo = JSON.parse(dataFromOC);
      _local2.default.setSystemInfo(dataInfo);
      if (callback) callback();
    });
  },

  // 请求位置数据
  getPositionInfo: function getPositionInfo(bridge, callback) {
    bridge.callHandler('getPosition', {}, function (dataFromOC) {
      _local2.default.setPositionInfo(JSON.parse(dataFromOC));
      if (callback) callback();
    });
  },

  // 初始化扫码窗口
  initScanView: function initScanView(mode, height, message, isPullable, header, fixed, callback) {
    // this.openMessageBox('调试信息', '', `调用initScanView方法：mode: ${mode};height: ${height};message: ${message};isPullable: ${isPullable};header: ${header};fixed: ${fixed};`, '', '关闭', false)
    this.setupWebViewJavascriptBridge(function (bridge) {
      var param = {
        mode: mode, // 扫码类型，QCC：量子云码、QR：二维码、BC：条形码、VC：虚拟码
        flash: 'off', // 闪光灯，值为 on, off
        devicePosition: 0, // 摄像头朝向，front：前置1、back：后置0
        webviewHeight: height, // 底部webview展示内容高度，单位%，0为不展示
        message: message, // 扫码提示信息
        isPullable: isPullable, // Webview是否可拉动
        header: header,
        fixed: fixed
        // window.alert('initScanView调用成功' + JSON.stringify(param))
      };bridge.callHandler('initScanView', param, function (result) {
        // window.alert('initScanView调用成功' + JSON.stringify(result))
        if (callback) callback(result);
      });
    });
  },

  // 重新设置扫码页面样式
  changeScanView: function changeScanView(height, message, isPullable, header, fixed, callback) {
    // this.openMessageBox('调试信息', '', `调用changeScanView方法：height: ${height};message: ${message};isPullable: ${isPullable};header: ${header};fixed: ${fixed};`, '', '关闭', false)
    this.setupWebViewJavascriptBridge(function (bridge) {
      bridge.callHandler('changeScanView', {
        webviewHeight: height,
        message: message,
        isPullable: isPullable,
        header: header,
        fixed: fixed
      }, function (result) {
        if (callback) callback(result);
      });
    });
  },

  // 打开弹窗提示
  openMessageBox: function openMessageBox(title, alert, message, cancelButtonText, confirmButtonText, buttonLinefeed, callback) {
    if (!window.config.forApp) {
      (0, _mintUi.MessageBox)({
        title: title,
        message: message,
        showCancelButton: cancelButtonText !== '',
        showConfirmButton: confirmButtonText !== '',
        cancelButtonText: cancelButtonText,
        confirmButtonText: confirmButtonText
      }).then(function (action) {
        if (callback) callback(action);
      });
    }
    this.setupWebViewJavascriptBridge(function (bridge) {
      bridge.callHandler('openMessageBox', {
        title: title,
        alert: alert,
        message: message,
        cancelButtonText: cancelButtonText,
        confirmButtonText: confirmButtonText,
        buttonLinefeed: buttonLinefeed // 超过五个字换行
      }, function (result) {
        _store2.default.commit('global.changeScanFlag', false); // 解锁
        if (callback) callback(result);
      });
    });
  },

  // 设置扫码界面显示状态接口(true显示预览页面、false隐藏预览页面)
  showScanView: function showScanView(isShow, callback) {
    // this.openMessageBox('调试信息', '', `调用showScanView方法：isShow: ${isShow};`, '', '关闭', false)
    this.setupWebViewJavascriptBridge(function (bridge) {
      bridge.callHandler('showScanView', { isShow: isShow }, function (result) {
        if (callback) callback(result);
      });
    });
  },

  // 设置APP跳转应用市场
  transformToUpdateAPP: function transformToUpdateAPP(isTransform, callback) {
    this.setupWebViewJavascriptBridge(function (bridge) {
      bridge.callHandler('transformToUpdateAPP', { isTransform: isTransform }, function (result) {
        if (callback) callback(result);
      });
    });
  },

  // 切换扫码方式
  switchScanMode: function switchScanMode(scanMode, callback) {
    this.setupWebViewJavascriptBridge(function (bridge) {
      bridge.callHandler('switchScanMode', { mode: scanMode }, function (result) {
        // window.alert(JSON.stringify(result))
        if (callback) callback(result);
      });
    });
  },

  // 语音提示
  //   StockSuccess：出库成功
  //   StockFail：出库失败
  //   PackSuccess：打包成功
  //   PackFail：打包失败
  //   ShipSuccess：发货成功
  //   ShipFail：发货失败
  //   RemoveSuccess：解除成功
  //   FailSuccess：解除失败
  //   ScanSuccess：扫码成功
  //   ScanFail：扫码失败
  //   ScanRepeat：扫码重复
  //   replaceSuccess：替换成功
  //   replaceFailure：替换失败
  //   ScanSuperCode: 请扫描上级码+扫码成功
  //   AppendSuccess: 追加成功
  //   AppendFailure: 追加失败
  voiceAlert: function voiceAlert(type, callback) {
    this.setupWebViewJavascriptBridge(function (bridge) {
      bridge.callHandler('voicePrompts', { type: type }, function (result) {
        if (callback) callback();
      });
    });
  },

  // 上传图片
  uploadImage: function uploadImage(callback) {
    this.setupWebViewJavascriptBridge(function (bridge) {
      bridge.callHandler('uploadImage', {}, function (result) {
        if (callback) callback(result);
      });
    });
  },

  // 重新定位
  reloadPosition: function reloadPosition(callback) {
    this.setupWebViewJavascriptBridge(function (bridge) {
      bridge.callHandler('reloadPosition', {}, function (result) {
        if (callback) callback(result);
      });
    });
  },

  // 重新登录
  tokenFail: function tokenFail(callback) {
    this.setupWebViewJavascriptBridge(function (bridge) {
      bridge.callHandler('tokenFail', {}, function (result) {
        if (callback) callback(result);
      });
    });
  },

  // 退出小程序
  existApplet: function existApplet(callback) {
    this.setupWebViewJavascriptBridge(function (bridge) {
      bridge.callHandler('existApplet', {}, function (result) {
        if (callback) callback(result);
      });
    });
  },

  // 设置扫码状态接口（不关闭扫码框）
  setScanStatus: function setScanStatus(status, callback) {
    // window.alert('setScanStatus:' + status)
    this.setupWebViewJavascriptBridge(function (bridge) {
      bridge.callHandler('setScanStatus', { status: status }, function (result) {
        if (callback) callback(result);
      });
    });
  },

  // 注册路由回退接口
  goBackHistory: function goBackHistory(callback) {
    // this.openMessageBox('调试信息', '', `调用goBackHistory方法`, '', '关闭', false)
    this.setupWebViewJavascriptBridge(function (bridge) {
      bridge.registerHandler('goBackHistory', function (data, cb) {
        // this.openMessageBox('调试信息', '', JSON.stringify(callback), '', '关闭', false)
        if (callback) callback(data, cb);
      });
    });
  },

  // 注册扫码回调接口
  syncScanResult: function syncScanResult(callback) {
    this.setupWebViewJavascriptBridge(function (bridge) {
      bridge.registerHandler('syncScanResult', function (data, cb) {
        if (!callback) return;
        var scanFlag = _store2.default.getters['global.scanFlag'];
        if (scanFlag) return (0, _mintUi.Toast)({ message: '请等待扫码完成', duration: 500 });
        _store2.default.commit('global.changeScanFlag', true); // 加锁
        // this.$store.commit('global.changeScanFlag', false) // 解锁
        var scannedInfo = JSON.parse(data);
        if (scannedInfo.mode === 'BC') scannedInfo.code = scannedInfo.codeStr; // 条形码
        scannedInfo.codeType = scannedInfo.vid !== '' ? 1 : 2; // 1.量子云码 2.条形码
        if (scannedInfo.resultCode === 0) {
          if (callback) callback(scannedInfo, cb);
        } else {
          // this.$store.commit('global.changeScanFlag', false) // 解锁
          // return Toast({ message: '扫码错误,请继续扫码', duration: 500 })
        }
      });
    });
  },

  // =============================破损标签作废小应用相关接口==========================
  // 请求手机当前语言
  getLanguage: function getLanguage(callback) {
    this.setupWebViewJavascriptBridge(function (bridge) {
      bridge.callHandler('getLanguage', { 'code': true }, function (result) {
        if (callback) callback(result);
      });
    });
  },

  // 请求用户UserId
  getUserId: function getUserId(callback) {
    this.setupWebViewJavascriptBridge(function (bridge) {
      bridge.callHandler('getUserId', { 'code': true }, function (result) {
        // window.alert(result)
        if (callback) callback(result);
      });
    });
  },

  // 注册蓝牙扫码回调接口
  syncBluethoodScanResult: function syncBluethoodScanResult(callback) {
    this.setupWebViewJavascriptBridge(function (bridge) {
      bridge.registerHandler('syncBluethoodScanResult', function (data, cb) {
        if (callback) callback(data, cb);
      });
    });
  }
};

/***/ }),

/***/ "t3Hx":
/***/ (function(module, exports) {

// removed by extract-text-webpack-plugin

/***/ }),

/***/ "u8EM":
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/img/emptyBox.755c8e3.png";

/***/ }),

/***/ "uAb1":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
var render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('div',{attrs:{"id":"scanCodeRecord"}},[_c('p',{staticClass:"scan-title"},[_vm._v("入库记录("+_vm._s(_vm.scanRecordList.length)+")")]),_vm._v(" "),(_vm.scanRecordList.length>0)?_c('div',{staticClass:"scan-list"},[_c('ul',{staticClass:"list-item"},_vm._l((_vm.scanRecordList),function(record,index){return _c('li',{key:index},[_c('p',{staticClass:"scan-time"},[_vm._v(_vm._s(record.operateTime))]),_vm._v(" "),_c('div',{staticClass:"record-info"},[_c('p',{staticClass:"black-text"},[_vm._v(_vm._s(record.goodsInfo.sku.name)),_c('span',{staticClass:"yellow-text"},[_vm._v("("+_vm._s(record.goodsInfo.unit)+")")])]),_vm._v(" "),_c('p',[_c('span',[_vm._v("码值")]),_c('span',[_vm._v(_vm._s(_vm.$util.common.ObjectUtils.filterCode(record.operateCode)))])]),_vm._v(" "),_c('p',[_c('span',[_vm._v("组织")]),_c('span',[_vm._v(_vm._s(record.operator.orgName))])]),_vm._v(" "),_c('p',[_c('span',[_vm._v("仓库")]),_c('span',[_vm._v(_vm._s(record.stockInfo.warehouseName))])])])])}),0)]):_c('div',{staticClass:"empty-list"},[_c('img',{attrs:{"src":__webpack_require__("u8EM"),"alt":""}}),_vm._v(" "),_c('p',{staticClass:"gray-text"},[_vm._v("暂无记录")])])])}
var staticRenderFns = []
var esExports = { render: render, staticRenderFns: staticRenderFns }
/* harmony default export */ __webpack_exports__["a"] = (esExports);

/***/ }),

/***/ "uGmS":
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _defineProperty2 = __webpack_require__("bOdI");

var _defineProperty3 = _interopRequireDefault(_defineProperty2);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var NS = 'disassociate.';

exports.default = {
  state: {
    disassociate: {
      codeInfo: {} // 码值详情
    }
  },
  getters: (0, _defineProperty3.default)({}, NS + 'codeInfo', function (state) {
    return state.disassociate.codeInfo;
  }),
  mutations: (0, _defineProperty3.default)({}, NS + 'changeCodeInfo', function (state, info) {
    state.disassociate.codeInfo = info;
  })
};

/***/ }),

/***/ "wkJh":
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _defineProperty2 = __webpack_require__("bOdI");

var _defineProperty3 = _interopRequireDefault(_defineProperty2);

var _getters, _mutations;

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var NS = 'pack.';

exports.default = {
  state: {
    pack: {
      chosenGood: null, // 已选商品
      chosenSize: null, // 已选包装规格
      chosenWarehouse: null, // 已选仓库
      chosenPL: null, // 已选产线
      chosenBatchNo: null, // 已选批次号
      isRealTime: true // 是否实时校验
    }
  },
  getters: (_getters = {}, (0, _defineProperty3.default)(_getters, NS + 'chosenGood', function (state) {
    return state.pack.chosenGood;
  }), (0, _defineProperty3.default)(_getters, NS + 'chosenSize', function (state) {
    return state.pack.chosenSize;
  }), (0, _defineProperty3.default)(_getters, NS + 'chosenWarehouse', function (state) {
    return state.pack.chosenWarehouse;
  }), (0, _defineProperty3.default)(_getters, NS + 'chosenPL', function (state) {
    return state.pack.chosenPL;
  }), (0, _defineProperty3.default)(_getters, NS + 'chosenBatchNo', function (state) {
    return state.pack.chosenBatchNo;
  }), (0, _defineProperty3.default)(_getters, NS + 'isRealTime', function (state) {
    return state.pack.isRealTime;
  }), _getters),
  mutations: (_mutations = {}, (0, _defineProperty3.default)(_mutations, NS + 'changeChosenGood', function (state, good) {
    state.pack.chosenGood = good;
  }), (0, _defineProperty3.default)(_mutations, NS + 'changeChosenSize', function (state, size) {
    state.pack.chosenSize = size;
  }), (0, _defineProperty3.default)(_mutations, NS + 'changeChosenWarehouse', function (state, warehouse) {
    state.pack.chosenWarehouse = warehouse;
  }), (0, _defineProperty3.default)(_mutations, NS + 'changeChosenPL', function (state, pl) {
    state.pack.chosenPL = pl;
  }), (0, _defineProperty3.default)(_mutations, NS + 'changeChosenBatchNo', function (state, batchNo) {
    state.pack.chosenBatchNo = batchNo;
  }), (0, _defineProperty3.default)(_mutations, NS + 'changeIsRealTime', function (state, flag) {
    state.pack.isRealTime = flag;
  }), _mutations)
};

/***/ }),

/***/ "ySQA":
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var _session = __webpack_require__("hDMw");

var _session2 = _interopRequireDefault(_session);

var _user = __webpack_require__("ivU6");

var _user2 = _interopRequireDefault(_user);

var _dictionary = __webpack_require__("hCOg");

var _dictionary2 = _interopRequireDefault(_dictionary);

var _local = __webpack_require__("FITS");

var _local2 = _interopRequireDefault(_local);

var _app = __webpack_require__("svz7");

var _app2 = _interopRequireDefault(_app);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

module.exports = {
  SessionUtils: _session2.default,
  UserUtils: _user2.default,
  DictionaryUtils: _dictionary2.default,
  LocalUtils: _local2.default,
  AppUtils: _app2.default
};

/***/ }),

/***/ "ya2q":
/***/ (function(module, exports, __webpack_require__) {

"use strict";


module.exports = {
  common: {
    // 下级组织列表
    directLowerOrg: {
      path: '/organization/directLowerOrg',
      method: 'GET',
      server: 'user'
    },
    // 上级组织列表
    EqualOrg: {
      path: '/organization/superOrgOrAll',
      method: 'GET',
      server: 'user'
    },
    // 当前组织列表
    currentOrg: {
      path: '/organization/currentOrg',
      method: 'GET',
      server: 'user'
    },
    // 根据id获取仓库列表
    getWarehouseList: {
      path: '/warehouse/orgWarehouse',
      method: 'GET',
      server: 'base'
    },
    directLowerOrgOrAll: {
      path: '/organization/directLowerOrgOrAll',
      method: 'GET',
      server: 'user'
    },
    // 跨级发货
    allLowerOrg: {
      path: '/organization/allLowerOrg',
      method: 'GET',
      server: 'user'
    },
    // 工厂用户查询下面所有的经销商
    factoryAndDealer: {
      path: '/organization/factoryAndDealer',
      method: 'GET',
      server: 'user'
    },
    // 查询父对象
    selectById: {
      path: '/organization/selectById/',
      method: 'GET',
      server: 'user'
    }
  }
};

/***/ }),

/***/ "z0u7":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
var render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('div',{attrs:{"id":"app"}},[(_vm.$route.meta.showHeader)?_c('div',{staticClass:"customize-header"},[_c('div',{staticClass:"customize-header-info"},[_c('p',{on:{"click":function($event){return _vm.$router.goBack(_vm.$route)}}},[_c('van-icon',{attrs:{"name":"arrow-left","color":"#ffffff","size":"18"}}),_vm._v(" "),_c('span',{staticClass:"white-text"},[_vm._v("返回")])],1),_vm._v(" "),_c('span',[_vm._v(_vm._s(_vm.$route.meta.title))]),_vm._v(" "),_c('p',{staticClass:"time-search-iocn"})])]):_vm._e(),_vm._v(" "),(_vm.isLoading)?_c('div',{staticClass:"load-overlay"}):_vm._e(),_vm._v(" "),(_vm.isLoading)?_c('van-loading',{staticClass:"van-loading-customize",attrs:{"size":"26px"}}):_vm._e(),_vm._v(" "),_c('router-view')],1)}
var staticRenderFns = []
var esExports = { render: render, staticRenderFns: staticRenderFns }
/* harmony default export */ __webpack_exports__["a"] = (esExports);

/***/ })

},["ofE0"]);
//# sourceMappingURL=wholeCodeIn.56a6af641c54f25d3948.js.map