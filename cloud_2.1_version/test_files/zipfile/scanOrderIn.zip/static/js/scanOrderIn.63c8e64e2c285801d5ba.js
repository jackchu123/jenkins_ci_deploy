webpackJsonp([3],{

/***/ "/eQ1":
/***/ (function(module, exports) {

// removed by extract-text-webpack-plugin

/***/ }),

/***/ "0iPh":
/***/ (function(module, exports) {

module.exports = $;

/***/ }),

/***/ "0xDb":
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _index = __webpack_require__("jFiy");

var _index2 = _interopRequireDefault(_index);

var _index3 = __webpack_require__("ySQA");

var _index4 = _interopRequireDefault(_index3);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = {
  common: _index2.default,
  business: _index4.default
};

/***/ }),

/***/ "23rF":
/***/ (function(module, exports) {

// removed by extract-text-webpack-plugin

/***/ }),

/***/ "2GmJ":
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var MAX_FONT_SIZE = 42;

document.addEventListener('DOMContentLoaded', function () {
  var html = document.querySelector('html');
  var fontSize = window.innerWidth / 10;
  fontSize = fontSize > MAX_FONT_SIZE ? MAX_FONT_SIZE : fontSize;
  html.style.fontSize = fontSize + 'px';
});

/***/ }),

/***/ "3iuC":
/***/ (function(module, exports) {

// removed by extract-text-webpack-plugin

/***/ }),

/***/ "3pX5":
/***/ (function(module, exports, __webpack_require__) {

"use strict";


module.exports = {
  Base: {
    // 临时登录方法
    tempLogin: {
      path: '/login/app',
      method: 'POST',
      server: 'user'
    },
    // 获取数据字典
    getDictionary: {
      path: '',
      method: 'POST',
      server: ''
    }
  }
};

/***/ }),

/***/ "4D68":
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = {
  /**
     * @func
     * @desc 用于将后台返回的字段类型转化为 string, int, double, date
     * @param {String} coType - 必选，后台返回的字段类型
     * @returns {String} 返回转化后的字段类型
     */
  changeCoType: function changeCoType(coType) {
    var returnStr = '';
    if (coType !== null && coType !== '') {
      var tCoType = coType.toUpperCase();
      if (tCoType === 'VARCHAR' || tCoType === 'VARCHAR2' || tCoType === 'CHAR' || tCoType.indexOf('VARCHAR') > -1 || tCoType.indexOf('LOB') > -1) {
        returnStr = 'string';
      }
      if (tCoType === 'LONG' || tCoType === 'NUMBER' || tCoType === 'DECIMAL' || tCoType === 'INTEGER') {
        returnStr = 'int';
      }
      if (tCoType.indexOf('NUMBER') > -1 && tCoType === 'NUMBER' || tCoType.indexOf('DECIMAL') > -1 && tCoType === 'DECIMAL' || tCoType === 'FLOAT') {
        returnStr = 'double';
      }
      if (tCoType.indexOf('DATE') > -1 || tCoType.indexOf('TIME') > -1) {
        returnStr = 'date';
      }
      if (coType === null || coType === '') {
        return coType;
      }
    }
    return returnStr;
  }
};

/***/ }),

/***/ "4ml/":
/***/ (function(module, exports) {

// removed by extract-text-webpack-plugin

/***/ }),

/***/ "5fGi":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
Object.defineProperty(__webpack_exports__, "__esModule", { value: true });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__babel_loader_node_modules_vue_loader_lib_selector_type_script_index_0_inStockDetails_vue__ = __webpack_require__("Ot9J");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__babel_loader_node_modules_vue_loader_lib_selector_type_script_index_0_inStockDetails_vue___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0__babel_loader_node_modules_vue_loader_lib_selector_type_script_index_0_inStockDetails_vue__);
/* harmony namespace reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in __WEBPACK_IMPORTED_MODULE_0__babel_loader_node_modules_vue_loader_lib_selector_type_script_index_0_inStockDetails_vue__) if(__WEBPACK_IMPORT_KEY__ !== 'default') (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return __WEBPACK_IMPORTED_MODULE_0__babel_loader_node_modules_vue_loader_lib_selector_type_script_index_0_inStockDetails_vue__[key]; }) }(__WEBPACK_IMPORT_KEY__));
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__node_modules_vue_loader_lib_template_compiler_index_id_data_v_3ea6dce2_hasScoped_true_transformToRequire_video_src_poster_source_src_img_src_image_xlink_href_buble_transforms_node_modules_vue_loader_lib_selector_type_template_index_0_inStockDetails_vue__ = __webpack_require__("DiNS");
function injectStyle (ssrContext) {
  __webpack_require__("L8QT")
}
var normalizeComponent = __webpack_require__("VU/8")
/* script */


/* template */

/* template functional */
var __vue_template_functional__ = false
/* styles */
var __vue_styles__ = injectStyle
/* scopeId */
var __vue_scopeId__ = "data-v-3ea6dce2"
/* moduleIdentifier (server only) */
var __vue_module_identifier__ = null
var Component = normalizeComponent(
  __WEBPACK_IMPORTED_MODULE_0__babel_loader_node_modules_vue_loader_lib_selector_type_script_index_0_inStockDetails_vue___default.a,
  __WEBPACK_IMPORTED_MODULE_1__node_modules_vue_loader_lib_template_compiler_index_id_data_v_3ea6dce2_hasScoped_true_transformToRequire_video_src_poster_source_src_img_src_image_xlink_href_buble_transforms_node_modules_vue_loader_lib_selector_type_template_index_0_inStockDetails_vue__["a" /* default */],
  __vue_template_functional__,
  __vue_styles__,
  __vue_scopeId__,
  __vue_module_identifier__
)

/* harmony default export */ __webpack_exports__["default"] = (Component.exports);


/***/ }),

/***/ "5pKY":
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _promise = __webpack_require__("//Fk");

var _promise2 = _interopRequireDefault(_promise);

var _typeof2 = __webpack_require__("pFYg");

var _typeof3 = _interopRequireDefault(_typeof2);

var _stringify = __webpack_require__("mvHQ");

var _stringify2 = _interopRequireDefault(_stringify);

var _vue = __webpack_require__("lRwf");

var _vue2 = _interopRequireDefault(_vue);

var _vueResource = __webpack_require__("f/Qh");

var _vueResource2 = _interopRequireDefault(_vueResource);

var _session = __webpack_require__("hDMw");

var _session2 = _interopRequireDefault(_session);

var _string = __webpack_require__("TDeA");

var _string2 = _interopRequireDefault(_string);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

// import userInfo from '../conf/basedata/userInfo'
// import local from '../utils/business/local'

/* import config from './../utils/config' */
_vue2.default.use(_vueResource2.default);

function getApiConf(value) {
  if (value) {
    if (typeof value === 'string') {
      return {
        path: value,
        method: 'GET'
      };
    } else {
      if (!value) {
        throw new Error('Api未配置' + (0, _stringify2.default)(value));
      }
      if ((typeof value === 'undefined' ? 'undefined' : (0, _typeof3.default)(value)) !== 'object') {
        throw new Error('Api配置错误' + (0, _stringify2.default)(value));
      }
      if (!value.method) {
        throw new Error('Api配置错误，缺少method属性' + (0, _stringify2.default)(value));
      }
      if (!value.path) {
        throw new Error('Api配置错误，缺少path属性' + (0, _stringify2.default)(value));
      }
      return {
        path: value.path,
        method: value.method.toUpperCase(),
        server: value.server
      };
    }
  }
  throw new Error('Api path is null');
}

function _getUrl(api) {
  if (false) {
    return api.path;
  } else {
    // 此处配置中转服务器
    var server = api.server || 'default';
    /* if (session.getLoginUser().serviceUrl && session.getLoginUser().serviceUrl !== '' && api.server === 'transfer') {
      return session.getLoginUser().serviceUrl + api.path
    } */
    var url = _session2.default.getLoginUser().serverUrl;
    if (url.slice(url.length - 1) === '/') {} else {
      url += '/';
    }
    return url + window.config.servers[server === 'transfer' ? 'default' : server] + api.path;
  }
}

function buildQuery(json) {
  if (!json) {
    return '';
  }
  if (_string2.default.isString(json)) return json;
  var query = '?';
  for (var i in json) {
    query += i + '=' + encodeURIComponent(json[i]) + '&';
  }
  if (query.charAt(query.length - 1) === '&') {
    query = query.substr(0, query.length - 1);
  }
  return query;
}

function _request(settings) {
  var api = settings.api;
  var data = settings.data;
  var options = settings.options || {};
  var query = settings.query;
  api = getApiConf(api);
  var url = _getUrl(api);
  if (settings.options !== undefined) {
    _vue2.default.http.options.emulateJSON = true;
  } else {
    _vue2.default.http.options.emulateJSON = false;
  }
  if (api.method === 'GET') {
    url += buildQuery(data);
    return _vue2.default.http.get(url, options);
  } else if (api.method === 'POST') {
    url += buildQuery(query);
    return _vue2.default.http.post(url, data, options);
  } else if (api.method === 'PUT') {
    url += buildQuery(query);
    return _vue2.default.http.put(url, data, options);
  } else if (api.method === 'DELETE') {
    url += buildQuery(data);
    return _vue2.default.http.delete(url, null, options);
  } else {
    throw new Error('Http method not support => ' + api.method);
  }
}

/**
 * 请求代理类
 */
exports.default = {
  /**
   * 获取url
   */
  getUrl: function getUrl(apiKey, data) {
    var api = getApiConf(apiKey);
    var url = _getUrl(api);
    if ((typeof data === 'undefined' ? 'undefined' : (0, _typeof3.default)(data)) === 'object') {
      url += buildQuery(data);
    }
    return url;
  },

  /**
   * 请求后端
   * @param apiKey 获取URL用，即定义在src/conf/api.js中的api的Key
   * @param data JSON数据
   * @param options ajax附件参数，主要是http header，用的比较少
   */
  request: function request(api, data, options, query) {
    var isShowLoad = arguments.length > 4 && arguments[4] !== undefined ? arguments[4] : true;

    return new _promise2.default(function (resolve, reject) {
      _request({
        api: api,
        data: data,
        options: options,
        query: query
      }).then(function (response) {
        resolve(response.data);
      }, function (response) {
        reject(response);
      });
    });
  },

  /**
      * @param {
     * api:''//piKey 获取URL用，即定义在src/conf/api.js中的api的Key
     *  data: JSNO对象，POST或者PUT到服务端的JOSON数据，如果是GET或者Delete则实际转换成url参数
     *  query: FormData
     * }
     */
  send: function send(settings) {
    var isShowLoading = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : true;

    return new _promise2.default(function (resolve, reject) {
      _request(settings).then(function (response) {
        resolve(response.data);
      }, function (response) {
        reject(response);
      });
    });
  },

  /**
   * 转换错误
   * @param {*} error
   */
  convertError: function convertError(error) {
    var ret = { code: -1 };
    var response = error.response;
    if (response) {
      ret.code = response.status;
      var url = response.config.url;
      if (response.status === 504) {
        ret.msg = '服务器网关超时，请联系管理员，请求：' + url;
      } else if (response.status === 404) {
        ret.msg = '服务未启动或未找到接口，请求：' + url;
      } else {
        ret.msg = '服务器繁忙，请稍后再试，请求：' + url;
      }
    } else {
      ret.msg = '无法连接服务器，请检查您的网络';
    }
    return ret;
  }
};

/***/ }),

/***/ "5rSO":
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _vue = __webpack_require__("lRwf");

var _vue2 = _interopRequireDefault(_vue);

var _vueRouter = __webpack_require__("pRNm");

var _vueRouter2 = _interopRequireDefault(_vueRouter);

var _inStockDetails = __webpack_require__("5fGi");

var _inStockDetails2 = _interopRequireDefault(_inStockDetails);

var _orderInStock = __webpack_require__("juUJ");

var _orderInStock2 = _interopRequireDefault(_orderInStock);

var _scanRecordIn = __webpack_require__("wKWR");

var _scanRecordIn2 = _interopRequireDefault(_scanRecordIn);

var _confirmIn = __webpack_require__("ap5O");

var _confirmIn2 = _interopRequireDefault(_confirmIn);

var _selectOrgan = __webpack_require__("77y4");

var _selectOrgan2 = _interopRequireDefault(_selectOrgan);

var _batchScanRecord = __webpack_require__("t33/");

var _batchScanRecord2 = _interopRequireDefault(_batchScanRecord);

var _remarksList = __webpack_require__("od2t");

var _remarksList2 = _interopRequireDefault(_remarksList);

var _PageTransition = __webpack_require__("XHtf");

var _PageTransition2 = _interopRequireDefault(_PageTransition);

var _utils = __webpack_require__("0xDb");

var _utils2 = _interopRequireDefault(_utils);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

_vueRouter2.default.prototype.goBack = function (route) {
  this.isBack = true;
  if (route.path === '/') return _utils2.default.business.AppUtils.existApplet();
  window.history.go(-1);
};

_vue2.default.use(_vueRouter2.default);
var routes = [{
  path: '/',
  name: 'pageTransition',
  component: _PageTransition2.default,
  children: [{
    path: '/',
    component: _orderInStock2.default,
    name: 'orderInStock',
    meta: {
      title: '按单入库',
      showHeader: true
    }
  }, {
    path: '/scanRecordIn',
    component: _scanRecordIn2.default,
    name: 'scanRecordIn',
    meta: {
      title: '扫码记录 ',
      showHeader: false
    }
  }, {
    path: '/inStockDetails',
    component: _inStockDetails2.default,
    name: 'inStockDetails',
    meta: {
      title: '详情 ',
      showHeader: true
    }
  }, {
    path: '/confirmIn',
    component: _confirmIn2.default,
    name: 'confirmIn',
    meta: {
      title: '确认收货 ',
      showHeader: true
    }
  }, {
    path: '/selectOrgan',
    component: _selectOrgan2.default,
    name: 'selectOrgan',
    meta: {
      title: '选择组织 ',
      showHeader: true
    }
  }, {
    path: '/remarksList',
    component: _remarksList2.default,
    name: 'remarksList',
    meta: {
      title: '备注列表',
      showHeader: true
    }
  }, {
    path: '/batchScanRecord',
    component: _batchScanRecord2.default,
    name: 'batchScanRecord',
    meta: {
      title: '码值详情',
      showHeader: true
    }
  }]
}];

// 定义路由实例
var router = new _vueRouter2.default({
  // mode: 'history',
  routes: routes
});

/**
 * 处理路由配置项
 * @param {} conf 配置项
 */
// function handleRouterConfig (conf) {
//   let path = '/' + conf.path
//   let name = conf.path.replace(new RegExp('\\/', 'g'), '_')
//   let component = resolve => require(['../views/' + conf.component], resolve)
//
//   let route = { path, name, component }
//
//   if (conf.children && conf.children instanceof Array) {
//     route.children = []
//     for (let child of conf.children) {
//       let childRoute = handleRouterConfig(child)
//       if (typeof childRoute !== 'undefined') {
//         route.children.push(childRoute)
//       }
//     }
//   }
//   return route
// }

exports.default = router;

/***/ }),

/***/ "6Hho":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
Object.defineProperty(__webpack_exports__, "__esModule", { value: true });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__babel_loader_node_modules_vue_loader_lib_selector_type_script_index_0_timeSelect_vue__ = __webpack_require__("kB6T");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__babel_loader_node_modules_vue_loader_lib_selector_type_script_index_0_timeSelect_vue___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0__babel_loader_node_modules_vue_loader_lib_selector_type_script_index_0_timeSelect_vue__);
/* harmony namespace reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in __WEBPACK_IMPORTED_MODULE_0__babel_loader_node_modules_vue_loader_lib_selector_type_script_index_0_timeSelect_vue__) if(__WEBPACK_IMPORT_KEY__ !== 'default') (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return __WEBPACK_IMPORTED_MODULE_0__babel_loader_node_modules_vue_loader_lib_selector_type_script_index_0_timeSelect_vue__[key]; }) }(__WEBPACK_IMPORT_KEY__));
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__node_modules_vue_loader_lib_template_compiler_index_id_data_v_132a2fe4_hasScoped_true_transformToRequire_video_src_poster_source_src_img_src_image_xlink_href_buble_transforms_node_modules_vue_loader_lib_selector_type_template_index_0_timeSelect_vue__ = __webpack_require__("uJ/+");
function injectStyle (ssrContext) {
  __webpack_require__("v7pW")
  __webpack_require__("3iuC")
}
var normalizeComponent = __webpack_require__("VU/8")
/* script */


/* template */

/* template functional */
var __vue_template_functional__ = false
/* styles */
var __vue_styles__ = injectStyle
/* scopeId */
var __vue_scopeId__ = "data-v-132a2fe4"
/* moduleIdentifier (server only) */
var __vue_module_identifier__ = null
var Component = normalizeComponent(
  __WEBPACK_IMPORTED_MODULE_0__babel_loader_node_modules_vue_loader_lib_selector_type_script_index_0_timeSelect_vue___default.a,
  __WEBPACK_IMPORTED_MODULE_1__node_modules_vue_loader_lib_template_compiler_index_id_data_v_132a2fe4_hasScoped_true_transformToRequire_video_src_poster_source_src_img_src_image_xlink_href_buble_transforms_node_modules_vue_loader_lib_selector_type_template_index_0_timeSelect_vue__["a" /* default */],
  __vue_template_functional__,
  __vue_styles__,
  __vue_scopeId__,
  __vue_module_identifier__
)

/* harmony default export */ __webpack_exports__["default"] = (Component.exports);


/***/ }),

/***/ "6zCF":
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.actions = exports.mutations = exports.getters = exports.state = undefined;

var _defineProperty2 = __webpack_require__("bOdI");

var _defineProperty3 = _interopRequireDefault(_defineProperty2);

var _getters, _mutations;

var _session = __webpack_require__("hDMw");

var _session2 = _interopRequireDefault(_session);

var _local = __webpack_require__("FITS");

var _local2 = _interopRequireDefault(_local);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var NS = 'global.';

var state = exports.state = {
  global: {
    user: null,
    userid: '',
    isLoading: false,
    isPDA: true,
    scanMode: 'QCC',
    isInitScanView: true, // 判断是否第一次加载扫码框
    scanViewStatus: true, // 扫码框状态
    scanFlag: false, // true为扫码未处理完成
    timeVisible: false,
    outOrganInfo: {}, // 发货组织
    inOrganInfo: {}, // 收货组织
    outWareHouseInfo: {}, // 发货仓库scanFlag
    inWareHouseInfo: {}, // 收货组织
    outStockGoods: [],
    outInDetails: {}, // 出入库单详情
    isShowKeyBoard: false, // 键盘未展示
    batchScanRecord: [], // 批次扫码记录
    showEditRemarks: 0, // 0不可输入备注 1输入多条备注  2只能输入一条备注
    orderStockConfig: {}, // 收发货设置
    organLevelNum: 0, // 选择组织的层级数
    url: '' // 跳转的URL链接
  }
};

var getters = exports.getters = (_getters = {}, (0, _defineProperty3.default)(_getters, NS + 'outInDetails', function (state) {
  return state.global.outInDetails;
}), (0, _defineProperty3.default)(_getters, NS + 'outStockGoods', function (state) {
  return state.global.outStockGoods;
}), (0, _defineProperty3.default)(_getters, NS + 'orderStockConfig', function (state) {
  return state.global.orderStockConfig;
}), (0, _defineProperty3.default)(_getters, NS + 'organLevelNum', function (state) {
  return state.global.organLevelNum;
}), (0, _defineProperty3.default)(_getters, NS + 'url', function (state) {
  return state.global.url;
}), (0, _defineProperty3.default)(_getters, NS + 'batchScanRecord', function (state) {
  return state.global.batchScanRecord;
}), (0, _defineProperty3.default)(_getters, NS + 'outOrganInfo', function (state) {
  return state.global.outOrganInfo;
}), (0, _defineProperty3.default)(_getters, NS + 'showEditRemarks', function (state) {
  return state.global.showEditRemarks;
}), (0, _defineProperty3.default)(_getters, NS + 'isShowKeyBoard', function (state) {
  return state.global.isShowKeyBoard;
}), (0, _defineProperty3.default)(_getters, NS + 'inOrganInfo', function (state) {
  return state.global.inOrganInfo;
}), (0, _defineProperty3.default)(_getters, NS + 'outWareHouseInfo', function (state) {
  return state.global.outWareHouseInfo;
}), (0, _defineProperty3.default)(_getters, NS + 'inWareHouseInfo', function (state) {
  return state.global.inWareHouseInfo;
}), (0, _defineProperty3.default)(_getters, NS + 'timeVisible', function (state) {
  return state.global.timeVisible;
}), (0, _defineProperty3.default)(_getters, NS + 'user', function (state) {
  state.global.user = _session2.default.getLoginUser();
  return state.global.user;
}), (0, _defineProperty3.default)(_getters, NS + 'userid', function (state) {
  return state.global.userid;
}), (0, _defineProperty3.default)(_getters, NS + 'isLoading', function (state) {
  return state.global.isLoading;
}), (0, _defineProperty3.default)(_getters, NS + 'isPDA', function (state) {
  state.global.isPDA = _local2.default.getIsPDA();
  return state.global.isPDA;
}), (0, _defineProperty3.default)(_getters, NS + 'scanMode', function (state) {
  return state.global.scanMode;
}), (0, _defineProperty3.default)(_getters, NS + 'isInitScanView', function (state) {
  return state.global.isInitScanView;
}), (0, _defineProperty3.default)(_getters, NS + 'scanViewStatus', function (state) {
  return state.global.scanViewStatus;
}), (0, _defineProperty3.default)(_getters, NS + 'scanFlag', function (state) {
  return state.global.scanFlag;
}), _getters);

var mutations = exports.mutations = (_mutations = {}, (0, _defineProperty3.default)(_mutations, NS + 'changeOutInDetails', function (state, outInDetails) {
  state.global.outInDetails = outInDetails;
}), (0, _defineProperty3.default)(_mutations, NS + 'changeOutStockGoods', function (state, outStockGoods) {
  state.global.outStockGoods = outStockGoods;
}), (0, _defineProperty3.default)(_mutations, NS + 'changeBatchScanRecord', function (state, batchScanRecord) {
  state.global.batchScanRecord = batchScanRecord;
}), (0, _defineProperty3.default)(_mutations, NS + 'changeOrderStockConfig', function (state, orderStockConfig) {
  state.global.orderStockConfig = orderStockConfig;
}), (0, _defineProperty3.default)(_mutations, NS + 'changeOrganLevelNum', function (state, organLevelNum) {
  state.global.organLevelNum = organLevelNum;
}), (0, _defineProperty3.default)(_mutations, NS + 'changeUrl', function (state, url) {
  state.global.url = url;
}), (0, _defineProperty3.default)(_mutations, NS + 'changeShowEditRemarks', function (state, showEditRemarks) {
  state.global.showEditRemarks = showEditRemarks;
}), (0, _defineProperty3.default)(_mutations, NS + 'changeOutOrganInfo', function (state, outOrganInfo) {
  state.global.outOrganInfo = outOrganInfo;
}), (0, _defineProperty3.default)(_mutations, NS + 'changeShowKeyBoard', function (state, isShowKeyBoard) {
  state.global.isShowKeyBoard = isShowKeyBoard;
}), (0, _defineProperty3.default)(_mutations, NS + 'changeInOrganInfo', function (state, inOrganInfo) {
  state.global.inOrganInfo = inOrganInfo;
}), (0, _defineProperty3.default)(_mutations, NS + 'changeOutWareHouseInfo', function (state, outWareHouseInfo) {
  state.global.outWareHouseInfo = outWareHouseInfo;
}), (0, _defineProperty3.default)(_mutations, NS + 'changeInWareHouseInfo', function (state, inWareHouseInfo) {
  state.global.inWareHouseInfo = inWareHouseInfo;
}), (0, _defineProperty3.default)(_mutations, NS + 'changeTimeVisible', function (state, timeVisible) {
  state.global.timeVisible = timeVisible;
}), (0, _defineProperty3.default)(_mutations, NS + 'changeUser', function (state, user) {
  state.global.user = user;
  _session2.default.setLoginUser(user);
}), (0, _defineProperty3.default)(_mutations, NS + 'changeUserid', function (state, userid) {
  state.global.userid = userid;
}), (0, _defineProperty3.default)(_mutations, NS + 'changeIsLoading', function (state, flag) {
  state.global.isLoading = flag;
}), (0, _defineProperty3.default)(_mutations, NS + 'changeIsPDA', function (state, flag) {
  state.global.isPDA = flag;
}), (0, _defineProperty3.default)(_mutations, NS + 'changeScanMode', function (state, flag) {
  state.global.scanMode = flag;
}), (0, _defineProperty3.default)(_mutations, NS + 'changeIsInitScanView', function (state, flag) {
  state.global.isInitScanView = flag;
}), (0, _defineProperty3.default)(_mutations, NS + 'changeScanViewStatus', function (state, flag) {
  state.global.scanViewStatus = flag;
}), (0, _defineProperty3.default)(_mutations, NS + 'changeScanFlag', function (state, flag) {
  state.global.scanFlag = flag;
}), _mutations);

var actions = exports.actions = {};

/***/ }),

/***/ "77y4":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
Object.defineProperty(__webpack_exports__, "__esModule", { value: true });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__babel_loader_node_modules_vue_loader_lib_selector_type_script_index_0_selectOrgan_vue__ = __webpack_require__("SgIK");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__babel_loader_node_modules_vue_loader_lib_selector_type_script_index_0_selectOrgan_vue___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0__babel_loader_node_modules_vue_loader_lib_selector_type_script_index_0_selectOrgan_vue__);
/* harmony namespace reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in __WEBPACK_IMPORTED_MODULE_0__babel_loader_node_modules_vue_loader_lib_selector_type_script_index_0_selectOrgan_vue__) if(__WEBPACK_IMPORT_KEY__ !== 'default') (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return __WEBPACK_IMPORTED_MODULE_0__babel_loader_node_modules_vue_loader_lib_selector_type_script_index_0_selectOrgan_vue__[key]; }) }(__WEBPACK_IMPORT_KEY__));
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__node_modules_vue_loader_lib_template_compiler_index_id_data_v_01e83348_hasScoped_true_transformToRequire_video_src_poster_source_src_img_src_image_xlink_href_buble_transforms_node_modules_vue_loader_lib_selector_type_template_index_0_selectOrgan_vue__ = __webpack_require__("k/Mv");
function injectStyle (ssrContext) {
  __webpack_require__("FX6q")
  __webpack_require__("R9Oq")
}
var normalizeComponent = __webpack_require__("VU/8")
/* script */


/* template */

/* template functional */
var __vue_template_functional__ = false
/* styles */
var __vue_styles__ = injectStyle
/* scopeId */
var __vue_scopeId__ = "data-v-01e83348"
/* moduleIdentifier (server only) */
var __vue_module_identifier__ = null
var Component = normalizeComponent(
  __WEBPACK_IMPORTED_MODULE_0__babel_loader_node_modules_vue_loader_lib_selector_type_script_index_0_selectOrgan_vue___default.a,
  __WEBPACK_IMPORTED_MODULE_1__node_modules_vue_loader_lib_template_compiler_index_id_data_v_01e83348_hasScoped_true_transformToRequire_video_src_poster_source_src_img_src_image_xlink_href_buble_transforms_node_modules_vue_loader_lib_selector_type_template_index_0_selectOrgan_vue__["a" /* default */],
  __vue_template_functional__,
  __vue_styles__,
  __vue_scopeId__,
  __vue_module_identifier__
)

/* harmony default export */ __webpack_exports__["default"] = (Component.exports);


/***/ }),

/***/ "B0cl":
/***/ (function(module, exports) {

module.exports = {"userInfo":{"serviceUrl":"","username":"Julian","nickName":"Julian","tenantId":"Julian","roleType":2,"companyType":0,"token":"ZXlKaGJHY2lPaUpTVXpJMU5pSjkuZXlKemRXSWlPaUpxYVdVaUxDSjFjMlZ5U1dRaU9qWTJNVGMwTlRZNU56WXpNamMyTURZeU56SXNJblJsYm1GdWRFbGtJam9pYW1sbElpd2libWxqYTA1aGJXVWlPaUpxYVdVaUxDSndjbTlrZFdOMFNXUWlPaklzSW5WelpYSnVZVzFsSWpvaWFtbGxJaXdpYkc5bmFXNU5iMlJsSWpvaVVFTWlMQ0pqY21WaGRHVkVZWFJsSWpveE5UY3lNalUxTWpnM05qSTVMQ0pqYjIxd1lXNTVWSGx3WlNJNk1Dd2ljbTlzWlZSNWNHVWlPaklzSW05eVowbGtJam8yTmpFM05EVTFOekExTURFM01qZzJOalUyTENKMWMyVnlWSGx3WlNJNklqQWlmUS5PUjg2c1BTbUpmdGFya2RfN3Q0azVzaTIxRENMQWpvQkctSEdpZTBiRVNoWnM4ZDU5N09uVGlNSEtSZVhtTXoyemxyUlZueVQ2X3o3bzUtaUItSzlnOFZ5UzRBR053OWVmaXhKUHRHbnZuZnI1dWZYNFdUNGpCVkN6Uy1rODJFTnlLZnZmd0o2bUZZTDBuMzRsQml1aC1Qa2NsTDh1b1IwSDQwRDRkZUZVbnc=","loginFlag":false,"expire":1440,"orgId":"6579126089719759000","userId":"1223"},"positionInfo":{"longitude":"100.12","latitude":"100.3","addr":"中国深圳"},"systemInfo":{"appVersion":"1.0","imei":"869881012802909","model":"QCC S8","osType":"0","osVersion":"6.0","sdkVersion":"23","isPDA":false}}

/***/ }),

/***/ "C9Fg":
/***/ (function(module, exports, __webpack_require__) {

"use strict";


module.exports = {
  // 打包关联
  scanOrderIn: {
    // 扫码入库
    scanOut: {
      path: '/scanOutIn/scanInSingle',
      method: 'put',
      server: 'code'
    },
    // 订单详情
    orderDetails: {
      path: '/stockOutIn/',
      method: 'get',
      server: 'order'
    },
    // 扫码记录
    scanRecord: {
      path: '/codeLog/scanOutIn',
      method: 'get',
      server: 'code'
    },
    // 出库单列表
    stockOutIn: {
      path: '/stockOutIn/in',
      method: 'GET',
      server: 'order'
    },
    // 取消订单
    cancel: {
      path: '/stockOutIn/cancel',
      method: 'put',
      server: 'order'
    },
    // 确认订单
    confirmOut: {
      path: '/stockOutIn/in',
      method: 'post',
      server: 'order'
    },
    // 订单数量
    orderNum: {
      path: '/stockOutIn/statistics',
      method: 'get',
      server: 'order'
    }
  }
};

/***/ }),

/***/ "CS8j":
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _typeof2 = __webpack_require__("pFYg");

var _typeof3 = _interopRequireDefault(_typeof2);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = {
  // 获取标签的真实属性值 包含小数
  // tag 标签对象
  // attr 要获取的属性值
  // isNumber 是否转换为number类型
  getTagComputedStyle: function getTagComputedStyle(tag, attr, isNumber) {
    if (!tag || !tag.nodeName || (typeof tag === 'undefined' ? 'undefined' : (0, _typeof3.default)(tag)) !== 'object') {
      return isNumber ? 0 : '';
    }
    var attrValue = window.getComputedStyle(tag)[attr];
    if (attrValue.indexOf('px') !== -1) {
      attrValue = attrValue.substring(0, attrValue.length - 2);
    }
    return isNumber ? Number(attrValue) : attrValue;
  },
  getStyle: function getStyle(obj, attr) {
    if (obj.currentStyle) {
      return obj.currentStyle[attr];
    } else {
      return document.defaultView.getComputedStyle(obj, null)[attr];
    }
  },
  setBodyFontSize: function setBodyFontSize(p) {
    var width = window.innerWidth;

    var px = width / 120;

    var body = document.getElementsByTagName('layout.css')[0];

    body.style.fontSize = px + 'px';
  },
  offsetTop: function offsetTop($event) {
    var target = $event.nodeName ? $event : $event.target;
    var offsetTop = 0;
    while (target.previousElementSibling !== null) {
      target = target.previousElementSibling;
      offsetTop += target.offsetHeight;
      if (target.style.marginTop !== '') {
        offsetTop += parseFloat(target.style.marginTop);
      }
      if (target.style.marginBottom !== '') {
        offsetTop += target.style.marginBottom;
      }
    }
    return offsetTop;
  },

  //
  offset: function offset($event) {
    var target = $event.nodeName ? $event : $event.target;
    var site = {
      left: target.offsetLeft + 'px',
      top: target.offsetTop + 'px'
    };
    return site;
  },
  position: function position($event) {
    var target = $event.nodeName ? $event : $event.target;
    var stTarget = $event.nodeName ? $event : $event.target;
    var scrollTop = 0;
    var site = {
      left: target.offsetLeft,
      top: target.offsetTop - scrollTop
    };
    while (target.offsetParent) {
      target = target.offsetParent;
      site.left += target.offsetLeft;
      site.top += target.offsetTop;
    }
    while (stTarget.parentNode && stTarget.parentNode.nodeName.toLowerCase() !== 'layout.css') {
      stTarget = stTarget.parentNode;
      scrollTop += stTarget.scrollTop;
    }
    site.top -= scrollTop;
    return site;
  }
};

/***/ }),

/***/ "DiNS":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
var render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('div',{attrs:{"id":"inStockDetails"}},[_c('div',{staticClass:"content"},[_c('div',{staticClass:"order-info"},[_c('p',{staticClass:"order-title"},[_vm._v("订单信息"),_c('span',{staticClass:"red-text",class:_vm.styleColorList[_vm.orderDetails.status],staticStyle:{"float":"right"}},[_vm._v(_vm._s(_vm._f("orderStatus")(_vm.orderDetails.status)))])]),_vm._v(" "),_c('ul',{staticClass:"order-item"},[_c('li',[_c('span',[_vm._v("订单号")]),_vm._v(" "),_c('p',[_c('span',{staticClass:"order-no",attrs:{"id":"order-no"}},[_vm._v(_vm._s(_vm.orderDetails.stockOutNo))]),_vm._v(" "),_c('a',{directives:[{name:"clipboard",rawName:"v-clipboard:copy",value:(_vm.orderDetails.stockOutNo),expression:"orderDetails.stockOutNo",arg:"copy"},{name:"clipboard",rawName:"v-clipboard:success",value:(_vm.$util.common.ObjectUtils.onCopySuccess),expression:"$util.common.ObjectUtils.onCopySuccess",arg:"success"},{name:"clipboard",rawName:"v-clipboard:error",value:(_vm.$util.common.ObjectUtils.onCopyError),expression:"$util.common.ObjectUtils.onCopyError",arg:"error"}],staticClass:"blue-text"},[_vm._v("复制")])])]),_vm._v(" "),_c('li',[_c('span',[_vm._v("下单时间")]),_vm._v(" "),_c('span',[_vm._v(_vm._s(_vm.orderDetails.createDate))])]),_vm._v(" "),_c('li',[_c('span',[_vm._v("创建人")]),_vm._v(" "),_c('span',[_vm._v(_vm._s(_vm.orderDetails.creator))])]),_vm._v(" "),_c('li',[_c('span',[_vm._v("订单来源")]),_vm._v(" "),_c('span',[_vm._v(_vm._s(_vm._f("orderType")(_vm.orderDetails.type)))])]),_vm._v(" "),_c('li',[_c('span',[_vm._v("订单备注")]),_vm._v(" "),(_vm.remarksList.length>0)?_c('span',{staticClass:"arrow-right",on:{"click":function($event){return _vm.selectRemarks()}}},[_vm._v(_vm._s(_vm.remarksList[0].note))]):_c('span',{staticClass:"arrow-right",on:{"click":function($event){return _vm.selectRemarks()}}})])])]),_vm._v(" "),_c('div',{staticClass:"order-info"},[_c('p',{staticClass:"order-title"},[_vm._v("商品信息")]),_vm._v(" "),_vm._l((_vm.orderDetails.skuBatchList),function(goods,index){return _c('ul',{key:index},[_c('div',{staticClass:"flex-between"},[_c('p',{staticClass:"goods-title"},[_vm._v(_vm._s(goods.name))]),_vm._v(" "),(goods.list.length==1&&(goods.list[0].batchNo==''||goods.list[0].batchNo==null))?_c('p',{staticClass:"min-width-60",on:{"click":function($event){return _vm.batchScanRecord(goods.list[0])}}},[_vm._v(">\n                        "),_c('span',{staticClass:"red-text"},[_vm._v(_vm._s(goods.list[0].inQuality))]),_vm._v(" "),_c('span',[_vm._v("/")]),_vm._v(" "),_c('span',[_vm._v(_vm._s(goods.list[0].quality))]),_vm._v(" "),_c('span',{staticStyle:{"color":"#999999"}},[_vm._v("("+_vm._s(goods.list[0].unitName)+")")])]):_vm._e()]),_vm._v(" "),(!(goods.list.length==1&&(goods.list[0].batchNo==''||goods.list[0].batchNo==null)))?_c('ul',{staticClass:"goods-item"},_vm._l((goods.list),function(batch,index){return _c('li',{key:index},[_c('span',[_vm._v(_vm._s(batch.batchNo))]),_vm._v(" "),_c('p',{on:{"click":function($event){return _vm.batchScanRecord(batch)}}},[_c('span',{staticClass:"red-text"},[_vm._v(_vm._s(batch.inQuality))]),_vm._v(" "),_c('span',[_vm._v("/")]),_vm._v(" "),_c('span',[_vm._v(_vm._s(batch.quality))]),_vm._v(" "),_c('span',{staticStyle:{"color":"#999999"}},[_vm._v("("+_vm._s(batch.unitName)+")")])])])}),0):_vm._e()])}),_vm._v(" "),_c('p',{staticClass:"goods-total"},[_vm._v("总共"),_c('span',{staticClass:"red-text"},[_vm._v(_vm._s(_vm.orderDetails.goodsTotal))]),_vm._v("种商品,数量"),_c('span',{staticClass:"red-text"},[_vm._v(_vm._s(_vm.orderDetails.goodsTotalCount))])])],2),_vm._v(" "),_c('div',{staticClass:"order-info"},[_c('p',{staticClass:"order-title"},[_vm._v("收货信息")]),_vm._v(" "),_c('ul',{staticClass:"order-item"},[_c('li',[_c('span',[_vm._v("收货组织")]),_vm._v(" "),_c('span',[_vm._v(_vm._s(_vm.orderDetails.inOrgName))])]),_vm._v(" "),_c('li',[_c('span',[_vm._v("收货仓库")]),_vm._v(" "),_c('span',[_vm._v(_vm._s(_vm.orderDetails.inWarehouseName))])])])]),_vm._v(" "),_c('div',{staticClass:"order-info"},[_c('p',{staticClass:"order-title"},[_vm._v("发货信息")]),_vm._v(" "),_c('ul',{staticClass:"order-item"},[_c('li',[_c('span',[_vm._v("发货组织")]),_vm._v(" "),_c('span',[_vm._v(_vm._s(_vm.orderDetails.outOrgName))])]),_vm._v(" "),_c('li',[_c('span',[_vm._v("发货仓库")]),_vm._v(" "),_c('span',[_vm._v(_vm._s(_vm.orderDetails.outWarehouseName))])])])])]),_vm._v(" "),_c('div',{staticClass:"oper-button"},[(_vm.orderDetails.status===2)?_c('span',{staticClass:"yellow-button",on:{"click":function($event){return _vm.cancel(_vm.orderDetails)}}},[_vm._v("订单拒收")]):_vm._e(),_vm._v(" "),((_vm.orderDetails.status == 2||_vm.orderDetails.status == 3)&&(_vm.orderDetails.scanIn==0))?_c('span',{staticClass:"yellow-button",on:{"click":function($event){return _vm.scan(_vm.orderDetails)}}},[_vm._v("扫码收货")]):_vm._e(),_vm._v(" "),((_vm.orderDetails.status == 2||_vm.orderDetails.status == 3)&&_vm.orderDetails.scanIn==1)?_c('span',{staticClass:"yellow-button",on:{"click":function($event){return _vm.confirm(_vm.orderDetails)}}},[_vm._v("确认收货")]):_vm._e()])])}
var staticRenderFns = []
var esExports = { render: render, staticRenderFns: staticRenderFns }
/* harmony default export */ __webpack_exports__["a"] = (esExports);

/***/ }),

/***/ "F7Wx":
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
//
//
//
//
//
//
//
//
//

exports.default = {
  data: function data() {
    return {
      transitionName: 'slide-left'
    };
  },
  beforeRouteUpdate: function beforeRouteUpdate(to, from, next) {
    var isBack = this.$router.isBack;
    if (isBack) {
      this.transitionName = 'slide-right';
    } else {
      this.transitionName = 'slide-left';
    }
    this.$router.isBack = false;
    next();
  }
};

/***/ }),

/***/ "FITS":
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _stringify = __webpack_require__("mvHQ");

var _stringify2 = _interopRequireDefault(_stringify);

var _typeof2 = __webpack_require__("pFYg");

var _typeof3 = _interopRequireDefault(_typeof2);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var CODE_SEGMENT = 'CODE_SEGMENT';
var ALL_WRAPPER = 'ALL_WRAPPER';
var WAREHOUSE_LIST = 'WAREHOUSE_LIST';
var SYSTEM_INFO = 'SYSTEM_INFO';
var GOODS_LIST = 'GOODS_LIST';
var HAND_GOODS_LIST = 'HAND_GOODS_LIST';
var APP_HAND_ORDER_DATA = 'APP_HAND_ORDER_DATA';
var POSITION_INFO = 'POSITION_INFO';
var USER_SELECT_DATA = 'USER_SELECT_DATA';

exports.default = {
  setCodeSegment: function setCodeSegment(code) {
    if ((typeof code === 'undefined' ? 'undefined' : (0, _typeof3.default)(code)) === 'object') {
      window.localStorage.setItem(CODE_SEGMENT, (0, _stringify2.default)(code));
    } else {
      window.localStorage.setItem(CODE_SEGMENT, '');
    }
  },
  getCodeSegment: function getCodeSegment() {
    var jsonStr = window.localStorage.getItem(CODE_SEGMENT);
    if (jsonStr && jsonStr !== '') {
      try {
        return JSON.parse(jsonStr);
      } catch (e) {
        console.error(e);
        return null;
      }
    }
    return null;
  },
  setGoodList: function setGoodList(good) {
    if ((typeof good === 'undefined' ? 'undefined' : (0, _typeof3.default)(good)) === 'object') {
      window.localStorage.setItem(GOODS_LIST, (0, _stringify2.default)(good));
    } else {
      window.localStorage.setItem(GOODS_LIST, '');
    }
  },
  getGoodList: function getGoodList() {
    var jsonStr = window.localStorage.getItem(GOODS_LIST);
    if (jsonStr && jsonStr !== '') {
      try {
        return JSON.parse(jsonStr);
      } catch (e) {
        console.error(e);
        return null;
      }
    }
    return null;
  },
  setHandGoodList: function setHandGoodList(good) {
    if ((typeof good === 'undefined' ? 'undefined' : (0, _typeof3.default)(good)) === 'object') {
      window.localStorage.setItem(HAND_GOODS_LIST, (0, _stringify2.default)(good));
    } else {
      window.localStorage.setItem(HAND_GOODS_LIST, '');
    }
  },
  getHandGoodList: function getHandGoodList() {
    var jsonStr = window.localStorage.getItem(HAND_GOODS_LIST);
    if (jsonStr && jsonStr !== '') {
      try {
        return JSON.parse(jsonStr);
      } catch (e) {
        console.error(e);
        return null;
      }
    }
    return null;
  },
  setAppHandOrderData: function setAppHandOrderData(data) {
    if ((typeof data === 'undefined' ? 'undefined' : (0, _typeof3.default)(data)) === 'object') {
      window.localStorage.setItem(APP_HAND_ORDER_DATA, (0, _stringify2.default)(data));
    } else {
      window.localStorage.setItem(APP_HAND_ORDER_DATA, '');
    }
  },
  getAppHandOrderData: function getAppHandOrderData() {
    var jsonStr = window.localStorage.getItem(APP_HAND_ORDER_DATA);
    if (jsonStr && jsonStr !== '') {
      try {
        return JSON.parse(jsonStr);
      } catch (e) {
        console.error(e);
        return null;
      }
    }
    return null;
  },
  removeCodeSegment: function removeCodeSegment() {
    window.localStorage.removeItem(CODE_SEGMENT);
  },
  setAllWrapper: function setAllWrapper(code) {
    if ((typeof code === 'undefined' ? 'undefined' : (0, _typeof3.default)(code)) === 'object') {
      window.localStorage.setItem(ALL_WRAPPER, (0, _stringify2.default)(code));
    } else {
      window.localStorage.setItem(ALL_WRAPPER, '');
    }
  },
  getAllWrapper: function getAllWrapper() {
    var jsonStr = window.localStorage.getItem(ALL_WRAPPER);
    if (jsonStr && jsonStr !== '') {
      try {
        return JSON.parse(jsonStr);
      } catch (e) {
        console.error(e);
        return [];
      }
    }
    return [];
  },
  removeAllWrapper: function removeAllWrapper() {
    window.localStorage.removeItem(ALL_WRAPPER);
  },
  setWarehouseList: function setWarehouseList(list) {
    if ((typeof list === 'undefined' ? 'undefined' : (0, _typeof3.default)(list)) === 'object') {
      window.localStorage.setItem(WAREHOUSE_LIST, (0, _stringify2.default)(list));
    } else {
      window.localStorage.setItem(WAREHOUSE_LIST, '');
    }
  },
  getWarehouseList: function getWarehouseList() {
    var jsonStr = window.localStorage.getItem(WAREHOUSE_LIST);
    if (jsonStr && jsonStr !== '') {
      try {
        return JSON.parse(jsonStr);
      } catch (e) {
        console.error(e);
        return null;
      }
    }
    return null;
  },
  removeWarehouseList: function removeWarehouseList() {
    window.localStorage.removeItem(WAREHOUSE_LIST);
  },
  setSystemInfo: function setSystemInfo(info) {
    if ((typeof info === 'undefined' ? 'undefined' : (0, _typeof3.default)(info)) === 'object') {
      window.localStorage.setItem(SYSTEM_INFO, (0, _stringify2.default)(info));
    } else {
      window.localStorage.setItem(SYSTEM_INFO, '');
    }
  },
  getSystemInfo: function getSystemInfo() {
    var jsonStr = window.localStorage.getItem(SYSTEM_INFO);
    if (jsonStr && jsonStr !== '') {
      try {
        return JSON.parse(jsonStr);
      } catch (e) {
        console.error(e);
        return null;
      }
    }
    return null;
  },
  setPositionInfo: function setPositionInfo(info) {
    if ((typeof info === 'undefined' ? 'undefined' : (0, _typeof3.default)(info)) === 'object') {
      window.localStorage.setItem(POSITION_INFO, (0, _stringify2.default)(info));
    } else {
      window.localStorage.setItem(POSITION_INFO, '');
    }
  },
  getPositionInfo: function getPositionInfo() {
    var jsonStr = window.localStorage.getItem(POSITION_INFO);
    if (jsonStr && jsonStr !== '') {
      try {
        return JSON.parse(jsonStr);
      } catch (e) {
        console.error(e);
        return null;
      }
    }
    return null;
  },
  setUserSelectData: function setUserSelectData(info) {
    if ((typeof info === 'undefined' ? 'undefined' : (0, _typeof3.default)(info)) === 'object') {
      window.localStorage.setItem(USER_SELECT_DATA, (0, _stringify2.default)(info));
    } else {
      window.localStorage.setItem(USER_SELECT_DATA, '');
    }
  },
  getUserSelectData: function getUserSelectData() {
    var jsonStr = window.localStorage.getItem(USER_SELECT_DATA);
    if (jsonStr && jsonStr !== '') {
      try {
        return JSON.parse(jsonStr);
      } catch (e) {
        console.error(e);
        return null;
      }
    }
    return null;
  },
  removeSystemInfo: function removeSystemInfo() {
    window.localStorage.removeItem(SYSTEM_INFO);
  },
  getIsPDA: function getIsPDA() {
    // I/LoginActivity: 设备信息: {"appVersion":"1.0","imei":"869881012802909","model":"QCC S8","osType":"0","osVersion":"6.0","sdkVersion":"23"}
    // I/Webview2Activity: 设备信息: {"appVersion":"1.0","imei":"A1000012665FC7","model":"70 series","osType":"0","osVersion":"6.0","sdkVersion":"23"}
    // I/Webview2Activity: 设备信息: {"appVersion":"1.0","imei":"866828020962038","model":"PDT-90F","osType":"0","osVersion":"5.1","sdkVersion":"22"}
    var systemInfo = this.getSystemInfo();
    // window.alert(JSON.stringify(systemInfo))
    var PDAModelList = ['QCC S8', '70 series', '70 Series', 'PDT-90F', 'MC33', 'msm8909'];
    return systemInfo.isPDA === undefined ? PDAModelList.indexOf(systemInfo.model) > -1 : systemInfo.isPDA;
  }
};

/***/ }),

/***/ "FX6q":
/***/ (function(module, exports) {

// removed by extract-text-webpack-plugin

/***/ }),

/***/ "Fu5R":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
var render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('div',{attrs:{"id":"remarksList"}},[(_vm.showEditRemarks!=0)?_c('div',{staticClass:"remarks-input"},[_c('van-field',{attrs:{"rows":"4","type":"textarea","maxlength":"50","placeholder":"请输入留言","show-word-limit":""},model:{value:(_vm.remarksInfo.note),callback:function ($$v) {_vm.$set(_vm.remarksInfo, "note", $$v)},expression:"remarksInfo.note"}}),_vm._v(" "),_c('div',{staticClass:"oper-button"},[_c('span',{staticClass:"common-button",on:{"click":_vm.cancelRemarks}},[_vm._v("清空")]),_vm._v(" "),_c('span',{staticClass:"blue-button",on:{"click":_vm.addRemarks}},[_vm._v("确认")])])],1):_vm._e(),_vm._v(" "),(_vm.showEditRemarks!=2)?_c('div',{staticClass:"remarks-list"},[_vm._m(0),_vm._v(" "),_c('ul',{staticClass:"remarks-details"},_vm._l((_vm.remarksInfos),function(remarks,index){return _c('li',{key:index,staticClass:"remarks-info"},[_c('p',[_c('span',[_vm._v(_vm._s(remarks.note))]),_c('span',{directives:[{name:"show",rawName:"v-show",value:(_vm.showEditRemarks!=0),expression:"showEditRemarks!=0"}],staticClass:"red-text",on:{"click":function($event){return _vm.deleteRemarks(remarks)}}},[_vm._v("删除")])]),_vm._v(" "),_c('p',[_vm._v(_vm._s(_vm.user.realName)+"在"+_vm._s(remarks.createDate)+"添加")])])}),0)]):_vm._e()])}
var staticRenderFns = [function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('p',[_c('span',[_vm._v("备注列表")])])}]
var esExports = { render: render, staticRenderFns: staticRenderFns }
/* harmony default export */ __webpack_exports__["a"] = (esExports);

/***/ }),

/***/ "G0M6":
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _defineProperty2 = __webpack_require__("bOdI");

var _defineProperty3 = _interopRequireDefault(_defineProperty2);

var _getters, _mutations;

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var NS = 'outOrder.';
exports.default = {
  state: {
    outOrder: {
      chooseOrgan: {}, // 已选组织
      chooseWareHouse: {}, // 已选仓库
      chooseRemarksInfo: [], // 评论列表
      chooseGoodsList: [], // 已选商品列表
      chooseDeliverWareHouse: {}, // 选择发货仓库
      timeVisible: false // 是否打开时间选择框
    }
  },
  getters: (_getters = {}, (0, _defineProperty3.default)(_getters, NS + 'organInfo', function (state) {
    return state.outOrder.chooseOrgan;
  }), (0, _defineProperty3.default)(_getters, NS + 'wareHouseInfo', function (state) {
    return state.outOrder.chooseWareHouse;
  }), (0, _defineProperty3.default)(_getters, NS + 'deliverWareHouseInfo', function (state) {
    return state.outOrder.chooseDeliverWareHouse;
  }), (0, _defineProperty3.default)(_getters, NS + 'remarksInfo', function (state) {
    return state.outOrder.chooseRemarksInfo;
  }), (0, _defineProperty3.default)(_getters, NS + 'goodsList', function (state) {
    return state.outOrder.chooseGoodsList;
  }), (0, _defineProperty3.default)(_getters, NS + 'timeVisible', function (state) {
    return state.outOrder.timeVisible;
  }), _getters),
  mutations: (_mutations = {}, (0, _defineProperty3.default)(_mutations, NS + 'changeOrganInfo', function (state, organ) {
    state.outOrder.chooseOrgan = organ;
  }), (0, _defineProperty3.default)(_mutations, NS + 'changeWareHouseInfo', function (state, wareHouse) {
    state.outOrder.chooseWareHouse = wareHouse;
  }), (0, _defineProperty3.default)(_mutations, NS + 'changeDeliverWareHouseInfo', function (state, wareHouse) {
    state.outOrder.chooseDeliverWareHouse = wareHouse;
  }), (0, _defineProperty3.default)(_mutations, NS + 'changeRemarksInfo', function (state, remarksInfo) {
    state.outOrder.chooseRemarksInfo = remarksInfo;
  }), (0, _defineProperty3.default)(_mutations, NS + 'changeGoodsList', function (state, goodsList) {
    state.outOrder.chooseGoodsList = goodsList;
  }), (0, _defineProperty3.default)(_mutations, NS + 'changeTimeVisible', function (state, timeVisible) {
    state.outOrder.timeVisible = timeVisible;
  }), _mutations)
};

/***/ }),

/***/ "GPWr":
/***/ (function(module, exports) {

module.exports = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABQAAAAZCAYAAAAxFw7TAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyZpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuNi1jMTM4IDc5LjE1OTgyNCwgMjAxNi8wOS8xNC0wMTowOTowMSAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENDIDIwMTcgKFdpbmRvd3MpIiB4bXBNTTpJbnN0YW5jZUlEPSJ4bXAuaWlkOjRGOUVCNjA4NEZDRTExRUE5RTU5Rjc3MkQ2NEJGRUFDIiB4bXBNTTpEb2N1bWVudElEPSJ4bXAuZGlkOjRGOUVCNjA5NEZDRTExRUE5RTU5Rjc3MkQ2NEJGRUFDIj4gPHhtcE1NOkRlcml2ZWRGcm9tIHN0UmVmOmluc3RhbmNlSUQ9InhtcC5paWQ6NEY5RUI2MDY0RkNFMTFFQTlFNTlGNzcyRDY0QkZFQUMiIHN0UmVmOmRvY3VtZW50SUQ9InhtcC5kaWQ6NEY5RUI2MDc0RkNFMTFFQTlFNTlGNzcyRDY0QkZFQUMiLz4gPC9yZGY6RGVzY3JpcHRpb24+IDwvcmRmOlJERj4gPC94OnhtcG1ldGE+IDw/eHBhY2tldCBlbmQ9InIiPz7ijxf5AAAB5ElEQVR42qSVPSxDURTHzythMBtIK0SDkAgJCQNTJRZRpBI2FhZBfIUY2gGJ2Ay16cIgpGWS1CAWH2FAIioiqFjMNTSp53/0tXm9ve+9tE7y73nv3HN+797ec99TVFUl0bpm1SI4t6ZmyA5x7BM6h4LQYXhDiYu1iggErA9uHXKSuT1D84AGpUCACuBWOYlyM374EsAJvinUDaxBc5S7pSawkJ4hZufB9R79zzyY5b7imvkp1v4Pu5jRVk800KlQrSN5H4kSHZypdPEgBX5A1bxkjww20q3QsCsz1uRkKbR7QrR9nNUdzPDY8NMrm5kI0xuPcY7E3AxsFKO8TCszyGlhYLkYrXFY74BBTpkt3y01WEOcgbdi9ClqDYzIc+4YGBKj3BpWZpATYmAAiumj3GfcGkbGY5JeZEYgdVL4DC+KGe0NRP0dCtVVJO8f300bewUnZTkFLEHgHqrKc49euP0AjP3tMl/AjUFqHjCuGdcYlG4bBMJwW3kA/VotZQA1m4JucoBdQ9NWb+xKuCuo1AL2BbVidm/6YNZJQcIrXA/0bQLjb8mgCJMCNegl3BCUMNiEUeScymoNzzIKjuAmJEOTGNsxqjN9OaDQD+fThbyIbZq+NGTfZcl32stLBcxnlfsrwAAZCaHIjmhRMQAAAABJRU5ErkJggg=="

/***/ }),

/***/ "I9mY":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
var render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('div',{attrs:{"id":"batchScanRecord"}},[(_vm.codeBatchList.length>0)?_c('div',{staticClass:"content"},[_c('p',{staticClass:"batch-name"},[_vm._v("码值记录")]),_vm._v(" "),_c('ul',{staticClass:"list-item"},_vm._l((_vm.codeBatchList),function(item,index){return _c('li',{key:index,staticClass:"code-info"},[_c('span',[_vm._v(_vm._s(item.codeInfo.categoryName))]),_vm._v(" "),_c('span',[_vm._v(_vm._s(_vm.$util.common.ObjectUtils.filterCode(item.operateCode)))])])}),0)]):_c('div',{staticClass:"empty-list"},[_c('img',{attrs:{"src":__webpack_require__("u8EM"),"alt":""}}),_vm._v(" "),_c('p',{staticClass:"gray-text"},[_vm._v("暂无码值信息")])])])}
var staticRenderFns = []
var esExports = { render: render, staticRenderFns: staticRenderFns }
/* harmony default export */ __webpack_exports__["a"] = (esExports);

/***/ }),

/***/ "IcnI":
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _vue = __webpack_require__("lRwf");

var _vue2 = _interopRequireDefault(_vue);

var _vuex = __webpack_require__("SJI6");

var _vuex2 = _interopRequireDefault(_vuex);

var _global = __webpack_require__("6zCF");

var _pack = __webpack_require__("wkJh");

var _pack2 = _interopRequireDefault(_pack);

var _batchSearch = __webpack_require__("f6Gb");

var _batchSearch2 = _interopRequireDefault(_batchSearch);

var _outOrder = __webpack_require__("G0M6");

var _outOrder2 = _interopRequireDefault(_outOrder);

var _scanOutOrder = __webpack_require__("bBFl");

var _scanOutOrder2 = _interopRequireDefault(_scanOutOrder);

var _stockStatistics = __webpack_require__("kqKe");

var _stockStatistics2 = _interopRequireDefault(_stockStatistics);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

_vue2.default.use(_vuex2.default);
var store = new _vuex2.default.Store({
  actions: _global.actions,
  state: _global.state,
  getters: _global.getters,
  mutations: _global.mutations,
  modules: {
    pack: _pack2.default,
    batchSearch: _batchSearch2.default,
    outOrder: _outOrder2.default,
    scanOutOrder: _scanOutOrder2.default,
    stockStatistics: _stockStatistics2.default
  }
});

exports.default = store;

/***/ }),

/***/ "IpUx":
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _getIterator2 = __webpack_require__("BO1k");

var _getIterator3 = _interopRequireDefault(_getIterator2);

var _vant = __webpack_require__("Fd2+");

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = {
  name: 'scanRecordIn',
  data: function data() {
    return {
      orderStatus: [{ name: '待发货', id: 0, status: 0 }, { name: '发货中', id: 1, status: 1 }, { name: '已发货', id: 2, status: 2 }, { name: '已作废', id: 3, status: 3 }, { name: '全部', id: -1, status: -1 }],
      scannedInfo: {
        vid: '',
        cid: '',
        code: '',
        codeType: 1
      },
      scanRecordList: [],
      orderDetails: {},
      positionInfo: this.$util.business.LocalUtils.getPositionInfo(), // 位置信息
      systemInfo: this.$util.business.LocalUtils.getSystemInfo(),
      scanViewParam: {
        mode: 'QR',
        height: 30,
        message: '',
        isPullable: true,
        header: '',
        fixed: true
      },
      show: false,
      mode: '1'
    };
  },
  created: function created() {
    this.scanViewParam.header = this.$route.meta.title; // 将header传给原生设备
    // 初始化摄像头
    this.$util.business.AppUtils.initScanView(this.scanViewParam.mode, this.scanViewParam.height, this.scanViewParam.message, this.scanViewParam.isPullable, this.scanViewParam.header, this.scanViewParam.fixed, function (result) {});
  },
  activated: function activated() {
    var _this = this;

    this.registerHandler();
    // 回到页面打开摄像头
    if (!this.isInitScanView) {
      this.$util.business.AppUtils.showScanView(true, function () {
        _this.$util.business.AppUtils.changeScanView(_this.scanViewParam.height, _this.scanViewParam.message, _this.scanViewParam.isPullable, _this.scanViewParam.header, _this.scanViewParam.fixed, function (result) {});
      });
    }
    if (this.$route.params.id !== undefined) {
      this.getOrderDetails();
    }
  },
  deactivated: function deactivated() {
    // 离开页面关闭摄像头
    this.$util.business.AppUtils.showScanView(false, function (result) {});
  },

  methods: {
    // 注册native调用的js方法
    registerHandler: function registerHandler() {
      var _this2 = this;

      this.$util.business.AppUtils.syncScanResult(function (data, cb) {
        _this2.scannedInfo = data;
        _this2.codeScan();
      });
    },
    filterMode: function filterMode() {
      switch (this.mode) {
        case '1':
          return '按件(切换)';
        case '2':
          return '按垛(切换)';
        case '3':
          return '反向(切换)';
      }
    },
    selectScanType: function selectScanType() {
      this.show = true;
    },
    codeScan: function codeScan() {
      var _this3 = this;

      var scanParam = {
        stockOutNo: this.orderDetails.stockOutNo,
        lon: this.positionInfo.longitude || '',
        lat: this.positionInfo.latitude || '',
        address: this.positionInfo.addr || '',
        time: '',
        mode: this.mode,
        deviceType: this.systemInfo.model || '',
        imei: this.systemInfo.imei
      };
      scanParam.codeList = [];
      var code = {};
      code.vid = this.scannedInfo.vid;
      code.cid = this.scannedInfo.cid;
      code.code = this.scannedInfo.code;
      code.codeType = this.scannedInfo.codeType;
      scanParam.codeList.push(code);
      this.$backend.request(this.$api.scanOrderIn.scanOut, scanParam).then(function (res) {
        _this3.$store.commit('global.changeScanFlag', false);
        if (res.success) {
          _this3.$util.business.AppUtils.voiceAlert('ScanSuccess');
          _this3.getOrderDetails();
        } else {
          _this3.$util.business.AppUtils.voiceAlert('ScanFail');
          _this3.$util.business.AppUtils.openMessageBox('提示', '', res.message, '', '确定', false, function (result) {});
        }
      });
    },
    getOrderDetails: function getOrderDetails() {
      var _this4 = this;

      this.$backend.request(this.$api.scanOrderIn.orderDetails, this.$route.params.id).then(function (result) {
        if (result.success) {
          _this4.orderDetails = result.data;
          _this4.orderDetails.skuBatchList = _this4.$util.common.ArrayUtils.groupArr(_this4.orderDetails.bizOrderDetails, 'skuId', 'skuName');
          _this4.orderDetails.scanNum = 0;
          _this4.orderDetails.totalNum = 0;
          var _iteratorNormalCompletion = true;
          var _didIteratorError = false;
          var _iteratorError = undefined;

          try {
            for (var _iterator = (0, _getIterator3.default)(_this4.orderDetails.bizOrderDetails), _step; !(_iteratorNormalCompletion = (_step = _iterator.next()).done); _iteratorNormalCompletion = true) {
              var sku = _step.value;

              _this4.orderDetails.scanNum += parseInt(sku.inQuality);
              _this4.orderDetails.totalNum += parseInt(sku.quality);
            }
          } catch (err) {
            _didIteratorError = true;
            _iteratorError = err;
          } finally {
            try {
              if (!_iteratorNormalCompletion && _iterator.return) {
                _iterator.return();
              }
            } finally {
              if (_didIteratorError) {
                throw _iteratorError;
              }
            }
          }

          _this4.getScanRecordList();
        } else {
          (0, _vant.Toast)(result.message);
        }
      });
    },
    getScanRecordList: function getScanRecordList() {
      var _this5 = this;

      var param = {};
      param.stockOutNo = this.orderDetails.stockOutNo;
      param.operateType = '11';
      this.$backend.request(this.$api.scanOrderIn.scanRecord, param).then(function (result) {
        if (result.success) {
          _this5.scanRecordList = result.data;
        } else {
          (0, _vant.Toast)(result.message);
        }
      });
    }
  }
}; //
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

/***/ }),

/***/ "J3hU":
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _map = __webpack_require__("ifoU");

var _map2 = _interopRequireDefault(_map);

exports.default = function (router) {
  router.beforeEach(function (to, from, next) {
    try {
      beforeRouteEnter(to, from, next);
    } catch (e) {
      console.error(e);
    }
  });
};

var _business = __webpack_require__("ySQA");

var _business2 = _interopRequireDefault(_business);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

// 过滤的路由name
var filters = ['login', 'error', '500', '400'];

// 过滤的路由map
var filterMap = new _map2.default();
filters.forEach(function (item) {
  filterMap.set(item, true);
});

/**
 * 路由跳转之前
 */
function beforeRouteEnter(to, from, next) {
  document.body.scrollTop = 0;
  // 某些过滤的请求，包括login,error等
  if (isFilter(to.name)) {
    next();
    return;
  }
  if (from.name === null) return loadBaseData(next, to);
  next();
}

/**
 * 是否在过滤范围内
 */
function isFilter(name) {
  return filterMap.get(name);
}

/**
 * 加载基础数据
 */
function loadBaseData(next, to) {
  // 请求基础数据
  _business2.default.AppUtils.getData(function () {
    next();
  });
}

/***/ }),

/***/ "L8QT":
/***/ (function(module, exports) {

// removed by extract-text-webpack-plugin

/***/ }),

/***/ "M7S5":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
var render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('div',[_c('transition',{attrs:{"name":_vm.transitionName}},[_c('keep-alive',[_c('router-view',{staticClass:"child-view"})],1)],1)],1)}
var staticRenderFns = []
var esExports = { render: render, staticRenderFns: staticRenderFns }
/* harmony default export */ __webpack_exports__["a"] = (esExports);

/***/ }),

/***/ "MLfX":
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _extends2 = __webpack_require__("Dd8w");

var _extends3 = _interopRequireDefault(_extends2);

var _vuex = __webpack_require__("SJI6");

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = {
  name: 'batchScanRecord',
  computed: (0, _extends3.default)({}, (0, _vuex.mapGetters)({
    codeBatchList: 'global.batchScanRecord'
  })),
  data: function data() {
    return {};
  },
  activated: function activated() {
    /* for (let i = 0; i < 50; i++) {
      this.codeBatchList.push({code: i})
    } */
  },

  methods: {}
}; //
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

/***/ }),

/***/ "Mlnd":
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = {
  //   @func
  //     * @desc 阿拉伯数字单位转换，并保留 n 位小数：1 0000 -> 1 万，1 0000 0000 -> 亿，以此类推。
  // * @param {Number} num - 需要转换的数字
  // * @param {Number} digit - 需保留的小数位数，默认保留两位小数
  // * @returns {String} 转换后的数字
  unitConvert: function unitConvert(num, digit) {
    var unit = '';
    var newNum = '';
    // 默认保留两位小数
    if (digit === null || typeof digit === 'undefined') {
      digit = 2;
    }
    // 判断 num 是否为空
    if (num === null || typeof num === 'undefined') {
      return;
    }
    // 判断 num 是否为数字
    if (!isNaN(num)) {
      if (num < 10000) {
        // 小于 1 0000，原样输出
        newNum = num;
      } else if (num >= 10000 && num < 100000000) {
        // 大于 1 0000 小于 1 0000 0000
        unit = '万';
        newNum = (num / 10000).toFixed(digit) + unit;
      } else if (num >= 100000000) {
        // 大于 1 0000 0000
        unit = '亿';
        newNum = (num / 100000000).toFixed(digit) + unit;
      }
      return newNum;
    } else {
      return num;
    }
  },

  /* 比较两个数的大小,返回true或者false */
  compareNum: function compareNum(num1, num2) {
    var a = num1 + '';
    var b = num2 + '';
    if (a.length > b.length) {
      return true;
    }
    if (a.length < b.length) {
      return false;
    }
    if (a.length > 0 && a.length <= 12) {
      return parseInt(a) >= parseInt(b);
    }
    if (a.length > 12 && a.length <= 24) {
      if (parseInt(a.substring(0, 12)) !== parseInt(b.substring(0, 12))) {
        return parseInt(a.substring(0, 12)) >= parseInt(b.substring(0, 12));
      } else {
        return parseInt(a.substring(12, a.length)) >= parseInt(b.substring(12, b.length));
      }
    }
    if (a.length > 24 && a.length <= 36) {
      if (parseInt(a.substring(0, 12)) !== parseInt(b.substring(0, 12))) {
        return parseInt(a.substring(0, 12)) >= parseInt(b.substring(0, 12));
      } else if (parseInt(a.substring(12, 24)) !== parseInt(b.substring(12, 24))) {
        return parseInt(a.substring(12, 24)) >= parseInt(b.substring(12, 24));
      } else {
        return parseInt(a.substring(24, a.length)) >= parseInt(b.substring(24, b.length));
      }
    }
  }
};

/***/ }),

/***/ "NG5F":
/***/ (function(module, exports) {

// removed by extract-text-webpack-plugin

/***/ }),

/***/ "Ot9J":
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _extends2 = __webpack_require__("Dd8w");

var _extends3 = _interopRequireDefault(_extends2);

var _vant = __webpack_require__("Fd2+");

var _vuex = __webpack_require__("SJI6");

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

exports.default = {
  name: 'inStockDetails',
  computed: (0, _extends3.default)({}, (0, _vuex.mapGetters)({
    remarksList: 'outOrder.remarksInfo',
    outInDetails: 'global.outInDetails'
  })),
  data: function data() {
    return {
      orderStatus: [{ name: '待发货', id: 0, status: 0 }, { name: '发货中', id: 1, status: 1 }],
      orderDetails: {},
      styleColorList: ['blue-text', 'yellow-text', 'yellow-text', 'yellow-text', 'green-text', 'red-text']
    };
  },
  activated: function activated() {
    if (this.$route.params.id !== undefined) {
      this.getOrderDetails();
    }
  },

  filters: {
    orderStatus: function orderStatus(data) {
      if (data === 2) {
        return '待收货';
      } else if (data === 3) {
        return '收货中';
      } else if (data === 4) {
        return '已收货';
      } else if (data === 6) {
        return '已拒收';
      } else if (data === 5) {
        return '已取消';
      }
    },
    orderType: function orderType(data) {
      if (data === 1) {
        return '订货单';
      } else if (data === 2) {
        return '调拨单';
      } else if (data === 3) {
        return '采购单';
      } else if (data === 4) {
        return '退货单';
      } else if (data === 5) {
        return '出库单';
      } else if (data === 6) {
        return '入库单';
      }
    }
  },
  methods: {
    confirm: function confirm(order) {
      console.log(order);
      this.$store.commit('global.changeOutStockGoods', order);
      this.$router.push({ name: 'confirmIn' });
    },
    batchScanRecord: function batchScanRecord(sku) {
      var _this = this;

      var param = {};
      param.stockOutNo = this.orderDetails.stockOutNo;
      param.operateType = '11';
      param.skuId = sku.skuId;
      param.batchNo = sku.batchNo === null ? '' : sku.batchNo;
      this.$backend.request(this.$api.scanOrderIn.scanRecord, param).then(function (result) {
        if (result.success) {
          _this.$store.commit('global.changeBatchScanRecord', result.data);
          _this.$router.push({ name: 'batchScanRecord' });
        } else {
          (0, _vant.Toast)(result.message);
        }
      });
    },
    scan: function scan(order) {
      this.$router.push({ name: 'scanRecordIn', params: { id: order.id } });
    },
    cancel: function cancel(order) {
      var _this2 = this;

      if (!(order.status === 2)) {
        return;
      }
      _vant.Dialog.confirm({
        title: '拒收订单',
        message: '是否拒收当前入库单'
      }).then(function () {
        var param = {};
        param.id = order.id;
        return _this2.$backend.request(_this2.$api.scanOrderIn.cancel, param).then(function (res) {
          if (res.success) {
            _this2.getOrderDetails();
          } else {
            (0, _vant.Toast)(res.message);
          }
        });
      }).catch(function () {});
    },
    selectRemarks: function selectRemarks() {
      this.$store.commit('global.changeShowEditRemarks', 0);
      this.$router.push({ name: 'remarksList' });
    },
    getOrderDetails: function getOrderDetails() {
      var _this3 = this;

      this.$backend.request(this.$api.scanOrderIn.orderDetails, this.$route.params.id).then(function (result) {
        if (result.success) {
          _this3.orderDetails = result.data;
          /* this.orderDetails.operationType = this.outInDetails.operationType */
          _this3.orderDetails.skuBatchList = _this3.$util.common.ArrayUtils.groupArr(_this3.orderDetails.bizOrderDetails, 'skuId', 'skuName');
          _this3.orderDetails.goodsTotal = _this3.orderDetails.skuBatchList.length;
          _this3.orderDetails.goodsTotalCount = (_this3.orderDetails.skuBatchList || []).flatMap(function (item) {
            return (item.list || []).map(function (detail) {
              return detail.quality;
            });
          }).reduce(function (count, curr) {
            count += parseInt(curr);
            return count;
          }, 0);
          _this3.$store.commit('outOrder.changeRemarksInfo', _this3.orderDetails.remarksInfos || []);
        } else {
          (0, _vant.Toast)(result.message);
        }
      });
    }
  }
};

/***/ }),

/***/ "PeFb":
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _getIterator2 = __webpack_require__("BO1k");

var _getIterator3 = _interopRequireDefault(_getIterator2);

var _extends2 = __webpack_require__("Dd8w");

var _extends3 = _interopRequireDefault(_extends2);

var _vuex = __webpack_require__("SJI6");

var _vant = __webpack_require__("Fd2+");

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

exports.default = {
  name: 'confirmOut',
  computed: (0, _extends3.default)({}, (0, _vuex.mapGetters)({
    outOrganInfo: 'global.outOrganInfo',
    inOrganInfo: 'global.inOrganInfo',
    outWareHouseInfo: 'global.outWareHouseInfo',
    inWareHouseInfo: 'global.inWareHouseInfo',
    remarksInfo: 'outOrder.remarksInfo',
    outStockGoods: 'global.outStockGoods'
  })),
  data: function data() {
    return {
      selectBrand: 0,
      search: {
        keyword: ''
      }
    };
  },
  activated: function activated() {},
  created: function created() {},

  methods: {
    next: function next() {},
    selectGoods: function selectGoods() {},
    goBack: function goBack() {
      window.history.go(-1);
    },
    submitOrder: function submitOrder() {
      var _this = this;

      var param = {};
      param.id = this.outStockGoods.id;
      param.bizOrderDetails = [];
      var _iteratorNormalCompletion = true;
      var _didIteratorError = false;
      var _iteratorError = undefined;

      try {
        for (var _iterator = (0, _getIterator3.default)(this.outStockGoods.skuBatchList), _step; !(_iteratorNormalCompletion = (_step = _iterator.next()).done); _iteratorNormalCompletion = true) {
          var order = _step.value;
          var _iteratorNormalCompletion2 = true;
          var _didIteratorError2 = false;
          var _iteratorError2 = undefined;

          try {
            for (var _iterator2 = (0, _getIterator3.default)(order.list), _step2; !(_iteratorNormalCompletion2 = (_step2 = _iterator2.next()).done); _iteratorNormalCompletion2 = true) {
              var sku = _step2.value;

              param.bizOrderDetails.push({ id: sku.id, quality: sku.quality });
            }
          } catch (err) {
            _didIteratorError2 = true;
            _iteratorError2 = err;
          } finally {
            try {
              if (!_iteratorNormalCompletion2 && _iterator2.return) {
                _iterator2.return();
              }
            } finally {
              if (_didIteratorError2) {
                throw _iteratorError2;
              }
            }
          }
        }
      } catch (err) {
        _didIteratorError = true;
        _iteratorError = err;
      } finally {
        try {
          if (!_iteratorNormalCompletion && _iterator.return) {
            _iterator.return();
          }
        } finally {
          if (_didIteratorError) {
            throw _iteratorError;
          }
        }
      }

      console.log(this.orderForm);
      this.$backend.request(this.$api.scanOrderIn.confirmOut, param).then(function (res) {
        if (res.success) {
          _this.$router.push({ name: 'orderInStock' });
        } else {
          (0, _vant.Toast)(res.message);
        }
      });
    },
    toSelectOrgan: function toSelectOrgan(data) {
      this.$router.push({ name: 'selectOrgan', params: { flag: data, showOrg: false, showWare: true, isSelf: true } });
    },
    selectRemarks: function selectRemarks() {
      this.$router.push({ name: 'remarksList' });
    }
  },
  watch: {}
};

/***/ }),

/***/ "R9Oq":
/***/ (function(module, exports) {

// removed by extract-text-webpack-plugin

/***/ }),

/***/ "SJI6":
/***/ (function(module, exports) {

module.exports = Vuex;

/***/ }),

/***/ "SgIK":
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _getIterator2 = __webpack_require__("BO1k");

var _getIterator3 = _interopRequireDefault(_getIterator2);

var _extends2 = __webpack_require__("Dd8w");

var _extends3 = _interopRequireDefault(_extends2);

var _vant = __webpack_require__("Fd2+");

var _vuex = __webpack_require__("SJI6");

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

exports.default = {
  name: 'sureOrder',
  computed: (0, _extends3.default)({}, (0, _vuex.mapGetters)({
    user: 'global.user',
    outWareHouseInfo: 'global.outWareHouseInfo',
    inWareHouseInfo: 'global.inWareHouseInfo',
    outOrganInfo: 'global.outOrganInfo',
    inOrganInfo: 'global.inOrganInfo',
    orderStockConfig: 'global.orderStockConfig',
    organLevelNum: 'global.organLevelNum'
  })),
  data: function data() {
    return {
      defaultSelect: 0,
      organList: [{
        text: '经销商',
        dot: true,
        value: 0,
        children: []
      }, {
        text: '工厂',
        dot: true,
        value: 1,
        children: []
      }, {
        text: '企业',
        dot: true,
        value: 2,
        children: []
      }],
      organListTemp: {
        org0: [],
        org1: [],
        org2: []
      },
      pageTotal: '',
      finished: false,
      loading: false,
      queryListParam: {
        current: 1,
        rows: 20,
        order: 'createDate',
        asc: false,
        keyString: '',
        parentId: '',
        orgType: '',
        displayFlag: true
      },
      parentIdList: []
    };
  },

  /*
    * $route.params.flag
    * 0 出  1进
    * $route.params.organFlag 0 下级  1上级  2自己  roleType 2企业用户  3 经销商用户 4 工厂用户
    * */
  activated: function activated() {
    switch (this.user.roleType) {
      case 2:
        this.defaultSelect = 2;
        this.queryListParam.orgType = 0;
        break;
      case 3:
        this.defaultSelect = 0;
        this.queryListParam.orgType = 3;
        break;
      case 4:
        this.defaultSelect = 1;
        this.queryListParam.orgType = 2;
        break;
    }
    this.queryListParam.parentId = '';
    this.$store.commit('global.changeOrganLevelNum', 0);
    this.clearFilter();
    this.clearOrganData();
    this.getOrganList(this.$route.params.organFlag);
  },
  created: function created() {},

  watch: {
    organLevelNum: function organLevelNum(newValue, oldValue) {
      console.log('newValue' + newValue);
      console.log('oldValue' + oldValue);
      if (oldValue > newValue) {
        this.parentIdList.pop();
      }
      if (newValue >= 0) {
        this.getOrganList(this.$route.params.organFlag);
      }
    }
  },
  methods: {
    changeType: function changeType(value) {
      this.clearFilter();
      this.$store.commit('global.changeOrganLevelNum', 0);
      this.parentIdList = [];
      this.getOrganList(this.$route.params.organFlag);
    },
    getLowerOrgan: function getLowerOrgan(wareHouse) {
      this.clearFilter();
      var num = this.organLevelNum + 1;
      this.$store.commit('global.changeOrganLevelNum', num);
      this.parentIdList.push(wareHouse.orgId);
    },
    clearFilter: function clearFilter() {
      try {
        document.getElementById('organ-list').scrollTop = 0;
      } catch (e) {
        console.log(e);
      }
      this.finished = false;
      this.loading = false;
      this.queryListParam.keyString = '';
      this.queryListParam.current = 1;
    },
    isShowArrow: function isShowArrow() {
      if (this.orderStockConfig.skipLevel === 1 && (this.user.roleType === 3 || this.user.roleType === 2) && this.$route.params.flag === 1 && this.$route.params.type === 'scanCodeOut' && this.defaultSelect === 0) {
        return true;
      } else {
        return false;
      }
    },
    onLoad: function onLoad() {
      console.log('下拉');
      this.queryListParam.current++;
      if (this.queryListParam.current > this.pageTotal) {
        this.finished = true;
        return;
      }
      this.getOrganList(this.$route.params.organFlag, true);
    },

    // 企业用户不限制  退货单,入库单不限制  允许工厂用户发给经销商时不限制
    showType: function showType() {
      return (this.user.roleType === 2 || this.$route.params.type === 'inStockOrder' || this.$route.params.type === 'returnOrder' || this.orderStockConfig.factoryToDealer === 1 && this.user.roleType === 4 && this.$route.params.flag === 1 && this.$route.params.type === 'scanCodeOut') && this.$route.params.type !== 'traceAudit';
    },
    filterData: function filterData() {
      this.queryListParam.current = 1;
      /* this.queryListParam.parentId = '' */
      try {
        document.getElementById('organ-list').scrollTop = 0;
      } catch (e) {
        console.log(e);
      }
      this.finished = false;
      this.getOrganList(this.$route.params.organFlag);
      /* if (this.search.keyword === '') {
        this.organList[0].children = this.organListTemp.org0
        this.organList[1].children = this.organListTemp.org1
        this.organList[2].children = this.organListTemp.org2
        return
      }
      console.log(this.organListTemp.org0)
      console.log(this.organListTemp.org1)
      console.log(this.organListTemp.org2)
      this.organList[0].children = this.organListTemp.org0.filter((item) => {
        return item.orgName.indexOf(this.search.keyword) !== -1 || item.warehouseName.indexOf(this.search.keyword) !== -1
      })
      this.organList[1].children = this.organListTemp.org1.filter((item) => {
        return item.orgName.indexOf(this.search.keyword) !== -1 || item.warehouseName.indexOf(this.search.keyword) !== -1
      })
      this.organList[2].children = this.organListTemp.org2.filter((item) => {
        return item.orgName.indexOf(this.search.keyword) !== -1 || item.warehouseName.indexOf(this.search.keyword) !== -1
      }) */
    },
    selectWareHouse: function selectWareHouse(item) {
      var num = this.organLevelNum - 1;
      this.$store.commit('global.changeOrganLevelNum', num);
      var wareHouseInfo = {};
      wareHouseInfo.id = item.warehouseId;
      wareHouseInfo.warehouseName = item.warehouseName;
      var organInfo = {};
      organInfo.id = item.orgId;
      organInfo.name = item.orgName;
      if (this.$route.params.flag === 0) {
        this.$store.commit('global.changeOutWareHouseInfo', wareHouseInfo);
        this.$store.commit('global.changeOutOrganInfo', organInfo);
        /* this.$store.commit('global.changeOutWareHouseInfo', item) */
      } else {
        this.$store.commit('global.changeInWareHouseInfo', wareHouseInfo);
        this.$store.commit('global.changeInOrganInfo', organInfo);
      }
      window.history.go(-1);
    },
    addClass: function addClass(data, num) {
      this.$nextTick(function () {
        if (document.getElementsByClassName('van-dropdown-item__content')[0] !== undefined) {
          console.log(data);
          document.getElementsByClassName('van-dropdown-item__content')[0].children[num].style.display = data;
        }
      });
    },
    openDropdownMenu: function openDropdownMenu() {
      this.addClass('', 0);
      this.addClass('', 1);
      // 如果是登陆用户是企业,而且是出库单,扫码出库应用,且为接收组织选项,那么不展示工厂
      // 如果是登陆用户是企业,而且是出库单,扫码出库应用,且为发货组织选项,那么不展示经销商
      if (this.user.roleType === 2 && this.$route.params.flag === 1 && this.$route.params.type === 'scanCodeOut') {
        console.log(1);
        this.addClass('none', 1);
      } else if (this.user.roleType === 2 && this.$route.params.flag === 0 && this.$route.params.type === 'scanCodeOut') {
        console.log(2);
        this.addClass('none', 0);
      }
    },
    clearOrganData: function clearOrganData() {
      var _iteratorNormalCompletion = true;
      var _didIteratorError = false;
      var _iteratorError = undefined;

      try {
        for (var _iterator = (0, _getIterator3.default)(this.organList), _step; !(_iteratorNormalCompletion = (_step = _iterator.next()).done); _iteratorNormalCompletion = true) {
          var organ = _step.value;

          organ.children = [];
        }
      } catch (err) {
        _didIteratorError = true;
        _iteratorError = err;
      } finally {
        try {
          if (!_iteratorNormalCompletion && _iterator.return) {
            _iterator.return();
          }
        } finally {
          if (_didIteratorError) {
            throw _iteratorError;
          }
        }
      }
    },
    getOrganList: function getOrganList(data, flag) {
      var _this = this;

      switch (this.defaultSelect) {
        case 0:
          this.queryListParam.orgType = 3;
          break;
        case 1:
          this.queryListParam.orgType = 2;
          break;
        case 2:
          this.queryListParam.orgType = 0;
          break;
      }
      this.queryListParam.parentId = this.parentIdList.length > 0 ? this.parentIdList[this.parentIdList.length - 1] : this.user.roleType === 2 && this.defaultSelect === 0 && this.$route.params.type === 'scanCodeOut' ? this.user.orgId : '';
      var url = this.$commonApi.common.directLowerOrg;
      if (data === 1) {
        url = this.$commonApi.common.EqualOrg;
      } else if (data === 2) {
        url = this.$commonApi.common.currentOrg;
        console.log(this.user);
      } else if (this.$route.params.type === 'traceAudit') {
        // 溯源稽应用查经销商
        this.defaultSelect = 0;
        this.queryListParam.orgType = 3;
        url = this.$commonApi.common.directLowerOrgOrAll;
      }
      // 跨级发货
      if (this.orderStockConfig.skipLevel === 1 && (this.user.roleType === 3 || this.user.roleType === 2) && this.$route.params.flag === 1 && this.$route.params.type === 'scanCodeOut') {
        url = this.$commonApi.common.allLowerOrg;
      }
      // 工厂发货给经销商
      if (this.orderStockConfig.factoryToDealer === 1 && this.user.roleType === 4 && this.$route.params.flag === 1 && this.$route.params.type === 'scanCodeOut') {
        url = this.$commonApi.common.factoryAndDealer;
      }
      this.queryListParam.orgId = '';
      if (this.$route.params.orgId !== undefined) {
        this.queryListParam.orgId = this.$route.params.orgId;
      }
      if (this.$route.params.flag === 0) {
        this.queryListParam.displayFlag = false;
      } else {
        this.queryListParam.displayFlag = true;
      }
      this.$backend.request(url, this.queryListParam).then(function (result) {
        _this.loading = false;
        if (result) {
          _this.pageTotal = Math.ceil(result.total / _this.queryListParam.rows);
          if (!flag) {
            _this.clearOrganData();
          }
          if (_this.$route.params.type === 'traceAudit') {
            result.rows.forEach(function (item) {
              if (item.orgName === null) {
                item.orgName = '';
              }
              if (item.warehouseName === null) {
                item.warehouseName = '';
              }
              _this.organList[0].children.push(item);
            });
          } else {
            result.rows.forEach(function (item) {
              if (item.orgName === null) {
                item.orgName = '';
              }
              if (item.warehouseName === null) {
                item.warehouseName = '';
              }
              if (item.orgType === 0) {
                _this.organList[2].children.push(item);
              } else if (item.orgType === 2) {
                _this.organList[1].children.push(item);
              } else {
                _this.organList[0].children.push(item);
              }
            });
          }
        } else {
          (0, _vant.Toast)(result.message);
        }
      });
    }
  }
};

/***/ }),

/***/ "TDeA":
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _typeof2 = __webpack_require__("pFYg");

var _typeof3 = _interopRequireDefault(_typeof2);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = {
  //   判断中英文字符串长度 并截取对应长度的字符串
  //     * @param  {[type]} str    [字符串]
  // * @param  {[type]} length [要截取的长度,如果不填写则不截图 默认返回字符串长度]
  // * @return {[type]}        [字符串长度或截取后的字符串]
  subStrLength: function subStrLength(str, startLen, endLen) {
    if (str === undefined || str === null || !str) {
      return 0;
    }
    var byteLen = 0;
    var subStr = '';
    var len = str.length;
    if (typeof startLen === 'number') {
      if (typeof endLen === 'number') {
        for (var _i = 0; _i < len; _i++) {
          byteLen += str.charCodeAt(_i) > 255 ? 2 : 1;
          if (byteLen > endLen) {
            return subStr;
          }
          if (byteLen >= startLen) {
            subStr += str.charAt(_i);
          }
        }
      } else {
        for (var _i2 = 0; _i2 < len; _i2++) {
          byteLen += str.charCodeAt(_i2) > 255 ? 2 : 1;
          if (byteLen > startLen) {
            return subStr;
          }
          subStr += str.charAt(_i2);
        }
      }
      return subStr;
    }
    for (var i = 0; i < len; i++) {
      byteLen += str.charCodeAt(i) > 255 ? 2 : 1;
    }
    return byteLen;
  },

  /**
     * 字符串第一个字母转大写
     */
  firstLetterToUpperCase: function firstLetterToUpperCase(str) {
    if (typeof str !== 'string') {
      return str;
    }
    return str.toString()[0].toUpperCase() + str.toString().slice(1);
  },

  /**
     * 数字转添加间隔符的字符串  如1234567 转换后就是1,234,567
     * @param  {[type]} num       [description]
     * @param  {[type]} separator [description]
     * @return {[type]}           [description]
     */
  numberToString: function numberToString(num, separator) {
    if (num === undefined || isNaN(num)) {
      return '';
    }
    var str = num + '';
    str = str.split('').reverse().join('');
    if (str.length > 3) {
      var newStr = '';
      for (var i = 0; i < parseInt(str.length / 3) + 1; i++) {
        newStr += str.substring(i * 3, str.length < (i + 1) * 3 ? str.length : (i + 1) * 3) + separator;
      }
      if (str.length % 3 === 0) {
        newStr = newStr.substring(0, newStr.length - 1);
      }
      return newStr.substring(0, newStr.length - 1).split('').reverse().join('');
    }
    return num;
  },
  // 判断字符串是否为空
  isEmpty: function isEmpty(str) {
    if (str instanceof Array) {
      return str.length === 0;
    }
    if (typeof str === 'number') {
      str = str + '';
    }
    if (str !== undefined && str !== null && str !== '') {
      return false;
    }
    return true;
  },
  guid: function guid() {
    return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function (c) {
      var r = Math.random() * 16 | 0;
      var v = c === 'x' ? r : r & 0x3 | 0x8;
      return v.toString(16);
    });
  },
  getUUID: function getUUID() {
    var guid = this.guid();
    return guid.replace(/-/g, '');
  },
  isString: function isString(str) {
    return str instanceof String || (typeof str === 'undefined' ? 'undefined' : (0, _typeof3.default)(str)).toLowerCase() === 'string';
  }
};

/***/ }),

/***/ "VqKR":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
Object.defineProperty(__webpack_exports__, "__esModule", { value: true });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__babel_loader_node_modules_vue_loader_lib_selector_type_script_index_0_app_vue__ = __webpack_require__("fWU9");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__babel_loader_node_modules_vue_loader_lib_selector_type_script_index_0_app_vue___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0__babel_loader_node_modules_vue_loader_lib_selector_type_script_index_0_app_vue__);
/* harmony namespace reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in __WEBPACK_IMPORTED_MODULE_0__babel_loader_node_modules_vue_loader_lib_selector_type_script_index_0_app_vue__) if(__WEBPACK_IMPORT_KEY__ !== 'default') (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return __WEBPACK_IMPORTED_MODULE_0__babel_loader_node_modules_vue_loader_lib_selector_type_script_index_0_app_vue__[key]; }) }(__WEBPACK_IMPORT_KEY__));
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__node_modules_vue_loader_lib_template_compiler_index_id_data_v_3c3a68ae_hasScoped_false_transformToRequire_video_src_poster_source_src_img_src_image_xlink_href_buble_transforms_node_modules_vue_loader_lib_selector_type_template_index_0_app_vue__ = __webpack_require__("WNIL");
function injectStyle (ssrContext) {
  __webpack_require__("hgF+")
}
var normalizeComponent = __webpack_require__("VU/8")
/* script */


/* template */

/* template functional */
var __vue_template_functional__ = false
/* styles */
var __vue_styles__ = injectStyle
/* scopeId */
var __vue_scopeId__ = null
/* moduleIdentifier (server only) */
var __vue_module_identifier__ = null
var Component = normalizeComponent(
  __WEBPACK_IMPORTED_MODULE_0__babel_loader_node_modules_vue_loader_lib_selector_type_script_index_0_app_vue___default.a,
  __WEBPACK_IMPORTED_MODULE_1__node_modules_vue_loader_lib_template_compiler_index_id_data_v_3c3a68ae_hasScoped_false_transformToRequire_video_src_poster_source_src_img_src_image_xlink_href_buble_transforms_node_modules_vue_loader_lib_selector_type_template_index_0_app_vue__["a" /* default */],
  __vue_template_functional__,
  __vue_styles__,
  __vue_scopeId__,
  __vue_module_identifier__
)

/* harmony default export */ __webpack_exports__["default"] = (Component.exports);


/***/ }),

/***/ "WNIL":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
var render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('div',{attrs:{"id":"app"}},[(_vm.$route.meta.showHeader)?_c('div',{staticClass:"customize-header"},[_c('div',{staticClass:"customize-header-info"},[_c('p',{on:{"click":function($event){return _vm.$router.goBack(_vm.$route)}}},[_c('van-icon',{attrs:{"name":"arrow-left","color":"#ffffff","size":"18"}}),_vm._v(" "),_c('span',{staticClass:"white-text"},[_vm._v("返回")])],1),_vm._v(" "),_c('span',[_vm._v(_vm._s(_vm.$route.meta.title))]),_vm._v(" "),_c('p',{staticClass:"time-search-iocn"},[(_vm.$route.name=='orderInStock')?_c('van-icon',{attrs:{"name":"search","color":"#ffffff","size":"18"},on:{"click":_vm.selectTime}}):_vm._e()],1)])]):_vm._e(),_vm._v(" "),(_vm.isLoading)?_c('div',{staticClass:"load-overlay"}):_vm._e(),_vm._v(" "),(_vm.isLoading)?_c('van-loading',{staticClass:"van-loading-customize",attrs:{"size":"26px"}}):_vm._e(),_vm._v(" "),_c('router-view')],1)}
var staticRenderFns = []
var esExports = { render: render, staticRenderFns: staticRenderFns }
/* harmony default export */ __webpack_exports__["a"] = (esExports);

/***/ }),

/***/ "XHtf":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
Object.defineProperty(__webpack_exports__, "__esModule", { value: true });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__babel_loader_node_modules_vue_loader_lib_selector_type_script_index_0_PageTransition_vue__ = __webpack_require__("F7Wx");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__babel_loader_node_modules_vue_loader_lib_selector_type_script_index_0_PageTransition_vue___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0__babel_loader_node_modules_vue_loader_lib_selector_type_script_index_0_PageTransition_vue__);
/* harmony namespace reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in __WEBPACK_IMPORTED_MODULE_0__babel_loader_node_modules_vue_loader_lib_selector_type_script_index_0_PageTransition_vue__) if(__WEBPACK_IMPORT_KEY__ !== 'default') (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return __WEBPACK_IMPORTED_MODULE_0__babel_loader_node_modules_vue_loader_lib_selector_type_script_index_0_PageTransition_vue__[key]; }) }(__WEBPACK_IMPORT_KEY__));
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__node_modules_vue_loader_lib_template_compiler_index_id_data_v_1b1f73ed_hasScoped_true_transformToRequire_video_src_poster_source_src_img_src_image_xlink_href_buble_transforms_node_modules_vue_loader_lib_selector_type_template_index_0_PageTransition_vue__ = __webpack_require__("M7S5");
function injectStyle (ssrContext) {
  __webpack_require__("t3Hx")
}
var normalizeComponent = __webpack_require__("VU/8")
/* script */


/* template */

/* template functional */
var __vue_template_functional__ = false
/* styles */
var __vue_styles__ = injectStyle
/* scopeId */
var __vue_scopeId__ = "data-v-1b1f73ed"
/* moduleIdentifier (server only) */
var __vue_module_identifier__ = null
var Component = normalizeComponent(
  __WEBPACK_IMPORTED_MODULE_0__babel_loader_node_modules_vue_loader_lib_selector_type_script_index_0_PageTransition_vue___default.a,
  __WEBPACK_IMPORTED_MODULE_1__node_modules_vue_loader_lib_template_compiler_index_id_data_v_1b1f73ed_hasScoped_true_transformToRequire_video_src_poster_source_src_img_src_image_xlink_href_buble_transforms_node_modules_vue_loader_lib_selector_type_template_index_0_PageTransition_vue__["a" /* default */],
  __vue_template_functional__,
  __vue_styles__,
  __vue_scopeId__,
  __vue_module_identifier__
)

/* harmony default export */ __webpack_exports__["default"] = (Component.exports);


/***/ }),

/***/ "ZXMR":
/***/ (function(module, exports) {

// removed by extract-text-webpack-plugin

/***/ }),

/***/ "ZY45":
/***/ (function(module, exports) {

// removed by extract-text-webpack-plugin

/***/ }),

/***/ "a4s+":
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = {
  // 计算2点之间直线中所有的坐标,
  // * len 是取其中多少的坐标数
  // * order 取值的顺序 true:升序 false:降序
  getCoordinates: function getCoordinates(a, b) {
    var dx = void 0;
    var dy = void 0;
    var h = void 0;
    var x = void 0;
    var y = void 0;
    var t = void 0;
    var ret = [];
    if (a.x > b.x) {
      a.x = [b.x, b.x = a.x][0];
      a.y = [b.y, b.y = a.y][0];
    }
    dx = b.x - a.x;
    dy = b.y - a.y;
    x = a.x;
    y = a.y;
    if (!dx) {
      t = a.y > b.y ? -1 : 1;
      while (y !== b.y) {
        ret.push([x, y]);
        y += t;
      }
      return ret.slice(0);
    }
    if (!dy) {
      while (x !== b.x) {
        ret.push([x, y]);
        x++;
      }
      return ret.slice(0);
    }
    if (dy > 0) {
      if (dy <= dx) {
        h = 2 * dy - dx;
        ret.push([x, y]);
        while (x !== b.x) {
          if (h < 0) {
            h += 2 * dy;
          } else {
            y++;
            h += 2 * (dy - dx);
          }
          x++;
          ret.push([x, y]);
        }
      } else {
        h = 2 * dx - dy;
        ret.push([x, y]);
        while (y !== b.y) {
          if (h < 0) {
            h += 2 * dx;
          } else {
            ++x;
            h += 2 * (dx - dy);
          }
          y++;
          ret.push([x, y]);
        }
      }
    } else {
      t = -dy;
      if (t <= dx) {
        h = 2 * dy + dx;
        ret.push([x, y]);
        while (x !== b.x) {
          if (h < 0) {
            h += 2 * (dy + dx);
            y--;
          } else {
            h += 2 * dy;
          }
          x++;
          ret.push([x, y]);
        }
      } else {
        dy = -dy;
        dx = -dx;
        y = b.y;
        x = b.x;
        ret.push([x, y]);
        h = 2 * dx + dy;
        while (y !== a.y) {
          if (h < 0) {
            h += 2 * (dx + dy);
            x--;
          } else {
            h += 2 * dx;
          }
          y++;
          ret.push([x, y]);
        }
      }
    }
    return ret.slice(0);
  },

  // 获取两点之间的直线的角度
  getAngle: function getAngle(a, b) {
    // 两点的x、y值
    var x = b.x - a.x;
    var y = b.y - a.y;
    var hypotenuse = Math.sqrt(Math.pow(x, 2) + Math.pow(y, 2));
    // 斜边长度
    var cos = x / hypotenuse;
    var radian = Math.acos(cos);
    // 求出弧度
    var angle = 180 / (Math.PI / radian);
    // 用弧度算出角度
    if (y < 0) {
      angle = -angle;
    } else if (y === 0 && x < 0) {
      angle = 180;
    }
    return angle;
  },

  // 判断线段是否和矩形相交
  isLineIntersectRectangle: function isLineIntersectRectangle(line, graphics) {
    var lineHeight = line.y0 - line.y1;
    var lineWidth = line.x1 - line.x0; // 计算叉乘
    var c = line.x0 * line.y1 - line.x1 * line.y0;
    if (lineHeight * graphics.leftTopX + lineWidth * graphics.leftTopY + c >= 0 && lineHeight * graphics.rightBottomX + lineWidth * graphics.rightBottomY + c <= 0 || lineHeight * graphics.leftTopX + lineWidth * graphics.leftTopY + c <= 0 && lineHeight * graphics.rightBottomX + lineWidth * graphics.rightBottomY + c >= 0 || lineHeight * graphics.leftTopX + lineWidth * graphics.rightBottomY + c >= 0 && lineHeight * graphics.rightBottomX + lineWidth * graphics.leftTopY + c <= 0 || lineHeight * graphics.leftTopX + lineWidth * graphics.rightBottomY + c <= 0 && lineHeight * graphics.rightBottomX + lineWidth * graphics.leftTopY + c >= 0) {
      if (graphics.leftTopX > graphics.rightBottomX) {
        var temp = graphics.leftTopX;
        graphics.leftTopX = graphics.rightBottomX;
        graphics.rightBottomX = temp;
      }
      if (graphics.leftTopY < graphics.rightBottomY) {
        var _temp = graphics.leftTopY;
        graphics.leftTopY = graphics.rightBottomY;
        graphics.rightBottomY = _temp;
      }
      if (line.x0 < graphics.leftTopX && line.x1 < graphics.leftTopX || line.x0 > graphics.rightBottomX && line.x1 > graphics.rightBottomX || line.y0 > graphics.leftTopY && line.y1 > graphics.leftTopY || line.y0 < graphics.rightBottomY && line.y1 < graphics.rightBottomY) {
        return false;
      } else {
        return true;
      }
    } else {
      return false;
    }
  },

  // 判断图形是否相交
  graphicsIntersection: function graphicsIntersection(graphics1, graphics2) {
    if (graphics1.x > graphics2.x + graphics2.w || graphics2.x > graphics1.x + graphics1.w || graphics1.y > graphics2.y + graphics2.h || graphics2.y > graphics1.y + graphics1.h) {
      return false;
    } else {
      return true;
    }
  },

  // 判断坐标是在特定范围内
  coordinateInScope: function coordinateInScope(coordinate, graphics) {
    if (coordinate.x >= graphics.x && coordinate.x <= graphics.x + graphics.w && coordinate.y >= graphics.y && coordinate.y <= graphics.y + graphics.h) {
      return true;
    } else {
      return false;
    }
  },

  /**
     * 计算当前坐标是否在圆的范围内
     * coordinate 坐标 x y
     * circular 圆的心坐标 x y 半径 r
     */
  coordinateInCircular: function coordinateInCircular(coordinate, circular) {
    if ((circular.x - coordinate.x) * (circular.x - coordinate.x) + (circular.y - coordinate.y) * (circular.y - coordinate.y) < circular.r * circular.r) {
      return true;
    }
    return false;
  },

  /**
     * 通过直线的开始和结束点的左边计算中心点的坐标
     */
  getLineCenterCoordinate: function getLineCenterCoordinate(start, end) {
    return {
      x: (start.x + end.x) / 2,
      y: (start.y + end.y) / 2
    };
  }
};

/***/ }),

/***/ "ap5O":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
Object.defineProperty(__webpack_exports__, "__esModule", { value: true });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__babel_loader_node_modules_vue_loader_lib_selector_type_script_index_0_confirmIn_vue__ = __webpack_require__("PeFb");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__babel_loader_node_modules_vue_loader_lib_selector_type_script_index_0_confirmIn_vue___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0__babel_loader_node_modules_vue_loader_lib_selector_type_script_index_0_confirmIn_vue__);
/* harmony namespace reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in __WEBPACK_IMPORTED_MODULE_0__babel_loader_node_modules_vue_loader_lib_selector_type_script_index_0_confirmIn_vue__) if(__WEBPACK_IMPORT_KEY__ !== 'default') (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return __WEBPACK_IMPORTED_MODULE_0__babel_loader_node_modules_vue_loader_lib_selector_type_script_index_0_confirmIn_vue__[key]; }) }(__WEBPACK_IMPORT_KEY__));
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__node_modules_vue_loader_lib_template_compiler_index_id_data_v_5041ba0d_hasScoped_true_transformToRequire_video_src_poster_source_src_img_src_image_xlink_href_buble_transforms_node_modules_vue_loader_lib_selector_type_template_index_0_confirmIn_vue__ = __webpack_require__("o7Is");
function injectStyle (ssrContext) {
  __webpack_require__("NG5F")
}
var normalizeComponent = __webpack_require__("VU/8")
/* script */


/* template */

/* template functional */
var __vue_template_functional__ = false
/* styles */
var __vue_styles__ = injectStyle
/* scopeId */
var __vue_scopeId__ = "data-v-5041ba0d"
/* moduleIdentifier (server only) */
var __vue_module_identifier__ = null
var Component = normalizeComponent(
  __WEBPACK_IMPORTED_MODULE_0__babel_loader_node_modules_vue_loader_lib_selector_type_script_index_0_confirmIn_vue___default.a,
  __WEBPACK_IMPORTED_MODULE_1__node_modules_vue_loader_lib_template_compiler_index_id_data_v_5041ba0d_hasScoped_true_transformToRequire_video_src_poster_source_src_img_src_image_xlink_href_buble_transforms_node_modules_vue_loader_lib_selector_type_template_index_0_confirmIn_vue__["a" /* default */],
  __vue_template_functional__,
  __vue_styles__,
  __vue_scopeId__,
  __vue_module_identifier__
)

/* harmony default export */ __webpack_exports__["default"] = (Component.exports);


/***/ }),

/***/ "bBFl":
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _defineProperty2 = __webpack_require__("bOdI");

var _defineProperty3 = _interopRequireDefault(_defineProperty2);

var _getters, _mutations;

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var NS = 'scanOutOrder.';
exports.default = {
  state: {
    scanOutOrder: {
      scanType: { text: '按件出库', value: 0 }, // 扫码模式
      orderType: { text: '全部订单', value: -1 // 订单类型
      } }
  },
  getters: (_getters = {}, (0, _defineProperty3.default)(_getters, NS + 'scanType', function (state) {
    return state.scanOutOrder.scanType;
  }), (0, _defineProperty3.default)(_getters, NS + 'orderType', function (state) {
    return state.scanOutOrder.orderType;
  }), _getters),
  mutations: (_mutations = {}, (0, _defineProperty3.default)(_mutations, NS + 'changeScanType', function (state, scanType) {
    state.scanOutOrder.scanType = scanType;
  }), (0, _defineProperty3.default)(_mutations, NS + 'changeOrderType', function (state, orderType) {
    state.scanOutOrder.orderType = orderType;
  }), _mutations)
};

/***/ }),

/***/ "c+K/":
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = {
  /**
     * 数组求和
     */
  sum: function sum(arr) {
    var count = 0;
    if (arr instanceof Array) {
      for (var i = 0; i < arr.length; i++) {
        if (typeof arr[i] === 'string' || typeof arr[i] === 'number') {
          count += parseFloat(arr[i]);
        }
      }
    }
    return count;
  },
  addItem: function addItem(arr, number) {
    if (arr instanceof Array) {
      for (var i = 0; i < number; i++) {
        arr.push([]);
      }
      return arr;
    }
    return arr;
  },

  /**
     * 数组每项的值为空则用_now对应的值替换
     */
  replaceItem: function replaceItem(_old, _now) {
    if (_old instanceof Array && _now instanceof Array) {
      for (var i = 0; i < _old.length; i++) {
        if (this.$util.stringUtil.isEmpty(_old[i]) && _now.length > i) {
          _old[i] = _now[i];
        }
      }
    }
    return _old;
  },

  /**
     * 数组去重复
     * @param arr {type=Array} 要去重复的数组
     */
  unique: function unique(arr) {
    var result = [];
    var hash = {};
    for (var i = 0, elem; (elem = arr[i]) != null; i++) {
      if (!hash[elem]) {
        result.push(elem);
        hash[elem] = true;
      }
    }
    return result;
  },

  /**
     * 数组赋值 适用于值得数组
     * @author Bruce.yang
     * @param {Array} arr 数组
     * @param {String} val 要赋予的值
     * @return {Array} 返回改变值后的数组
     */
  changeValue: function changeValue(arr, val) {
    arr.forEach(function (dom, index) {
      arr[index] = val;
    });
    return arr;
  },

  /**
     * @desc 数组转树
     * @param {Array} arr - 需要转化的数组
     * @param {String} id - 节点 ID
     * @param {String} pId - 父节点 ID
     * @param {String} children - 子级属性名
     * @return {Array} 返回树结构数组
     */
  arrayToTree: function arrayToTree(arr) {
    var id = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 'id';
    var pId = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : 'pId';
    var children = arguments.length > 3 && arguments[3] !== undefined ? arguments[3] : 'children';

    var res = [];
    var hash = {};
    var len = 0;
    if (arr && arr.length > 0) {
      len = arr.length;
    }
    for (var i = 0; i < len; i++) {
      hash[arr[i][id]] = arr[i];
    }
    for (var j = 0; j < len; j++) {
      var obj = arr[j];
      var hashVP = hash[obj[pId]];
      if (hashVP) {
        !hashVP[children] && (hashVP[children] = []);
        hashVP[children].push(obj);
      } else {
        res.push(obj);
      }
    }
    return res;
  },
  remove: function remove(arr, val) {
    var index = arr.indexOf(val);
    if (index > -1) {
      arr.splice(index, 1);
    }
  },

  // 根据field进行分组
  groupArr: function groupArr(list, field, name, code) {
    var fieldList = [];
    var att = [];
    list.map(function (e) {
      fieldList.push(e[field]);
    });
    fieldList = fieldList.filter(function (e, i, self) {
      return self.indexOf(e) === i;
    });
    for (var j = 0; j < fieldList.length; j++) {
      var arr = list.filter(function (e) {
        return e[field] === fieldList[j];
      });
      att.push({
        name: arr[0][name],
        code: arr[0][code],
        list: arr
      });
    }
    return att;
  }
};

/***/ }),

/***/ "f/Qh":
/***/ (function(module, exports) {

module.exports = VueResource;

/***/ }),

/***/ "f5zX":
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _keys = __webpack_require__("fZjL");

var _keys2 = _interopRequireDefault(_keys);

var _getIterator2 = __webpack_require__("BO1k");

var _getIterator3 = _interopRequireDefault(_getIterator2);

var _map = __webpack_require__("ifoU");

var _map2 = _interopRequireDefault(_map);

var _typeof2 = __webpack_require__("pFYg");

var _typeof3 = _interopRequireDefault(_typeof2);

var _vant = __webpack_require__("Fd2+");

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = {
  // 对象拷贝
  deepCopy: function deepCopy(p, d) {
    var c = void 0;
    if (p instanceof Array) {
      c = d || [];
    } else {
      c = d || {};
    }
    for (var i in p) {
      if ((0, _typeof3.default)(p[i]) === 'object' && p[i] !== null) {
        c[i] = p[i].constructor === Array ? [] : {};
        this.deepCopy(p[i], c[i]);
      } else {
        c[i] = p[i];
      }
    }
    return c;
  },

  // es6 Map
  // json对象转Map对象
  jsonToMap: function jsonToMap(obj) {
    var newMap = new _map2.default();
    var _iteratorNormalCompletion = true;
    var _didIteratorError = false;
    var _iteratorError = undefined;

    try {
      for (var _iterator = (0, _getIterator3.default)((0, _keys2.default)(obj)), _step; !(_iteratorNormalCompletion = (_step = _iterator.next()).done); _iteratorNormalCompletion = true) {
        var k = _step.value;

        newMap.set(obj[k][0], obj[k][1]);
      }
    } catch (err) {
      _didIteratorError = true;
      _iteratorError = err;
    } finally {
      try {
        if (!_iteratorNormalCompletion && _iterator.return) {
          _iterator.return();
        }
      } finally {
        if (_didIteratorError) {
          throw _iteratorError;
        }
      }
    }

    return newMap;
  },
  isObj: function isObj(obj) {
    var arr = (0, _keys2.default)(obj);
    return arr.length === 0;
  },
  copy: function copy(data) {
    var range = document.createRange();
    range.selectNode(document.getElementById(data));
    var selection = window.getSelection();
    if (selection.rangeCount > 0) selection.removeAllRanges();
    selection.addRange(range);
    (0, _vant.Toast)('成功复制到剪切板');
    document.execCommand('copy');
  },

  // 复制成功
  onCopySuccess: function onCopySuccess(e) {
    (0, _vant.Toast)('成功复制到剪切板！');
  },

  // 复制失败
  onCopyError: function onCopyError(e) {
    (0, _vant.Toast)('复制失败！');
  },
  getImgToBase64: function getImgToBase64(url, callback) {
    var canvas = document.createElement('canvas');
    var ctx = canvas.getContext('2d');
    var img = new Image();
    img.crossOrigin = 'Anonymous';
    img.onload = function () {
      canvas.height = img.height;
      canvas.width = img.width;
      ctx.drawImage(img, 0, 0);
      var dataURL = canvas.toDataURL('image/png');
      callback(dataURL);
      canvas = null;
    };
    img.src = url;
  },
  dataURLtoFile: function dataURLtoFile(dataurl, filename) {
    var arr = dataurl.split(',');var mime = arr[0].match(/:(.*?);/)[1];
    var bstr = atob(arr[1]);var n = bstr.length;var u8arr = new Uint8Array(n);
    while (n--) {
      u8arr[n] = bstr.charCodeAt(n);
    }
    return new File([u8arr], filename, { type: mime });
  },
  filterCode: function filterCode(operateCode) {
    for (var code in operateCode) {
      if (operateCode[code] !== null) {
        return code === 'qcc' ? operateCode[code].tpid : operateCode[code];
      }
    }
  }
};

/***/ }),

/***/ "f6Gb":
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _defineProperty2 = __webpack_require__("bOdI");

var _defineProperty3 = _interopRequireDefault(_defineProperty2);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var NS = 'batchSearch.';

exports.default = {
  state: {
    batchSearch: {
      chosenStock: null // 选择库存统计
    }
  },
  getters: (0, _defineProperty3.default)({}, NS + 'chosenStock', function (state) {
    return state.batchSearch.chosenStock;
  }),
  mutations: (0, _defineProperty3.default)({}, NS + 'changeChosenStock', function (state, stock) {
    state.batchSearch.chosenStock = stock;
  })
};

/***/ }),

/***/ "fWU9":
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _extends2 = __webpack_require__("Dd8w");

var _extends3 = _interopRequireDefault(_extends2);

var _vant = __webpack_require__("Fd2+");

var _vue = __webpack_require__("lRwf");

var _vue2 = _interopRequireDefault(_vue);

var _vuex = __webpack_require__("SJI6");

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = {
  name: 'App',
  computed: (0, _extends3.default)({}, (0, _vuex.mapGetters)({
    isLoading: 'global.isLoading',
    scanFlag: 'global.scanFlag',
    timeVisible: 'global.timeVisible'
  })),
  data: function data() {
    return {};
  },

  watch: {
    /* isLoading (val, oldVal) {
              val ? Indicator.open() : Indicator.close()
            }, */
    scanFlag: function scanFlag(val, oldVal) {
      this.$util.business.AppUtils.setScanStatus(!val);
    }
  },
  created: function created() {
    var _this = this;

    this.initVueResource();
    this.$util.business.AppUtils.goBackHistory(function () {
      _this.goBack();
    });
  },

  methods: {
    selectTime: function selectTime() {
      this.$store.commit('global.changeTimeVisible', !this.timeVisible);
    },
    initVueResource: function initVueResource() {
      var _this2 = this;

      _vue2.default.http.interceptors.push(function (request, next) {
        _this2.$store.commit('global.changeIsLoading', true);
        next(function (response) {
          _this2.$store.commit('global.changeIsLoading', false);
          if (response.status === 200 || response.status === 304) {
            return response;
          } else if (response.status === 401) {
            var me = _this2;
            me.$util.business.AppUtils.openMessageBox('提示', '', '会话超时，请重新登录', '', '确定', false, function (result) {
              me.$util.business.AppUtils.tokenFail(function (result) {});
            });
            _this2.$store.commit('global.changeScanFlag', false); // 解锁
          } else if (response.status === 0) {
            if (window.config.forApp) {
              _this2.$util.business.AppUtils.openMessageBox('提示', '', '网络异常,请尝试重连网络', '', '确定', false, function (result) {});
            } else {
              (0, _vant.Toast)({ message: '网络异常,请尝试重连网络!' });
            }
            _this2.$store.commit('global.changeScanFlag', false); // 解锁
          } else {
            (0, _vant.Toast)({ message: '服务端异常，请联系技术支持!' });
            _this2.$store.commit('global.changeScanFlag', false); // 解锁
          }
        });
      });
    },
    goBack: function goBack() {
      if (this.$route.path === '/') return this.$util.business.AppUtils.existApplet();
      this.$router.goBack(this.$route);
    }
  }
}; //
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

/***/ }),

/***/ "gJ0n":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
var render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('div',{attrs:{"id":"scanRecordIn"}},[_c('div',{staticClass:"search-input"},[_c('van-search',{attrs:{"placeholder":"请录入码值"},on:{"search":_vm.codeScan},model:{value:(_vm.scannedInfo.code),callback:function ($$v) {_vm.$set(_vm.scannedInfo, "code", $$v)},expression:"scannedInfo.code"}}),_vm._v(" "),_c('span',{staticClass:"search-button",on:{"click":_vm.codeScan}},[_vm._v("录入")])],1),_vm._v(" "),_c('div',{staticClass:"scan-list"},[_c('p',{staticClass:"scan-title"},[_c('span',[_vm._v("扫码记录")]),_c('span',{staticClass:"blue-text",on:{"click":function($event){return _vm.selectScanType()}}},[_vm._v(_vm._s(_vm.filterMode()))])]),_vm._v(" "),_c('p',{staticClass:"scan-num"},[_c('span',[_vm._v("已扫数量/总数量")]),_vm._v(" "),_c('span',[_vm._v(_vm._s(_vm.orderDetails.scanNum)+"/"+_vm._s(_vm.orderDetails.totalNum))])]),_vm._v(" "),_c('p',{staticClass:"order-no"},[_c('span',[_vm._v(_vm._s(_vm.orderDetails.stockOutNo))]),_vm._v(" "),_c('span',[_vm._v(_vm._s(_vm.orderDetails.createDate.split(' ')[0]))])]),_vm._v(" "),_c('ul',{staticClass:"list-item"},_vm._l((_vm.scanRecordList),function(record,index){return _c('li',{key:index},[_c('span',[_vm._v(_vm._s(_vm.$util.common.ObjectUtils.filterCode(record.operateCode)))]),_vm._v(" "),_c('span',{staticClass:"green-text"},[_vm._v("扫码成功")])])}),0)]),_vm._v(" "),_c('div',{staticClass:"goods-list"},[_c('p',{staticClass:"scan-title"},[_vm._v("商品进度")]),_vm._v(" "),_vm._l((_vm.orderDetails.skuBatchList),function(goods,index){return _c('ul',{key:index},[_c('p',{staticClass:"goods-title"},[_vm._v(_vm._s(goods.name))]),_vm._v(" "),_c('ul',{staticClass:"goods-item"},_vm._l((goods.list),function(batch,index){return _c('li',{key:index},[_c('span',[_vm._v(_vm._s(batch.batchNo))]),_vm._v(" "),_c('p',[_c('span',{staticClass:"red-text"},[_vm._v(_vm._s(batch.inQuality))]),_vm._v(" "),_c('span',[_vm._v("/")]),_vm._v(" "),_c('span',[_vm._v(_vm._s(batch.quality))]),_vm._v(" "),_c('span',{staticStyle:{"color":"#999999"}},[_vm._v("("+_vm._s(batch.unitName)+")")])])])}),0)])})],2),_vm._v(" "),_c('van-dialog',{attrs:{"use-slot":"","title":"选择入库方式"},model:{value:(_vm.show),callback:function ($$v) {_vm.show=$$v},expression:"show"}},[_c('van-radio-group',{model:{value:(_vm.mode),callback:function ($$v) {_vm.mode=$$v},expression:"mode"}},[_c('van-radio',{attrs:{"name":"1"}},[_vm._v("按件入库")]),_vm._v(" "),_c('van-radio',{attrs:{"name":"2"}},[_vm._v("按垛入库")])],1)],1)],1)}
var staticRenderFns = []
var esExports = { render: render, staticRenderFns: staticRenderFns }
/* harmony default export */ __webpack_exports__["a"] = (esExports);

/***/ }),

/***/ "gMUt":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
var render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('div',{attrs:{"id":"orderInStock"}},[_c('div',{staticClass:"search-filter"},_vm._l((_vm.orderStatus),function(order,index){return _c('span',{key:index,class:{ active: _vm.selectData.id == order.id },on:{"click":function($event){return _vm.selectStatus(order)}}},[_vm._v(_vm._s(order.name)+"("+_vm._s(order.num)+")")])}),0),_vm._v(" "),(_vm.orderList.length > 0)?_c('div',{staticClass:"order-list",attrs:{"id":"order-list"}},[_c('van-list',{attrs:{"finished":_vm.finished,"finished-text":"没有更多了...","offset":20,"immediate-check":false},on:{"load":_vm.onLoad},model:{value:(_vm.loading),callback:function ($$v) {_vm.loading=$$v},expression:"loading"}},_vm._l((_vm.orderList),function(order,index){return _c('div',{key:index,staticClass:"order-info"},[_c('div',{staticClass:"order-title"},[_c('div',[_c('p',{staticClass:"order-no"},[_c('span',{staticClass:"blue-icon"}),_vm._v(" "),_c('span',{staticStyle:{"color":"#4473fa"}},[_vm._v(_vm._s(order.stockOutNo))])]),_vm._v(" "),_c('p',{staticClass:"order-time"},[_vm._v(_vm._s(order.createDate))])]),_vm._v(" "),_c('div',{staticClass:"red-text",class:_vm.styleColorList[order.status]},[_vm._v("\n                        "+_vm._s(_vm._f("orderStatus")(order.status))+"\n                    ")])]),_vm._v(" "),_c('div',{staticClass:"order-content",on:{"click":function($event){return _vm.viewDetails(order)}}},_vm._l((order.skuBatchList),function(goods,goodsIndex){return _c('div',{key:goodsIndex,staticClass:"goods-info"},[_c('div',{staticClass:"flex-between"},[(_vm.showMore(order,goodsIndex))?_c('p',{staticClass:"goods-name"},[_vm._v(_vm._s(goods.name))]):_vm._e(),_vm._v(" "),((goods.list.length==1&&(goods.list[0].batchNo==''||goods.list[0].batchNo==null))&&_vm.showMore(order,goodsIndex))?_c('p',{staticClass:"min-width-60"},[_c('span',{staticClass:"red-text"},[_vm._v(_vm._s(goods.list[0].inQuality))]),_vm._v(" "),_c('span',[_vm._v("/")]),_vm._v(" "),_c('span',[_vm._v(_vm._s(goods.list[0].quality))]),_vm._v(" "),_c('span',{staticStyle:{"color":"#999999"}},[_vm._v("("+_vm._s(goods.list[0].unitName)+")")])]):_vm._e()]),_vm._v(" "),((!(goods.list.length==1&&(goods.list[0].batchNo==''||goods.list[0].batchNo==null)))&&_vm.showMore(order,goodsIndex))?_c('ul',{staticClass:"batch-info"},_vm._l((goods.list),function(batch,index){return _c('li',{key:index},[_c('span',[_vm._v(_vm._s(batch.batchNo))]),_vm._v(" "),_c('p',[_c('span',{staticClass:"red-text"},[_vm._v(_vm._s(batch.inQuality))]),_vm._v(" "),_c('span',[_vm._v("/")]),_vm._v(" "),_c('span',[_vm._v(_vm._s(batch.quality))]),_vm._v(" "),_c('span',{staticStyle:{"color":"#999999"}},[_vm._v("("+_vm._s(batch.unitName)+")")])])])}),0):_vm._e()])}),0),_vm._v(" "),_c('p',{staticClass:"goods-total-num"},[_vm._v("共"),_c('span',{staticClass:"red-text"},[_vm._v(_vm._s(order.goodsTotal||0))]),_vm._v("种商品,数量"),_c('span',{staticClass:"red-text"},[_vm._v(_vm._s(order.goodsTotalCount||0))]),(order.skuBatchList.length>3)?_c('span',{class:order.arrowFlag?'arrow-bottom':'arrow-up',staticStyle:{"margin-left":"5px"},on:{"click":function($event){return _vm.changeArrowStatus(order)}}}):_vm._e()]),_vm._v(" "),_c('div',{staticClass:"oragn-info"},[_c('img',{staticClass:"organ-icon",attrs:{"src":__webpack_require__("GPWr"),"alt":""}}),_vm._v(" "),_c('div',{staticStyle:{"flex":"1"}},[_c('p',{staticClass:"flex-between",staticStyle:{"margin-bottom":"10px"}},[_c('span',{staticClass:"min-width-80"},[_vm._v("发货组织")]),_vm._v(" "),_c('span',{staticClass:"black-text"},[_vm._v(_vm._s(order.outOrgName))])]),_vm._v(" "),_c('p',{staticClass:"flex-between"},[_c('span',{staticClass:"min-width-80"},[_vm._v("收货组织")]),_vm._v(" "),_c('span',{staticClass:"black-text"},[_vm._v(_vm._s(order.inOrgName))])])])]),_vm._v(" "),_c('div',{staticClass:"oper-button"},[(order.status == 2)?_c('span',{staticClass:"yellow-button",on:{"click":function($event){return _vm.cancel(order)}}},[_vm._v("订单拒收")]):_vm._e(),_vm._v(" "),((order.status == 2||order.status == 3)&&(order.scanIn==0))?_c('span',{staticClass:"yellow-button",on:{"click":function($event){return _vm.scan(order)}}},[_vm._v("扫码收货")]):_vm._e(),_vm._v(" "),((order.status == 2||order.status == 3)&&(order.scanIn==1))?_c('span',{staticClass:"yellow-button",on:{"click":function($event){return _vm.confirm(order)}}},[_vm._v("确认收货")]):_vm._e()])])}),0)],1):_c('div',{staticClass:"empty-list"},[_c('img',{attrs:{"src":__webpack_require__("u8EM"),"alt":""}}),_vm._v(" "),_c('p',{staticClass:"gray-text"},[_vm._v("暂无订单信息")])]),_vm._v(" "),_c('timeSelect',{attrs:{"showOrderFilter":true},on:{"sureDate":_vm.sureDate}})],1)}
var staticRenderFns = []
var esExports = { render: render, staticRenderFns: staticRenderFns }
/* harmony default export */ __webpack_exports__["a"] = (esExports);

/***/ }),

/***/ "hCOg":
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
// import api from '../../conf/api'
// import backend from '../../utils/backend'

exports.default = {
  // 查询企业下所有码段
  // initAllCodeSegment () {
  //   return backend.request(api.Pack.getAllCodeSegment, {}).then((res) => {
  //     this.$util.business.LocalUtils.setCodeSegmnet(res)
  //   })
  // }
};

/***/ }),

/***/ "hDMw":
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _stringify = __webpack_require__("mvHQ");

var _stringify2 = _interopRequireDefault(_stringify);

var _typeof2 = __webpack_require__("pFYg");

var _typeof3 = _interopRequireDefault(_typeof2);

var _vue = __webpack_require__("lRwf");

var _vue2 = _interopRequireDefault(_vue);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var LOGIN_USER = 'LOGIN_USER';

exports.default = {
  setLoginUser: function setLoginUser(user) {
    if ((typeof user === 'undefined' ? 'undefined' : (0, _typeof3.default)(user)) === 'object') {
      _vue2.default.http.headers.common['Authorization'] = user.token;
      _vue2.default.http.headers.common['Username'] = user.username;
      _vue2.default.http.headers.common['TenantId'] = user.tenantId;
      window.sessionStorage.setItem(LOGIN_USER, (0, _stringify2.default)(user));
    } else {
      window.sessionStorage.setItem(LOGIN_USER, '');
    }
  },
  getLoginUser: function getLoginUser() {
    var jsonstr = window.sessionStorage.getItem(LOGIN_USER);
    if (jsonstr && jsonstr !== '') {
      try {
        return JSON.parse(jsonstr);
      } catch (e) {
        console.error(e);
        return null;
      }
    }
    return null;
  },

  // @desc 将数据存进 sessionStorage 里
  // @param {String} key - 存储的 key
  // @param {Object|String|Number|Boolean} value - 需要存储的数据
  setData: function setData(key, value) {
    if (typeof key !== 'string') {
      throw new Error('key must be a string!');
    }
    if ((typeof value === 'undefined' ? 'undefined' : (0, _typeof3.default)(value)) === 'object') {
      value = (0, _stringify2.default)(value);
    }
    window.sessionStorage.setItem(key, value);
  },

  // @desc 获取 sessionStorage 里存储的数据
  // @param {String} key - 通过 key 获取对于的数据
  getData: function getData(key) {
    if (typeof key !== 'string') {
      throw new Error('key must be a string!');
    }
    try {
      return JSON.parse(window.sessionStorage.getItem(key));
    } catch (e) {
      return window.sessionStorage.getItem(key);
    }
  }
};

/***/ }),

/***/ "hgF+":
/***/ (function(module, exports) {

// removed by extract-text-webpack-plugin

/***/ }),

/***/ "hi50":
/***/ (function(module, exports) {

module.exports = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACAAAAAgCAYAAABzenr0AAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyZpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuNi1jMTM4IDc5LjE1OTgyNCwgMjAxNi8wOS8xNC0wMTowOTowMSAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENDIDIwMTcgKFdpbmRvd3MpIiB4bXBNTTpJbnN0YW5jZUlEPSJ4bXAuaWlkOjQzODlERTYwNEZDRTExRUFBNDFGOUM4QzdBOTk3OTkzIiB4bXBNTTpEb2N1bWVudElEPSJ4bXAuZGlkOjQzODlERTYxNEZDRTExRUFBNDFGOUM4QzdBOTk3OTkzIj4gPHhtcE1NOkRlcml2ZWRGcm9tIHN0UmVmOmluc3RhbmNlSUQ9InhtcC5paWQ6NDM4OURFNUU0RkNFMTFFQUE0MUY5QzhDN0E5OTc5OTMiIHN0UmVmOmRvY3VtZW50SUQ9InhtcC5kaWQ6NDM4OURFNUY0RkNFMTFFQUE0MUY5QzhDN0E5OTc5OTMiLz4gPC9yZGY6RGVzY3JpcHRpb24+IDwvcmRmOlJERj4gPC94OnhtcG1ldGE+IDw/eHBhY2tldCBlbmQ9InIiPz6WdY/4AAACgklEQVR42uxXz2tTQRCe3Vh/1GrtQQ0olhZB0FY9iUctHiIGT54Ub/WgNwWxB0EQvOrJQ9GziAcRqVCkKPQPkAq1iGCtP5IqVrEmMU2a7PrNcxvyzNvNS9IkHhz4COTN2+/b2ZnZN6IwRX/bXmAYOA70AeuoMcsBs8A4cBeYKX8oygSsBW4C5wFJzTEF3AEuAtlyAUz+BDhGrbFnJsL5lZ3eaiE525CJtheBffh9CUSotVYEDkiTcK0mJ8M5zAJiq7dkN8n+pxTZXyDZ+wCp3FntjRgfQc4koc9EzxmS0RtYdEtA8H6QSl4ivfiwglx0Hir9pdPPSb2LI/d/2QTkWYAO3MxgCjvosmsvfKXiq23GuQfk4z7ysCLs9e4iZ1uztfQrd08GknuR7DpKsm/MehwNNhyBxR+TWD/g9mIRu+41QUBHFDs/HE7q5ngTBCx/IZ19EcpV/xxrxhEoUrMx0kvTbnJOxA+naxSg0lV2nyxVg3o7ZBVRdxWoT7gUlz+i5hcrkZ8jlbjgK8kgESH6AFn7QF3GJdl7H1l/BE3qEcJ+1km++gJ8gVXhNNvL5iSJ6HUSAa1YF7+Rnr9COjXxx7f7FHyvkZCbAnwXSCfQtjOTtUUgMvDda7H2JExQcWYnVuiAL/JCbnB8lL2h4us9NVaBi9xrQjvMChvd5F6ctzsPq632XwALyLeRPy3N0BDQQ5fcrxYWTMvMcq1VuTJStifvpZlYKt9JjthFqAyp+ctGaI7U56sO3xR8R2wCJrgP8NfEVJs+yw9yBPgGGW3D+TPn9D8zmnElnABuh75F6h9OeefxleoTAeM5j2rnzMDSz023QdIMMMcJZ8Zz30fDbwEGAAhY775JuspNAAAAAElFTkSuQmCC"

/***/ }),

/***/ "i8Gx":
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = {
  // 计算时间差
  getDatePoor: function getDatePoor(start, end) {
    end = end || new Date();
    var startTime = new Date(start).getTime();
    var endTime = new Date(end).getTime();
    if (startTime > endTime) {
      var curTime = new Date().getTime();
      return curTime - startTime;
    }
    return endTime - startTime;
  },

  // 秒转天时分秒
  secondToDate: function secondToDate(second) {
    if (!second) {
      return '';
    }
    second = parseInt(second);
    var s = 0;
    var m = 0;
    var h = 0;
    var d = 0;
    s = second % 60;
    m = parseInt(second / 60);
    if (m >= 60) {
      h = parseInt(m / 60);
      m = m % 60;
    }
    if (h >= 24) {
      d = parseInt(h / 24);
    }
    h = h % 24;
    if (d !== 0) {
      return d + '天' + h + '时' + m + '分' + s + '秒';
    }
    if (h !== 0) {
      return h + '时' + m + '分' + s + '秒';
    }
    if (m !== 0) {
      return m + '分' + s + '秒';
    }
    return s + '秒';
  },

  // 日期格式化
  dateFormat: function dateFormat() {
    var date = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : new Date();
    var fmt = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 'yyyy-MM-dd hh:mm:ss';

    date = typeof date === 'number' ? new Date(date) : date;
    var o = {
      'M+': date.getMonth() + 1,
      'd+': date.getDate(),
      'h+': date.getHours(),
      'm+': date.getMinutes(),
      's+': date.getSeconds(),
      'q+': Math.floor((date.getMonth() + 3) / 3),
      'S': date.getMilliseconds()
    };
    if (/(y+)/.test(fmt)) {
      fmt = fmt.replace(RegExp.$1, (date.getFullYear() + '').substr(4 - RegExp.$1.length));
    }
    for (var k in o) {
      if (new RegExp('(' + k + ')').test(fmt)) {
        fmt = fmt.replace(RegExp.$1, RegExp.$1.length === 1 ? o[k] : ('00' + o[k]).substr(('' + o[k]).length));
      }
    }
    return fmt;
  },

  // 添加减少年  返回新的日期对象
  addYear: function addYear(date) {
    var year = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 0;

    if (Math.abs(year) === 0) {
      return date;
    }
    return new Date(date.getFullYear() + year, date.getMonth(), date.getDate(), date.getHours(), date.getMinutes(), date.getSeconds());
  },

  /**
     * 添加减少月  返回新的日期对象
     */
  addMonth: function addMonth(date) {
    var month = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 0;

    if (Math.abs(month) === 0) {
      return date;
    }
    return new Date(date.getFullYear(), date.getMonth() + month, date.getDate(), date.getHours(), date.getMinutes(), date.getSeconds());
  },

  /**
     * 添加减少天数  返回新的日期对象
     */
  addDate: function addDate(date) {
    var days = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 0;

    if (Math.abs(days) === 0) {
      return date;
    }
    return new Date(date.getFullYear(), date.getMonth(), date.getDate() + days, date.getHours(), date.getMinutes(), date.getSeconds());
  },

  /**
     * 添加减少小时  返回新的日期对象
     */
  addHour: function addHour(date) {
    var hour = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 0;

    if (Math.abs(hour) === 0) {
      return date;
    }
    return new Date(date.getFullYear(), date.getMonth(), date.getDate(), date.getHours() + hour, date.getMinutes(), date.getSeconds());
  },

  /**
     * 添加减少分钟  返回新的日期对象
     */
  addMinute: function addMinute(date) {
    var minute = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 0;

    if (Math.abs(minute) === 0) {
      return date;
    }
    return new Date(date.getFullYear(), date.getMonth(), date.getDate(), date.getHours(), date.getMinutes() + minute, date.getSeconds());
  },

  /**
     * 添加减少秒钟  返回新的日期对象
     */
  addSecond: function addSecond(date) {
    var second = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 0;

    if (Math.abs(second) === 0) {
      return date;
    }
    return new Date(date.getFullYear(), date.getMonth(), date.getDate(), date.getHours(), date.getMinutes(), date.getSeconds() + second);
  },
  dateFormat2: function dateFormat2(d, istime) {
    if (!d) return null;
    if (typeof d === 'number') {
      d = new Date(d);
    }
    var year = d.getFullYear();
    var month = this.fixzero(d.getMonth() + 1, 2);
    var date = this.fixzero(d.getDate(), 2);
    var str = year + '-' + month + '-' + date;
    if (istime) {
      var hour = this.fixzero(d.getHours(), 2);
      var min = this.fixzero(d.getMinutes(), 2);
      var sec = this.fixzero(d.getSeconds(), 2);
      str += ' ' + hour + ':' + min + ':' + sec;
    }
    return str;
  },
  dateParse: function dateParse(s, istime) {
    var d = new Date();
    var year = s.substring(0, 4);
    var month = s.substring(5, 7) - 1;
    var date = s.substring(8, 10);
    d.setFullYear(year, month, date);
    if (istime) {
      var hour = s.substring(11, 13);
      var min = s.substring(14, 16);
      var sec = s.substring(17, 19);
      d.setHours(hour, min, sec, 0);
    }
    return d;
  },

  /**
     * 补零
     */
  fixzero: function fixzero(s, size) {
    s = s.toString();
    if (s.length === size) return s;
    var dest = '';
    for (var i = 0; i < size - s.length; i++) {
      dest += '0';
    }
    return dest + s;
  },

  // 获取 近七天sevenDays 近一月oneMonth 近三月threeMonth 近六月sixMonth
  getTimeRegion: function getTimeRegion(flag) {
    var fmt = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 'yyyy-MM-dd hh:mm:ss';

    var date = new Date();
    var time = '';
    switch (flag) {
      case 'sevenDays':
        time = this.dateFormat(new Date(date.getTime() - 7 * 24 * 60 * 60 * 1000), fmt);
        break;
      case 'oneMonth':
        time = this.dateFormat(new Date(date.getTime() - 30 * 24 * 60 * 60 * 1000));
        break;
      case 'threeMonth':
        time = this.dateFormat(new Date(date.getTime() - 90 * 24 * 60 * 60 * 1000));
        break;
      case 'sixMonth':
        time = this.dateFormat(new Date(date.getTime() - 180 * 24 * 60 * 60 * 1000));
        break;
    }
    return time;
  },
  forMatData: function forMatData(date) {
    // 补0   例如 2018/7/10 14:7:2  补完后为 2018/07/10 14:07:02
    function addZero(num) {
      if (num < 10) {
        return '0' + num;
      }
      return num;
    }
    // 按自定义拼接格式返回
    return date.getFullYear() + '-' + addZero(date.getMonth() + 1) + '-' + addZero(date.getDate()) + ' ' + addZero(date.getHours()) + ':' + addZero(date.getMinutes()) + ':' + addZero(date.getSeconds());
  }
};

/***/ }),

/***/ "ivU6":
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
// import store from '../../store'
// import api from '../../conf/api'
// import backend from '../backend'

exports.default = {
  logout: function logout() {
    // store.dispatch('global.setUser', null)
    // backend.request(api.user.logout)
  }
};

/***/ }),

/***/ "jFiy":
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var _object = __webpack_require__("f5zX");

var _object2 = _interopRequireDefault(_object);

var _date = __webpack_require__("i8Gx");

var _date2 = _interopRequireDefault(_date);

var _string = __webpack_require__("TDeA");

var _string2 = _interopRequireDefault(_string);

var _dom = __webpack_require__("CS8j");

var _dom2 = _interopRequireDefault(_dom);

var _formula = __webpack_require__("a4s+");

var _formula2 = _interopRequireDefault(_formula);

var _canvas = __webpack_require__("ph76");

var _canvas2 = _interopRequireDefault(_canvas);

var _array = __webpack_require__("c+K/");

var _array2 = _interopRequireDefault(_array);

var _convert = __webpack_require__("4D68");

var _convert2 = _interopRequireDefault(_convert);

var _number = __webpack_require__("Mlnd");

var _number2 = _interopRequireDefault(_number);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

module.exports = {
  ObjectUtils: _object2.default,
  DateUtils: _date2.default,
  StringUtils: _string2.default,
  DomUtils: _dom2.default,
  FormulaUtils: _formula2.default,
  CanvasUtils: _canvas2.default,
  ArrayUtils: _array2.default,
  ConvertUtils: _convert2.default,
  NumberUtils: _number2.default
};

/***/ }),

/***/ "juUJ":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
Object.defineProperty(__webpack_exports__, "__esModule", { value: true });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__babel_loader_node_modules_vue_loader_lib_selector_type_script_index_0_orderInStock_vue__ = __webpack_require__("srZF");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__babel_loader_node_modules_vue_loader_lib_selector_type_script_index_0_orderInStock_vue___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0__babel_loader_node_modules_vue_loader_lib_selector_type_script_index_0_orderInStock_vue__);
/* harmony namespace reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in __WEBPACK_IMPORTED_MODULE_0__babel_loader_node_modules_vue_loader_lib_selector_type_script_index_0_orderInStock_vue__) if(__WEBPACK_IMPORT_KEY__ !== 'default') (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return __WEBPACK_IMPORTED_MODULE_0__babel_loader_node_modules_vue_loader_lib_selector_type_script_index_0_orderInStock_vue__[key]; }) }(__WEBPACK_IMPORT_KEY__));
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__node_modules_vue_loader_lib_template_compiler_index_id_data_v_95c7af1c_hasScoped_true_transformToRequire_video_src_poster_source_src_img_src_image_xlink_href_buble_transforms_node_modules_vue_loader_lib_selector_type_template_index_0_orderInStock_vue__ = __webpack_require__("gMUt");
function injectStyle (ssrContext) {
  __webpack_require__("/eQ1")
}
var normalizeComponent = __webpack_require__("VU/8")
/* script */


/* template */

/* template functional */
var __vue_template_functional__ = false
/* styles */
var __vue_styles__ = injectStyle
/* scopeId */
var __vue_scopeId__ = "data-v-95c7af1c"
/* moduleIdentifier (server only) */
var __vue_module_identifier__ = null
var Component = normalizeComponent(
  __WEBPACK_IMPORTED_MODULE_0__babel_loader_node_modules_vue_loader_lib_selector_type_script_index_0_orderInStock_vue___default.a,
  __WEBPACK_IMPORTED_MODULE_1__node_modules_vue_loader_lib_template_compiler_index_id_data_v_95c7af1c_hasScoped_true_transformToRequire_video_src_poster_source_src_img_src_image_xlink_href_buble_transforms_node_modules_vue_loader_lib_selector_type_template_index_0_orderInStock_vue__["a" /* default */],
  __vue_template_functional__,
  __vue_styles__,
  __vue_scopeId__,
  __vue_module_identifier__
)

/* harmony default export */ __webpack_exports__["default"] = (Component.exports);


/***/ }),

/***/ "jz1p":
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _instance = __webpack_require__("5rSO");

var _instance2 = _interopRequireDefault(_instance);

var _handler = __webpack_require__("J3hU");

var _handler2 = _interopRequireDefault(_handler);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

(0, _handler2.default)(_instance2.default);

exports.default = _instance2.default;

/***/ }),

/***/ "k/Mv":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
var render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('div',{attrs:{"id":"selectOrgan"}},[_c('div',{staticClass:"search-filter"},[(_vm.showType())?_c('van-dropdown-menu',[_c('van-dropdown-item',{attrs:{"options":_vm.organList},on:{"open":_vm.openDropdownMenu,"change":_vm.changeType},model:{value:(_vm.defaultSelect),callback:function ($$v) {_vm.defaultSelect=$$v},expression:"defaultSelect"}})],1):_vm._e(),_vm._v(" "),_c('van-search',{attrs:{"placeholder":"请输入搜索关键词"},on:{"search":_vm.filterData},model:{value:(_vm.queryListParam.keyString),callback:function ($$v) {_vm.$set(_vm.queryListParam, "keyString", $$v)},expression:"queryListParam.keyString"}}),_vm._v(" "),_c('span',{staticClass:"search-button",on:{"click":_vm.filterData}},[_vm._v("搜索")])],1),_vm._v(" "),(_vm.organList[_vm.defaultSelect].children.length>0)?_c('div',{staticClass:"content",attrs:{"id":"organ-list"}},[_c('van-list',{attrs:{"finished":_vm.finished,"finished-text":"没有更多了...","offset":20,"immediate-check":false},on:{"load":_vm.onLoad},model:{value:(_vm.loading),callback:function ($$v) {_vm.loading=$$v},expression:"loading"}},[(_vm.$route.params.type !== 'traceAudit')?_c('ul',{staticClass:"organ-list"},_vm._l((_vm.organList[_vm.defaultSelect].children),function(wareHouse,index){return _c('li',{key:index,staticClass:"flex-between",class:{'active': _vm.$route.params.flag==0?wareHouse.warehouseId===_vm.outWareHouseInfo.id:wareHouse.warehouseId===_vm.inWareHouseInfo.id }},[_c('div',{staticStyle:{"flex":"1"},on:{"click":function($event){return _vm.selectWareHouse(wareHouse)}}},[_c('p',[_vm._v(_vm._s(wareHouse.orgName))]),_vm._v(" "),_c('p',[_vm._v(_vm._s(wareHouse.warehouseName))])]),_vm._v(" "),(_vm.isShowArrow())?_c('div',{staticClass:"min-width-60",staticStyle:{"text-align":"right"}},[_c('span',{staticClass:"arrow-right blue-text",on:{"click":function($event){return _vm.getLowerOrgan(wareHouse)}}},[_vm._v("下级")])]):_vm._e()])}),0):_c('ul',{staticClass:"organ-list"},_vm._l((_vm.organList[_vm.defaultSelect].children),function(wareHouse,index){return _c('li',{key:index,class:{'active': _vm.$route.params.flag==0?wareHouse.orgId===_vm.outOrganInfo.id:wareHouse.orgId===_vm.inOrganInfo.id },on:{"click":function($event){return _vm.selectWareHouse(wareHouse)}}},[_c('p',[_vm._v(_vm._s(wareHouse.orgName))])])}),0)])],1):_c('div',{staticClass:"empty-list"},[_c('img',{attrs:{"src":__webpack_require__("u8EM"),"alt":""}}),_vm._v(" "),_c('p',{staticClass:"gray-text"},[_vm._v("暂无仓库信息")])])])}
var staticRenderFns = []
var esExports = { render: render, staticRenderFns: staticRenderFns }
/* harmony default export */ __webpack_exports__["a"] = (esExports);

/***/ }),

/***/ "kB6T":
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _slicedToArray2 = __webpack_require__("d7EF");

var _slicedToArray3 = _interopRequireDefault(_slicedToArray2);

var _extends2 = __webpack_require__("Dd8w");

var _extends3 = _interopRequireDefault(_extends2);

var _vuex = __webpack_require__("SJI6");

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = {
  props: ['showFilter', 'showOrderFilter'],
  name: 'timeSelect',
  computed: (0, _extends3.default)({}, (0, _vuex.mapGetters)({
    timeVisible: 'global.timeVisible'
  })),
  data: function data() {
    return {
      dataShow: false,
      showMoreFilter: false,
      queryListParam: {
        startSearchDate: '',
        endSearchDate: '',
        keyword: '',
        type: '',
        skuName: '',
        stockOutNo: '',
        batchNo: '',
        inOrgName: '',
        outOrgName: ''
      },
      submitTime: [{ name: '近七天', id: 1, time: 'sevenDays' }, { name: '近一月', id: 2, time: 'oneMonth' }, { name: '近三月', id: 3, time: 'threeMonth' }, { name: '自定义', id: -1, time: 'user-customize' }],
      searchType: [{ text: '商品名称', value: 1 }, { text: '生产批次号', value: 2 }, { text: '商品编号', value: 3 }, { text: '发货组织', value: 4 }, { text: '接收组织', value: 5 }],
      userSelectTime: {},
      userSelectOrder: { name: '全部', type: '' },
      minDate: new Date(2020, 0, 1),
      orderOrigin: [{ name: '订货单', type: 1 }, { name: '调拨单', type: 2 }, { name: '采购单', type: 3 }, { name: '退货单', type: 4 }, { name: '出库单', type: 5 }, { name: '入库单', type: 6 }, { name: '全部', type: '' }]
    };
  },
  activated: function activated() {},
  created: function created() {},

  methods: {
    onConfirm: function onConfirm(date) {
      var _date = (0, _slicedToArray3.default)(date, 2),
          start = _date[0],
          end = _date[1];

      this.dataShow = false;
      this.queryListParam.startSearchDate = this.$util.common.DateUtils.dateFormat(start);
      this.queryListParam.endSearchDate = this.$util.common.DateUtils.dateFormat(end);
    },
    showMore: function showMore() {
      this.showMoreFilter = !this.showMoreFilter;
    },
    sureDate: function sureDate() {
      this.$store.commit('global.changeTimeVisible', false);
      this.$emit('sureDate', this.queryListParam);
    },
    changeType: function changeType() {},
    reloadDate: function reloadDate() {
      for (var key in this.queryListParam) {
        this.queryListParam[key] = '';
      }
      this.showMoreFilter = false;
      this.userSelectTime = {};
      this.userSelectOrder = { name: '全部', type: '' };
    },
    clickOrder: function clickOrder(data) {
      this.queryListParam.type = data.type;
      this.userSelectOrder = data;
    },
    clickTime: function clickTime(time) {
      this.userSelectTime = time;
      if (time.id === -1) {
        this.dataShow = true;
      } else {
        this.queryListParam.startSearchDate = this.$util.common.DateUtils.getTimeRegion(this.userSelectTime.time);
        this.queryListParam.endSearchDate = this.$util.common.DateUtils.dateFormat(new Date());
      }
    }
  }
}; //
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

/***/ }),

/***/ "kqKe":
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _defineProperty2 = __webpack_require__("bOdI");

var _defineProperty3 = _interopRequireDefault(_defineProperty2);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var NS = 'stockStatistics.';

exports.default = {
  state: {
    stockStatistics: {
      popupVisible: false // 搜索弹出框
    }
  },
  getters: (0, _defineProperty3.default)({}, NS + 'popupVisible', function (state) {
    return state.stockStatistics.popupVisible;
  }),
  mutations: (0, _defineProperty3.default)({}, NS + 'changePopupVisible', function (state, status) {
    state.stockStatistics.popupVisible = status;
  })
};

/***/ }),

/***/ "lRwf":
/***/ (function(module, exports) {

module.exports = Vue;

/***/ }),

/***/ "o7Is":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
var render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('div',{attrs:{"id":"confirmOut"}},[_c('div',{staticClass:"select-organ"},[_c('img',{staticClass:"position-icon",attrs:{"src":__webpack_require__("GPWr"),"alt":""}}),_vm._v(" "),_c('div',{staticClass:"organ-name"},[_c('p',[_c('span',{staticClass:"gray-text"},[_vm._v("发货组织:")]),_vm._v(" "),_c('span',[_vm._v(_vm._s(_vm.outStockGoods.outOrgName))])]),_vm._v(" "),_c('p',[_c('span',{staticClass:"gray-text"},[_vm._v("出库仓库:")]),_vm._v(" "),(_vm.outStockGoods.outWarehouseName)?_c('span',[_vm._v(_vm._s(_vm.outStockGoods.outWarehouseName))]):_vm._e()])])]),_vm._v(" "),_c('div',{staticClass:"select-organ"},[_c('img',{staticClass:"position-icon",attrs:{"src":__webpack_require__("GPWr"),"alt":""}}),_vm._v(" "),_c('div',{staticClass:"organ-name"},[_c('p',[_c('span',{staticClass:"gray-text"},[_vm._v("收货组织:")]),_vm._v(" "),_c('span',[_vm._v(_vm._s(_vm.outStockGoods.inOrgName))])]),_vm._v(" "),_c('p',[_c('span',{staticClass:"gray-text"},[_vm._v("收货仓库:")]),_vm._v(" "),_c('span',[_vm._v(_vm._s(_vm.outStockGoods.inWarehouseName))])])])]),_vm._v(" "),_c('div',{staticClass:"content"},[_c('div',{staticClass:"goods-list"},_vm._l((_vm.outStockGoods.skuBatchList),function(goods,index){return _c('div',{key:index},[_c('p',{staticClass:"goods-name"},[_c('img',{staticClass:"brand-icon",attrs:{"src":__webpack_require__("hi50"),"alt":""}}),_vm._v(" "),_c('span',[_vm._v(_vm._s(goods.name))])]),_vm._v(" "),_vm._l((goods.list),function(sku,index){return _c('div',{key:index,staticClass:"sku-list"},[_c('span',[_vm._v(_vm._s(sku.batchNo))]),_vm._v(" "),_c('van-stepper',{attrs:{"button-size":"20px","integer":"","max":"999999999"},model:{value:(sku.quality),callback:function ($$v) {_vm.$set(sku, "quality", $$v)},expression:"sku.quality"}})],1)})],2)}),0),_vm._v(" "),_c('div',{staticClass:"remarks"},[_c('span',[_vm._v("备注")]),_vm._v(" "),(_vm.remarksInfo.length==0)?_c('span',{staticClass:"arrow-right",on:{"click":_vm.selectRemarks}},[_vm._v("选填可填一条或者多条")]):_c('span',{staticClass:"arrow-right",on:{"click":_vm.selectRemarks}},[_vm._v(_vm._s(_vm.remarksInfo[0].note))])])]),_vm._v(" "),_c('div',{staticClass:"oper-button"},[_c('span',{staticClass:"blue-button",on:{"click":_vm.submitOrder}},[_vm._v("确认收货")])])])}
var staticRenderFns = []
var esExports = { render: render, staticRenderFns: staticRenderFns }
/* harmony default export */ __webpack_exports__["a"] = (esExports);

/***/ }),

/***/ "oXLK":
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var basedata = {
  getFlag: function getFlag() {
    return window.config.forApp;
  }
  /**
     * 请求后端数据
     */
  // request () {
  //   let getAllCodeSegment = backend.request(api.Pack.getAllCodeSegment, {})
  //   let getTempList = backend.request(api.Pack.getTempList, {})
  //   let getAllWrapper = backend.request(api.Pack.selectAllWrapper, {})
  //   return Promise.all([getAllCodeSegment, getTempList, getAllWrapper]).then(result => {
  //     if (result) {
  //       local.setCodeSegment(result[0])
  //       local.setScannedCode(result[1])
  //       local.setAllWrapper(result[2])
  //     } else {
  //       return Promise.reject(result)
  //     }
  //   }, error => {
  //     let err = backend.convertError(error)
  //     return Promise.reject(err)
  //   })
  // }

};

module.exports = {
  basedata: basedata
};

/***/ }),

/***/ "od2t":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
Object.defineProperty(__webpack_exports__, "__esModule", { value: true });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__babel_loader_node_modules_vue_loader_lib_selector_type_script_index_0_remarksList_vue__ = __webpack_require__("wWSW");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__babel_loader_node_modules_vue_loader_lib_selector_type_script_index_0_remarksList_vue___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0__babel_loader_node_modules_vue_loader_lib_selector_type_script_index_0_remarksList_vue__);
/* harmony namespace reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in __WEBPACK_IMPORTED_MODULE_0__babel_loader_node_modules_vue_loader_lib_selector_type_script_index_0_remarksList_vue__) if(__WEBPACK_IMPORT_KEY__ !== 'default') (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return __WEBPACK_IMPORTED_MODULE_0__babel_loader_node_modules_vue_loader_lib_selector_type_script_index_0_remarksList_vue__[key]; }) }(__WEBPACK_IMPORT_KEY__));
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__node_modules_vue_loader_lib_template_compiler_index_id_data_v_a599f9f6_hasScoped_true_transformToRequire_video_src_poster_source_src_img_src_image_xlink_href_buble_transforms_node_modules_vue_loader_lib_selector_type_template_index_0_remarksList_vue__ = __webpack_require__("Fu5R");
function injectStyle (ssrContext) {
  __webpack_require__("ZY45")
  __webpack_require__("sO0B")
}
var normalizeComponent = __webpack_require__("VU/8")
/* script */


/* template */

/* template functional */
var __vue_template_functional__ = false
/* styles */
var __vue_styles__ = injectStyle
/* scopeId */
var __vue_scopeId__ = "data-v-a599f9f6"
/* moduleIdentifier (server only) */
var __vue_module_identifier__ = null
var Component = normalizeComponent(
  __WEBPACK_IMPORTED_MODULE_0__babel_loader_node_modules_vue_loader_lib_selector_type_script_index_0_remarksList_vue___default.a,
  __WEBPACK_IMPORTED_MODULE_1__node_modules_vue_loader_lib_template_compiler_index_id_data_v_a599f9f6_hasScoped_true_transformToRequire_video_src_poster_source_src_img_src_image_xlink_href_buble_transforms_node_modules_vue_loader_lib_selector_type_template_index_0_remarksList_vue__["a" /* default */],
  __vue_template_functional__,
  __vue_styles__,
  __vue_scopeId__,
  __vue_module_identifier__
)

/* harmony default export */ __webpack_exports__["default"] = (Component.exports);


/***/ }),

/***/ "pRNm":
/***/ (function(module, exports) {

module.exports = VueRouter;

/***/ }),

/***/ "ph76":
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = {
  /**
     * canvas 画图方法
     */
  drawImg: function drawImg(ctx, option) {
    var image = new window.Image();
    image.src = option.src;
    ctx.drawImage(image, option.sx, option.sy, option.sw, option.sh, option.x, option.y, option.w, option.h);
  },
  /**
     * canvas 画图方法 用户画布中画canvas
     */
  drawCanvas: function drawCanvas(ctx, canvas, option) {
    ctx.drawImage(canvas, option.sx, option.sy, option.sw, option.sh, option.x, option.y, option.w, option.h);
  },
  /**
     * canvas 画圆方法
     */
  drawCircular: function drawCircular(ctx, option) {
    ctx.beginPath();
    /**
     * 设置弧线的颜色
     * @type {[type]}
     */
    ctx.strokeStyle = option.strokeStyle;
    /**
          * 设置背景颜色rgba(141, 141, 141, 1)
          * @type {[type]}
          */
    ctx.fillStyle = option.fillStyle;
    /**
      * option.x,    圆心的x轴坐标值
      * option.y,    圆心的y轴坐标值
      * option.r     圆的半径
      */
    var sAngle = option.sAngle || 0;
    var eAngle = option.eAngle || 2;
    ctx.arc(option.x, option.y, option.r, sAngle * Math.PI, eAngle * Math.PI);
    ctx.closePath();
    ctx.stroke();
    ctx.fill();
  },

  /**
     * 画圆角矩形
     * @type {[type]}
     */
  drawRoundedRect: function drawRoundedRect(ctx, temp) {
    var roundedRect = function roundedRect(ctx, x, y, w, h, radius) {
      if (w > 0) {
        ctx.moveTo(x + radius, y);
      } else {
        ctx.moveTo(x - radius, y);
      }
      ctx.arcTo(x + w, y, x + w, y + h, radius);
      ctx.arcTo(x + w, y + h, x, y + h, radius);
      ctx.arcTo(x, y + h, x, y, radius);
      if (w > 0) {
        ctx.arcTo(x, y, x + radius, y, radius);
      } else {
        ctx.arcTo(x, y, x - radius, y, radius);
      }
    };
    ctx.beginPath();
    roundedRect(ctx, temp.x, temp.y, temp.w, temp.h, temp.radius);
    ctx.strokeStyle = temp.strokeStyle;
    ctx.fillStyle = temp.fillStyle;
    ctx.stroke();
    ctx.fill();
  },
  /**
     * canvas 写文字方法
     */
  fillText: function fillText(ctx, option, text, x, y) {
    ctx.font = option.font;
    ctx.fillStyle = option.fillStyle;
    if (option.textAlign) {
      ctx.textAlign = option.textAlign;
    } else {
      ctx.textAlign = 'start';
    }
    if (option.textBaseline) {
      ctx.textBaseline = option.textBaseline;
    } else {
      ctx.textBaseline = 'top';
    }
    ctx.fillText(text, x, y);
  },
  /**
     * canvas 画线
     */
  drawLine: function drawLine(ctx, option) {
    /**
         * 设置填充颜色
         * @type {String}
         */
    ctx.strokeStyle = option.fillStyle;
    ctx.lineWidth = option.lineWidth ? option.lineWidth : 1;
    ctx.beginPath();
    /**
         * 将画笔移到x0,y0处
         */
    ctx.moveTo(option.x0, option.y0);
    /**
         * 从x0,y0到x1,y1画一条线
         */
    ctx.lineTo(option.x1, option.y1);
    ctx.closePath();
    ctx.stroke();
    ctx.fill();
  },
  /**
     * canvas 画横向带箭头的线
     */
  drawArrowLine: function drawArrowLine(ctx, option) {
    /**
         * 设置填充颜色
         * @type {String}
         */
    ctx.strokeStyle = option.fillStyle;
    ctx.lineWidth = option.lineWidth;
    ctx.fillStyle = option.fillStyle;
    ctx.beginPath();
    /**
         * 将画笔移到x0,y0处
         */
    ctx.moveTo(option.x0, option.y0);
    /**
         * 从x0,y0到x1,y1画一条线
         */
    ctx.lineTo(option.x1 - 1, option.y1);
    ctx.closePath();
    ctx.stroke();
    ctx.beginPath();
    /**
         * 从x1,y1画两5像素的条线形成箭头
         */
    ctx.lineTo(option.x1 - option.r, option.y1 + option.r * 2 / 3);
    ctx.lineTo(option.x1 - 1, option.y1);
    ctx.lineTo(option.x1 - option.r, option.y1 - option.r * 2 / 3);
    ctx.closePath();
    ctx.stroke();
    ctx.fill();
  },
  /**
     * 缩放
     */
  resizeImage: function resizeImage(image, width, height) {
    var canvas = document.createElement('canvas');
    var ctx = canvas.getContext('2d');
    canvas.width = width;
    canvas.height = height;
    ctx.drawImage(image, 0, 0, width, height);
    var dataUrl = canvas.toDataURL('image/jpeg');
    var dest = new window.Image();
    dest.src = dataUrl;
    return dest;
  },

  /**
     * 压缩
     */
  compressImage: function compressImage(image) {
    var maxWidth = 1024;
    var maxHeight = 1536;
    var scale = 0;
    var nwidth = image.width;
    var nheight = image.height;
    // 压缩
    if (image.width > maxWidth) {
      nwidth = maxWidth;
      scale = image.width / image.height;
      nheight = parseInt(nwidth / scale);
      image = this.resizeImage(image, nwidth, nheight);
    }
    if (image.height > maxHeight) {
      nheight = maxHeight;
      scale = image.height / image.width;
      nwidth = parseInt(nheight / scale);
      image = this.resizeImage(image, nwidth, nheight);
    }
    var size = image.width * image.height;
    if (size > 1024 * 300) {
      var canvas = document.createElement('canvas');
      var ctx = canvas.getContext('2d');
      canvas.width = image.width;
      canvas.height = image.height;
      ctx.drawImage(image, 0, 0, image.width, image.height);
      var dataUrl = canvas.toDataURL('image/jpeg', 0.9);
      image.src = dataUrl;
    }
    return image;
  }
};

/***/ }),

/***/ "r+E3":
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var _vue = __webpack_require__("lRwf");

var _vue2 = _interopRequireDefault(_vue);

var _app = __webpack_require__("VqKR");

var _app2 = _interopRequireDefault(_app);

var _router = __webpack_require__("jz1p");

var _router2 = _interopRequireDefault(_router);

var _jquery = __webpack_require__("0iPh");

var _jquery2 = _interopRequireDefault(_jquery);

var _vant = __webpack_require__("Fd2+");

var _vant2 = _interopRequireDefault(_vant);

__webpack_require__("4ml/");

var _backend = __webpack_require__("5pKY");

var _backend2 = _interopRequireDefault(_backend);

var _store = __webpack_require__("IcnI");

var _store2 = _interopRequireDefault(_store);

var _index = __webpack_require__("0xDb");

var _index2 = _interopRequireDefault(_index);

var _scanOrderIn = __webpack_require__("C9Fg");

var _scanOrderIn2 = _interopRequireDefault(_scanOrderIn);

var _common = __webpack_require__("ya2q");

var _common2 = _interopRequireDefault(_common);

var _basedata = __webpack_require__("oXLK");

__webpack_require__("2GmJ");

var _vueClipboard = __webpack_require__("wvfG");

var _vueClipboard2 = _interopRequireDefault(_vueClipboard);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

/* import '../../assets/css/common/index.css' */
// The Vue build version to load with the `import` command
// (runtime-only or standalone) has been set in webpack.base.conf with an alias.
_vue2.default.use(_vueClipboard2.default);
_vue2.default.config.productionTip = false;
_vue2.default.use(_vant2.default);

Object.defineProperty(_vue2.default.prototype, '$backend', {
  get: function get() {
    return _backend2.default;
  }
});

Object.defineProperty(_vue2.default.prototype, '$util', {
  get: function get() {
    return _index2.default;
  }
});

Object.defineProperty(_vue2.default.prototype, '$api', {
  get: function get() {
    return _scanOrderIn2.default;
  }
});

Object.defineProperty(_vue2.default.prototype, '$commonApi', {
  get: function get() {
    return _common2.default;
  }
});

Object.defineProperty(_vue2.default.prototype, '$basedata', {
  get: function get() {
    return _basedata.basedata;
  }
});

Object.defineProperty(_vue2.default.prototype, '$', {
  get: function get() {
    return _jquery2.default;
  }
});

/* eslint-disable no-new */
new _vue2.default({
  el: '#app',
  store: _store2.default,
  router: _router2.default,
  components: { App: _app2.default },
  template: '<App/>'
});

/***/ }),

/***/ "sO0B":
/***/ (function(module, exports) {

// removed by extract-text-webpack-plugin

/***/ }),

/***/ "srZF":
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _getIterator2 = __webpack_require__("BO1k");

var _getIterator3 = _interopRequireDefault(_getIterator2);

var _stringify = __webpack_require__("mvHQ");

var _stringify2 = _interopRequireDefault(_stringify);

var _vant = __webpack_require__("Fd2+");

var _timeSelect = __webpack_require__("6Hho");

var _timeSelect2 = _interopRequireDefault(_timeSelect);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

exports.default = {
  name: 'orderInStock',
  data: function data() {
    return {
      orderStatus: [{ name: '待收货', id: 2, status: 2, num: 0 }, { name: '收货中', id: 3, status: 3, num: 0 }, { name: '已收货', id: 4, status: 4, num: 0 }, { name: '已拒收', id: 6, status: 6, num: 0 }, { name: '全部', id: -1, status: '', num: 0 }],
      selectData: { name: '待收货', id: 2, status: 2 },
      orderList: [],
      search: {
        current: 1,
        rows: 20,
        order: 'createDate',
        asc: false,
        status: 2
      },
      loading: false,
      finished: false,
      pageTotal: '',
      styleColorList: ['blue-text', 'yellow-text', 'yellow-text', 'yellow-text', 'green-text', 'red-text'],
      filterItem: {}
    };
  },

  components: {
    timeSelect: _timeSelect2.default
  },
  activated: function activated() {
    this.orderList = [];
    this.search.current = 1;
    this.getOrderList();
  },

  filters: {
    orderStatus: function orderStatus(data) {
      if (data === 2) {
        return '待收货';
      } else if (data === 3) {
        return '收货中';
      } else if (data === 4) {
        return '已收货';
      } else if (data === 6) {
        return '已拒收';
      } else if (data === 5) {
        return '已取消';
      }
    }
  },
  methods: {
    showMore: function showMore(order, goodsIndex) {
      console.log(goodsIndex);
      if (goodsIndex <= 2) {
        return true;
      }
      if (order.arrowFlag && goodsIndex > 2) {
        return false;
      }
      return true;
    },
    changeArrowStatus: function changeArrowStatus(order) {
      console.log(order.arrowFlag);
      order.arrowFlag = !order.arrowFlag;
    },
    confirm: function confirm(order) {
      console.log(order);
      this.$store.commit('global.changeOutStockGoods', order);
      this.$router.push({ name: 'confirmIn' });
    },
    scan: function scan(order) {
      this.$router.push({ name: 'scanRecordIn', params: { id: order.id } });
    },
    sureDate: function sureDate(data) {
      console.log(data);
      this.filterItem = JSON.parse((0, _stringify2.default)(data));
      this.orderList = [];
      this.search.current = 1;
      this.finished = false;
      /* this.search.startSearchDate = data.startSearchDate
      this.search.endSearchDate = data.endSearchDate
      this.search.keyword = data.keyword */
      for (var key in data) {
        this.search[key] = data[key];
      }
      this.getOrderList();
    },
    cancel: function cancel(order) {
      var _this = this;

      _vant.Dialog.confirm({
        title: '拒收订单',
        message: '是否拒收当前入库单'
      }).then(function () {
        var param = {};
        param.id = order.id;
        return _this.$backend.request(_this.$api.scanOrderIn.cancel, param).then(function (res) {
          if (res.success) {
            _this.orderList = [];
            _this.search.current = 1;
            _this.finished = false;
            _this.getOrderList();
          } else {
            (0, _vant.Toast)(res.message);
          }
        });
      }).catch(function () {});
    },
    onLoad: function onLoad() {
      console.log('下拉');
      this.search.current++;
      if (this.search.current > this.pageTotal) {
        this.finished = true;
        return;
      }
      this.getOrderList();
    },
    createOrder: function createOrder() {
      this.$router.push({ name: 'selectGoods' });
    },
    selectStatus: function selectStatus(order) {
      try {
        document.getElementById('order-list').scrollTop = 0;
      } catch (e) {
        console.log(e);
      }
      this.orderList = [];
      this.search.current = 1;
      this.finished = false;
      this.selectData = order;
      this.search.status = order.status;
      this.getOrderList();
    },
    viewDetails: function viewDetails(order) {
      this.$store.commit('global.changeOutInDetails', order);
      this.$router.push({ name: 'inStockDetails', params: { id: order.id } });
    },
    getOrderNum: function getOrderNum() {
      var _this2 = this;

      var data = {};
      for (var key in this.filterItem) {
        data[key] = this.filterItem[key];
      }
      data.stockType = 2;
      this.$backend.request(this.$api.scanOrderIn.orderNum, data).then(function (result) {
        console.log(result);
        var _iteratorNormalCompletion = true;
        var _didIteratorError = false;
        var _iteratorError = undefined;

        try {
          for (var _iterator = (0, _getIterator3.default)(_this2.orderStatus), _step; !(_iteratorNormalCompletion = (_step = _iterator.next()).done); _iteratorNormalCompletion = true) {
            var orderStatus = _step.value;

            orderStatus.num = 0;
            if (orderStatus.status === '') {
              for (var _key in result.data) {
                orderStatus.num += result.data[_key];
              }
              continue;
            }
            for (var _key2 in result.data) {
              if (parseInt(orderStatus.status) === parseInt(_key2)) {
                orderStatus.num = result.data[_key2];
                break;
              }
            }
          }
        } catch (err) {
          _didIteratorError = true;
          _iteratorError = err;
        } finally {
          try {
            if (!_iteratorNormalCompletion && _iterator.return) {
              _iterator.return();
            }
          } finally {
            if (_didIteratorError) {
              throw _iteratorError;
            }
          }
        }
      });
    },
    getOrderList: function getOrderList() {
      var _this3 = this;

      this.$backend.request(this.$api.scanOrderIn.stockOutIn, this.search).then(function (result) {
        _this3.getOrderNum();
        console.log(result);
        _this3.pageTotal = Math.ceil(result.total / _this3.search.rows);
        var _iteratorNormalCompletion2 = true;
        var _didIteratorError2 = false;
        var _iteratorError2 = undefined;

        try {
          for (var _iterator2 = (0, _getIterator3.default)(result.rows), _step2; !(_iteratorNormalCompletion2 = (_step2 = _iterator2.next()).done); _iteratorNormalCompletion2 = true) {
            var order = _step2.value;

            order.skuBatchList = _this3.$util.common.ArrayUtils.groupArr(order.bizOrderDetails, 'skuId', 'skuName');
            order.goodsTotalCount = 0;
            order.goodsTotal = order.skuBatchList.length;
            order.arrowFlag = true;
            var _iteratorNormalCompletion3 = true;
            var _didIteratorError3 = false;
            var _iteratorError3 = undefined;

            try {
              for (var _iterator3 = (0, _getIterator3.default)(order.skuBatchList), _step3; !(_iteratorNormalCompletion3 = (_step3 = _iterator3.next()).done); _iteratorNormalCompletion3 = true) {
                var sku = _step3.value;
                var _iteratorNormalCompletion4 = true;
                var _didIteratorError4 = false;
                var _iteratorError4 = undefined;

                try {
                  for (var _iterator4 = (0, _getIterator3.default)(sku.list), _step4; !(_iteratorNormalCompletion4 = (_step4 = _iterator4.next()).done); _iteratorNormalCompletion4 = true) {
                    var batchInfo = _step4.value;

                    order.goodsTotalCount += parseInt(batchInfo.quality);
                  }
                } catch (err) {
                  _didIteratorError4 = true;
                  _iteratorError4 = err;
                } finally {
                  try {
                    if (!_iteratorNormalCompletion4 && _iterator4.return) {
                      _iterator4.return();
                    }
                  } finally {
                    if (_didIteratorError4) {
                      throw _iteratorError4;
                    }
                  }
                }
              }
            } catch (err) {
              _didIteratorError3 = true;
              _iteratorError3 = err;
            } finally {
              try {
                if (!_iteratorNormalCompletion3 && _iterator3.return) {
                  _iterator3.return();
                }
              } finally {
                if (_didIteratorError3) {
                  throw _iteratorError3;
                }
              }
            }

            _this3.orderList.push(order);
          }
        } catch (err) {
          _didIteratorError2 = true;
          _iteratorError2 = err;
        } finally {
          try {
            if (!_iteratorNormalCompletion2 && _iterator2.return) {
              _iterator2.return();
            }
          } finally {
            if (_didIteratorError2) {
              throw _iteratorError2;
            }
          }
        }

        _this3.loading = false;
        /* return result */
      });
    }
  }
};

/***/ }),

/***/ "svz7":
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _session = __webpack_require__("hDMw");

var _session2 = _interopRequireDefault(_session);

var _baseData = __webpack_require__("B0cl");

var _baseData2 = _interopRequireDefault(_baseData);

var _local = __webpack_require__("FITS");

var _local2 = _interopRequireDefault(_local);

var _store = __webpack_require__("IcnI");

var _store2 = _interopRequireDefault(_store);

var _backend = __webpack_require__("5pKY");

var _backend2 = _interopRequireDefault(_backend);

var _basedata = __webpack_require__("3pX5");

var _basedata2 = _interopRequireDefault(_basedata);

var _vue = __webpack_require__("lRwf");

var _vue2 = _interopRequireDefault(_vue);

var _mintUi = __webpack_require__("Au9i");

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = {
  /**
    *  初始化JsBridge
    */
  setupWebViewJavascriptBridge: function setupWebViewJavascriptBridge(callback) {
    var u = navigator.userAgent;
    // android终端
    var isAndroid = u.indexOf('Android') > -1 || u.indexOf('Adr') > -1;
    // ios终端
    var isiOS = !!u.match(/\(i[^;]+;( U;)? CPU.+Mac OS X/);
    if (isAndroid) {
      if (window.WebViewJavascriptBridge) {
        callback(window.WebViewJavascriptBridge);
      } else {
        document.addEventListener('WebViewJavascriptBridgeReady', function () {
          callback(window.WebViewJavascriptBridge);
        }, false);
      }
    } else if (isiOS) {
      if (window.WebViewJavascriptBridge) {
        return callback(window.WebViewJavascriptBridge);
      }
      if (window.WVJBCallbacks) {
        return window.WVJBCallbacks.push(callback);
      }
      // 创建一个 WVJBCallbacks 全局属性数组，并将 callback 插入到数组中。
      window.WVJBCallbacks = [callback];
      // 创建一个 iframe 元素
      var WVJBIframe = document.createElement('iframe');
      // 不显示
      WVJBIframe.style.display = 'none';
      // 设置 iframe 的 src 属性
      WVJBIframe.src = 'wvjbscheme://__BRIDGE_LOADED__';
      // 把 iframe 添加到当前文导航上。
      document.documentElement.appendChild(WVJBIframe);
      setTimeout(function () {
        document.documentElement.removeChild(WVJBIframe);
      }, 0);
    }
  },
  getData: function getData(callback) {
    var _this = this;

    if (window.config.forApp) {
      // 请求用户数据、手机系统数据、位置数据
      // let getList = [new Promise(this.getUserInfo), new Promise(this.getSystemInfo), new Promise(this.getPositionInfo)]
      this.setupWebViewJavascriptBridge(function (bridge) {
        _this.getUserInfo(bridge);
        _this.getSystemInfo(bridge, callback);
        _this.getPositionInfo(bridge);
      });
    } else {
      // session.setLoginUser(baseData.userInfo)
      /* 本地调试配置路径 */
      var data = {};
      data.serverUrl = window.config.userInfo.serverUrl;
      _session2.default.setLoginUser(data);
      _local2.default.setPositionInfo(_baseData2.default.positionInfo);
      _local2.default.setSystemInfo(_baseData2.default.systemInfo);
      this.tempLogin().then(function () {
        if (callback) callback();
      });
    }
  },

  // 请求用户数据
  getUserInfo: function getUserInfo(bridge) {
    bridge.callHandler('getUserInfo', {}, function (dataFromOC) {
      var dataInfo = JSON.parse(dataFromOC);
      if (dataInfo.resultCode === '0') {
        _session2.default.setLoginUser(dataInfo.data);
      }
    });
  },

  // 临时登录方法
  tempLogin: function tempLogin() {
    _vue2.default.http.headers.common['TenantId'] = window.config.userInfo.tenantId;
    return _backend2.default.request(_basedata2.default.Base.tempLogin, {
      userName: window.config.userInfo.userName,
      password: window.config.userInfo.password,
      tenantId: window.config.userInfo.tenantId
    }).then(function (res) {
      if (res.resultCode === '0') {
        /* res.data.orgName = '程礼邦工厂' */
        res.data.serverUrl = window.config.userInfo.serverUrl;
        _session2.default.setLoginUser(res.data);
      }
    });
  },

  /* H5应用写日志 */
  writeError: function writeError(data, callback) {
    this.setupWebViewJavascriptBridge(function (bridge) {
      bridge.callHandler('error', { data: data }, function (result) {
        if (callback) callback(result);
      });
    });
  },

  // 请求手机系统数据
  getSystemInfo: function getSystemInfo(bridge, callback) {
    bridge.callHandler('getSystemInfo', {}, function (dataFromOC) {
      // window.alert(dataFromOC)
      var dataInfo = JSON.parse(dataFromOC);
      _local2.default.setSystemInfo(dataInfo);
      if (callback) callback();
    });
  },

  // 请求位置数据
  getPositionInfo: function getPositionInfo(bridge, callback) {
    bridge.callHandler('getPosition', {}, function (dataFromOC) {
      _local2.default.setPositionInfo(JSON.parse(dataFromOC));
      if (callback) callback();
    });
  },

  // 初始化扫码窗口
  initScanView: function initScanView(mode, height, message, isPullable, header, fixed, callback) {
    // this.openMessageBox('调试信息', '', `调用initScanView方法：mode: ${mode};height: ${height};message: ${message};isPullable: ${isPullable};header: ${header};fixed: ${fixed};`, '', '关闭', false)
    this.setupWebViewJavascriptBridge(function (bridge) {
      var param = {
        mode: mode, // 扫码类型，QCC：量子云码、QR：二维码、BC：条形码、VC：虚拟码
        flash: 'off', // 闪光灯，值为 on, off
        devicePosition: 0, // 摄像头朝向，front：前置1、back：后置0
        webviewHeight: height, // 底部webview展示内容高度，单位%，0为不展示
        message: message, // 扫码提示信息
        isPullable: isPullable, // Webview是否可拉动
        header: header,
        fixed: fixed
        // window.alert('initScanView调用成功' + JSON.stringify(param))
      };bridge.callHandler('initScanView', param, function (result) {
        // window.alert('initScanView调用成功' + JSON.stringify(result))
        if (callback) callback(result);
      });
    });
  },

  // 重新设置扫码页面样式
  changeScanView: function changeScanView(height, message, isPullable, header, fixed, callback) {
    // this.openMessageBox('调试信息', '', `调用changeScanView方法：height: ${height};message: ${message};isPullable: ${isPullable};header: ${header};fixed: ${fixed};`, '', '关闭', false)
    this.setupWebViewJavascriptBridge(function (bridge) {
      bridge.callHandler('changeScanView', {
        webviewHeight: height,
        message: message,
        isPullable: isPullable,
        header: header,
        fixed: fixed
      }, function (result) {
        if (callback) callback(result);
      });
    });
  },

  // 打开弹窗提示
  openMessageBox: function openMessageBox(title, alert, message, cancelButtonText, confirmButtonText, buttonLinefeed, callback) {
    if (!window.config.forApp) {
      (0, _mintUi.MessageBox)({
        title: title,
        message: message,
        showCancelButton: cancelButtonText !== '',
        showConfirmButton: confirmButtonText !== '',
        cancelButtonText: cancelButtonText,
        confirmButtonText: confirmButtonText
      }).then(function (action) {
        if (callback) callback(action);
      });
    }
    this.setupWebViewJavascriptBridge(function (bridge) {
      bridge.callHandler('openMessageBox', {
        title: title,
        alert: alert,
        message: message,
        cancelButtonText: cancelButtonText,
        confirmButtonText: confirmButtonText,
        buttonLinefeed: buttonLinefeed // 超过五个字换行
      }, function (result) {
        _store2.default.commit('global.changeScanFlag', false); // 解锁
        if (callback) callback(result);
      });
    });
  },

  // 设置扫码界面显示状态接口(true显示预览页面、false隐藏预览页面)
  showScanView: function showScanView(isShow, callback) {
    // this.openMessageBox('调试信息', '', `调用showScanView方法：isShow: ${isShow};`, '', '关闭', false)
    this.setupWebViewJavascriptBridge(function (bridge) {
      bridge.callHandler('showScanView', { isShow: isShow }, function (result) {
        if (callback) callback(result);
      });
    });
  },

  // 切换扫码方式
  switchScanMode: function switchScanMode(scanMode, callback) {
    this.setupWebViewJavascriptBridge(function (bridge) {
      bridge.callHandler('switchScanMode', { mode: scanMode }, function (result) {
        // window.alert(JSON.stringify(result))
        if (callback) callback(result);
      });
    });
  },

  // 语音提示
  //   StockSuccess：出库成功
  //   StockFail：出库失败
  //   PackSuccess：打包成功
  //   PackFail：打包失败
  //   ShipSuccess：发货成功
  //   ShipFail：发货失败
  //   RemoveSuccess：解除成功
  //   FailSuccess：解除失败
  //   ScanSuccess：扫码成功
  //   ScanFail：扫码失败
  //   ScanRepeat：扫码重复
  //   replaceSuccess：替换成功
  //   replaceFailure：替换失败
  //   ScanSuperCode: 请扫描上级码+扫码成功
  //   AppendSuccess: 追加成功
  //   AppendFailure: 追加失败
  voiceAlert: function voiceAlert(type, callback) {
    this.setupWebViewJavascriptBridge(function (bridge) {
      bridge.callHandler('voicePrompts', { type: type }, function (result) {
        if (callback) callback();
      });
    });
  },

  // 上传图片
  uploadImage: function uploadImage(callback) {
    this.setupWebViewJavascriptBridge(function (bridge) {
      bridge.callHandler('uploadImage', {}, function (result) {
        if (callback) callback(result);
      });
    });
  },

  // 重新定位
  reloadPosition: function reloadPosition(callback) {
    this.setupWebViewJavascriptBridge(function (bridge) {
      bridge.callHandler('reloadPosition', {}, function (result) {
        if (callback) callback(result);
      });
    });
  },

  // 重新登录
  tokenFail: function tokenFail(callback) {
    this.setupWebViewJavascriptBridge(function (bridge) {
      bridge.callHandler('tokenFail', {}, function (result) {
        if (callback) callback(result);
      });
    });
  },

  // 退出小程序
  existApplet: function existApplet(callback) {
    this.setupWebViewJavascriptBridge(function (bridge) {
      bridge.callHandler('existApplet', {}, function (result) {
        if (callback) callback(result);
      });
    });
  },

  // 设置扫码状态接口（不关闭扫码框）
  setScanStatus: function setScanStatus(status, callback) {
    // window.alert('setScanStatus:' + status)
    this.setupWebViewJavascriptBridge(function (bridge) {
      bridge.callHandler('setScanStatus', { status: status }, function (result) {
        if (callback) callback(result);
      });
    });
  },

  // 注册路由回退接口
  goBackHistory: function goBackHistory(callback) {
    // this.openMessageBox('调试信息', '', `调用goBackHistory方法`, '', '关闭', false)
    this.setupWebViewJavascriptBridge(function (bridge) {
      bridge.registerHandler('goBackHistory', function (data, cb) {
        // this.openMessageBox('调试信息', '', JSON.stringify(callback), '', '关闭', false)
        if (callback) callback(data, cb);
      });
    });
  },

  // 注册扫码回调接口
  syncScanResult: function syncScanResult(callback) {
    this.setupWebViewJavascriptBridge(function (bridge) {
      bridge.registerHandler('syncScanResult', function (data, cb) {
        if (!callback) return;
        var scanFlag = _store2.default.getters['global.scanFlag'];
        if (scanFlag) return (0, _mintUi.Toast)({ message: '请等待扫码完成', duration: 500 });
        _store2.default.commit('global.changeScanFlag', true); // 加锁
        // this.$store.commit('global.changeScanFlag', false) // 解锁
        var scannedInfo = JSON.parse(data);
        if (scannedInfo.mode === 'BC') scannedInfo.code = scannedInfo.codeStr; // 条形码
        scannedInfo.codeType = scannedInfo.vid !== '' ? 1 : 2; // 1.量子云码 2.条形码
        if (scannedInfo.resultCode === 0) {
          if (callback) callback(scannedInfo, cb);
        } else {
          // this.$store.commit('global.changeScanFlag', false) // 解锁
          // return Toast({ message: '扫码错误,请继续扫码', duration: 500 })
        }
      });
    });
  },

  // =============================破损标签作废小应用相关接口==========================
  // 请求手机当前语言
  getLanguage: function getLanguage(callback) {
    this.setupWebViewJavascriptBridge(function (bridge) {
      bridge.callHandler('getLanguage', { 'code': true }, function (result) {
        if (callback) callback(result);
      });
    });
  },

  // 请求用户UserId
  getUserId: function getUserId(callback) {
    this.setupWebViewJavascriptBridge(function (bridge) {
      bridge.callHandler('getUserId', { 'code': true }, function (result) {
        // window.alert(result)
        if (callback) callback(result);
      });
    });
  },

  // 注册蓝牙扫码回调接口
  syncBluethoodScanResult: function syncBluethoodScanResult(callback) {
    this.setupWebViewJavascriptBridge(function (bridge) {
      bridge.registerHandler('syncBluethoodScanResult', function (data, cb) {
        if (callback) callback(data, cb);
      });
    });
  }
};

/***/ }),

/***/ "t33/":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
Object.defineProperty(__webpack_exports__, "__esModule", { value: true });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__babel_loader_node_modules_vue_loader_lib_selector_type_script_index_0_batchScanRecord_vue__ = __webpack_require__("MLfX");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__babel_loader_node_modules_vue_loader_lib_selector_type_script_index_0_batchScanRecord_vue___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0__babel_loader_node_modules_vue_loader_lib_selector_type_script_index_0_batchScanRecord_vue__);
/* harmony namespace reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in __WEBPACK_IMPORTED_MODULE_0__babel_loader_node_modules_vue_loader_lib_selector_type_script_index_0_batchScanRecord_vue__) if(__WEBPACK_IMPORT_KEY__ !== 'default') (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return __WEBPACK_IMPORTED_MODULE_0__babel_loader_node_modules_vue_loader_lib_selector_type_script_index_0_batchScanRecord_vue__[key]; }) }(__WEBPACK_IMPORT_KEY__));
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__node_modules_vue_loader_lib_template_compiler_index_id_data_v_68423089_hasScoped_true_transformToRequire_video_src_poster_source_src_img_src_image_xlink_href_buble_transforms_node_modules_vue_loader_lib_selector_type_template_index_0_batchScanRecord_vue__ = __webpack_require__("I9mY");
function injectStyle (ssrContext) {
  __webpack_require__("ZXMR")
}
var normalizeComponent = __webpack_require__("VU/8")
/* script */


/* template */

/* template functional */
var __vue_template_functional__ = false
/* styles */
var __vue_styles__ = injectStyle
/* scopeId */
var __vue_scopeId__ = "data-v-68423089"
/* moduleIdentifier (server only) */
var __vue_module_identifier__ = null
var Component = normalizeComponent(
  __WEBPACK_IMPORTED_MODULE_0__babel_loader_node_modules_vue_loader_lib_selector_type_script_index_0_batchScanRecord_vue___default.a,
  __WEBPACK_IMPORTED_MODULE_1__node_modules_vue_loader_lib_template_compiler_index_id_data_v_68423089_hasScoped_true_transformToRequire_video_src_poster_source_src_img_src_image_xlink_href_buble_transforms_node_modules_vue_loader_lib_selector_type_template_index_0_batchScanRecord_vue__["a" /* default */],
  __vue_template_functional__,
  __vue_styles__,
  __vue_scopeId__,
  __vue_module_identifier__
)

/* harmony default export */ __webpack_exports__["default"] = (Component.exports);


/***/ }),

/***/ "t3Hx":
/***/ (function(module, exports) {

// removed by extract-text-webpack-plugin

/***/ }),

/***/ "u8EM":
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/img/emptyBox.755c8e3.png";

/***/ }),

/***/ "uJ/+":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
var render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('div',{attrs:{"id":"timeSelect"}},[(_vm.timeVisible)?_c('div',{staticClass:"time-select"},[(_vm.showFilter!==0)?_c('div',{staticClass:"search-filter",class:_vm.showMoreFilter?'':'search-filter-height'},[_c('p',[_vm._v("输入关键字:")]),_vm._v(" "),_c('van-search',{attrs:{"placeholder":"请输入商品名称查询"},model:{value:(_vm.queryListParam.skuName),callback:function ($$v) {_vm.$set(_vm.queryListParam, "skuName", $$v)},expression:"queryListParam.skuName"}}),_vm._v(" "),_c('van-search',{attrs:{"placeholder":"请输入订单编号查询"},model:{value:(_vm.queryListParam.stockOutNo),callback:function ($$v) {_vm.$set(_vm.queryListParam, "stockOutNo", $$v)},expression:"queryListParam.stockOutNo"}}),_vm._v(" "),_c('van-search',{attrs:{"placeholder":"请输入生产批次号查询"},model:{value:(_vm.queryListParam.batchNo),callback:function ($$v) {_vm.$set(_vm.queryListParam, "batchNo", $$v)},expression:"queryListParam.batchNo"}}),_vm._v(" "),_c('van-search',{attrs:{"placeholder":"请输入发货组织查询"},model:{value:(_vm.queryListParam.outOrgName),callback:function ($$v) {_vm.$set(_vm.queryListParam, "outOrgName", $$v)},expression:"queryListParam.outOrgName"}}),_vm._v(" "),_c('van-search',{attrs:{"placeholder":"请输入接收组织查询"},model:{value:(_vm.queryListParam.inOrgName),callback:function ($$v) {_vm.$set(_vm.queryListParam, "inOrgName", $$v)},expression:"queryListParam.inOrgName"}})],1):_vm._e(),_vm._v(" "),_c('p',{staticClass:"blue-text",staticStyle:{"text-align":"right"},on:{"click":_vm.showMore}},[_vm._v(_vm._s(_vm.showMoreFilter?'收起':'更多筛选条件'))]),_vm._v(" "),(_vm.showOrderFilter)?_c('div',{staticClass:"time-list"},[_c('p',{staticClass:"time-title"},[_vm._v("按订单来源:")]),_vm._v(" "),_c('ul',_vm._l((_vm.orderOrigin),function(data,index){return _c('li',{key:index,class:{ 'time-active': _vm.userSelectOrder.type == data.type },on:{"click":function($event){return _vm.clickOrder(data)}}},[_vm._v(_vm._s(data.name))])}),0)]):_vm._e(),_vm._v(" "),_c('div',{staticClass:"time-list"},[_c('p',{staticClass:"time-title"},[_vm._v("快捷选择:")]),_vm._v(" "),_c('ul',_vm._l((_vm.submitTime),function(data,index){return _c('li',{key:index,class:{ 'time-active': _vm.userSelectTime.id == data.id },on:{"click":function($event){return _vm.clickTime(data)}}},[_vm._v(_vm._s(data.name))])}),0),_vm._v(" "),_c('p',{staticClass:"time-title"},[_vm._v("时间:")]),_vm._v(" "),(_vm.queryListParam.startSearchDate!=='')?_c('p',{staticClass:"data-time"},[_vm._v(_vm._s(_vm.queryListParam.startSearchDate.split(' ')[0])+"至"+_vm._s(_vm.queryListParam.endSearchDate.split(' ')[0]))]):_vm._e()]),_vm._v(" "),_c('div',{staticClass:"oper-button"},[_c('span',{staticClass:"common-button",on:{"click":_vm.reloadDate}},[_vm._v("重置")]),_vm._v(" "),_c('span',{staticClass:"blue-button",on:{"click":_vm.sureDate}},[_vm._v("确定")])])]):_vm._e(),_vm._v(" "),_c('van-calendar',{attrs:{"type":"range","min-date":_vm.minDate},on:{"confirm":_vm.onConfirm},model:{value:(_vm.dataShow),callback:function ($$v) {_vm.dataShow=$$v},expression:"dataShow"}}),_vm._v(" "),(_vm.timeVisible)?_c('div',{staticClass:"load-overlay"}):_vm._e()],1)}
var staticRenderFns = []
var esExports = { render: render, staticRenderFns: staticRenderFns }
/* harmony default export */ __webpack_exports__["a"] = (esExports);

/***/ }),

/***/ "v7pW":
/***/ (function(module, exports) {

// removed by extract-text-webpack-plugin

/***/ }),

/***/ "wKWR":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
Object.defineProperty(__webpack_exports__, "__esModule", { value: true });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__babel_loader_node_modules_vue_loader_lib_selector_type_script_index_0_scanRecordIn_vue__ = __webpack_require__("IpUx");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__babel_loader_node_modules_vue_loader_lib_selector_type_script_index_0_scanRecordIn_vue___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0__babel_loader_node_modules_vue_loader_lib_selector_type_script_index_0_scanRecordIn_vue__);
/* harmony namespace reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in __WEBPACK_IMPORTED_MODULE_0__babel_loader_node_modules_vue_loader_lib_selector_type_script_index_0_scanRecordIn_vue__) if(__WEBPACK_IMPORT_KEY__ !== 'default') (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return __WEBPACK_IMPORTED_MODULE_0__babel_loader_node_modules_vue_loader_lib_selector_type_script_index_0_scanRecordIn_vue__[key]; }) }(__WEBPACK_IMPORT_KEY__));
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__node_modules_vue_loader_lib_template_compiler_index_id_data_v_205227be_hasScoped_true_transformToRequire_video_src_poster_source_src_img_src_image_xlink_href_buble_transforms_node_modules_vue_loader_lib_selector_type_template_index_0_scanRecordIn_vue__ = __webpack_require__("gJ0n");
function injectStyle (ssrContext) {
  __webpack_require__("23rF")
}
var normalizeComponent = __webpack_require__("VU/8")
/* script */


/* template */

/* template functional */
var __vue_template_functional__ = false
/* styles */
var __vue_styles__ = injectStyle
/* scopeId */
var __vue_scopeId__ = "data-v-205227be"
/* moduleIdentifier (server only) */
var __vue_module_identifier__ = null
var Component = normalizeComponent(
  __WEBPACK_IMPORTED_MODULE_0__babel_loader_node_modules_vue_loader_lib_selector_type_script_index_0_scanRecordIn_vue___default.a,
  __WEBPACK_IMPORTED_MODULE_1__node_modules_vue_loader_lib_template_compiler_index_id_data_v_205227be_hasScoped_true_transformToRequire_video_src_poster_source_src_img_src_image_xlink_href_buble_transforms_node_modules_vue_loader_lib_selector_type_template_index_0_scanRecordIn_vue__["a" /* default */],
  __vue_template_functional__,
  __vue_styles__,
  __vue_scopeId__,
  __vue_module_identifier__
)

/* harmony default export */ __webpack_exports__["default"] = (Component.exports);


/***/ }),

/***/ "wWSW":
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _stringify = __webpack_require__("mvHQ");

var _stringify2 = _interopRequireDefault(_stringify);

var _extends2 = __webpack_require__("Dd8w");

var _extends3 = _interopRequireDefault(_extends2);

var _vant = __webpack_require__("Fd2+");

var _vuex = __webpack_require__("SJI6");

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

exports.default = {
  name: 'remarksList',
  computed: (0, _extends3.default)({}, (0, _vuex.mapGetters)({
    remarksList: 'outOrder.remarksInfo',
    user: 'global.user',
    showEditRemarks: 'global.showEditRemarks'
  })),
  data: function data() {
    return {
      remarksInfo: {
        note: '',
        creator: '',
        createDate: ''
      },
      remarksInfos: []
    };
  },
  activated: function activated() {
    this.remarksInfos = this.remarksList;
    if (this.showEditRemarks === 2) {
      if (this.remarksInfos.length > 0) {
        this.remarksInfo = this.remarksInfos[0];
      }
      this.remarksInfos = [];
    }
  },

  methods: {
    scanDeliver: function scanDeliver() {
      this.$router.push({ name: 'scanRecord' });
    },
    addRemarks: function addRemarks() {
      if (this.remarksInfo.note === '') {
        (0, _vant.Toast)('备注不能为空');
        return;
      }
      this.remarksInfo.createDate = this.$util.common.DateUtils.dateFormat(new Date(), 'yyyy-MM-dd hh:mm:ss');
      this.remarksInfos.unshift(JSON.parse((0, _stringify2.default)(this.remarksInfo)));
      this.$store.commit('outOrder.changeRemarksInfo', this.remarksInfos);
      this.cancelRemarks();
      if (this.showEditRemarks === 2) {
        window.history.go(-1);
      }
    },
    deleteRemarks: function deleteRemarks(remarks) {
      this.$util.common.ArrayUtils.remove(this.remarksInfos, remarks);
      this.$store.commit('outOrder.changeRemarksInfo', this.remarksInfos);
    },
    cancelRemarks: function cancelRemarks() {
      this.remarksInfo.note = '';
      this.remarksInfo.creator = '';
      this.remarksInfo.createDate = '';
    }
  }
};

/***/ }),

/***/ "wkJh":
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _defineProperty2 = __webpack_require__("bOdI");

var _defineProperty3 = _interopRequireDefault(_defineProperty2);

var _getters, _mutations;

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var NS = 'pack.';

exports.default = {
  state: {
    pack: {
      chosenGood: null, // 已选商品
      chosenSize: null, // 已选包装规格
      chosenWarehouse: null, // 已选仓库
      chosenPL: null, // 已选产线
      chosenBatchNo: null, // 已选批次号
      isRealTime: true // 是否实时校验
    }
  },
  getters: (_getters = {}, (0, _defineProperty3.default)(_getters, NS + 'chosenGood', function (state) {
    return state.pack.chosenGood;
  }), (0, _defineProperty3.default)(_getters, NS + 'chosenSize', function (state) {
    return state.pack.chosenSize;
  }), (0, _defineProperty3.default)(_getters, NS + 'chosenWarehouse', function (state) {
    return state.pack.chosenWarehouse;
  }), (0, _defineProperty3.default)(_getters, NS + 'chosenPL', function (state) {
    return state.pack.chosenPL;
  }), (0, _defineProperty3.default)(_getters, NS + 'chosenBatchNo', function (state) {
    return state.pack.chosenBatchNo;
  }), (0, _defineProperty3.default)(_getters, NS + 'isRealTime', function (state) {
    return state.pack.isRealTime;
  }), _getters),
  mutations: (_mutations = {}, (0, _defineProperty3.default)(_mutations, NS + 'changeChosenGood', function (state, good) {
    state.pack.chosenGood = good;
  }), (0, _defineProperty3.default)(_mutations, NS + 'changeChosenSize', function (state, size) {
    state.pack.chosenSize = size;
  }), (0, _defineProperty3.default)(_mutations, NS + 'changeChosenWarehouse', function (state, warehouse) {
    state.pack.chosenWarehouse = warehouse;
  }), (0, _defineProperty3.default)(_mutations, NS + 'changeChosenPL', function (state, pl) {
    state.pack.chosenPL = pl;
  }), (0, _defineProperty3.default)(_mutations, NS + 'changeChosenBatchNo', function (state, batchNo) {
    state.pack.chosenBatchNo = batchNo;
  }), (0, _defineProperty3.default)(_mutations, NS + 'changeIsRealTime', function (state, flag) {
    state.pack.isRealTime = flag;
  }), _mutations)
};

/***/ }),

/***/ "ySQA":
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var _session = __webpack_require__("hDMw");

var _session2 = _interopRequireDefault(_session);

var _user = __webpack_require__("ivU6");

var _user2 = _interopRequireDefault(_user);

var _dictionary = __webpack_require__("hCOg");

var _dictionary2 = _interopRequireDefault(_dictionary);

var _local = __webpack_require__("FITS");

var _local2 = _interopRequireDefault(_local);

var _app = __webpack_require__("svz7");

var _app2 = _interopRequireDefault(_app);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

module.exports = {
  SessionUtils: _session2.default,
  UserUtils: _user2.default,
  DictionaryUtils: _dictionary2.default,
  LocalUtils: _local2.default,
  AppUtils: _app2.default
};

/***/ }),

/***/ "ya2q":
/***/ (function(module, exports, __webpack_require__) {

"use strict";


module.exports = {
  common: {
    // 下级组织列表
    directLowerOrg: {
      path: '/organization/directLowerOrg',
      method: 'GET',
      server: 'user'
    },
    // 上级组织列表
    EqualOrg: {
      path: '/organization/superOrgOrAll',
      method: 'GET',
      server: 'user'
    },
    // 当前组织列表
    currentOrg: {
      path: '/organization/currentOrg',
      method: 'GET',
      server: 'user'
    },
    // 根据id获取仓库列表
    getWarehouseList: {
      path: '/warehouse/orgWarehouse',
      method: 'GET',
      server: 'base'
    },
    directLowerOrgOrAll: {
      path: '/organization/directLowerOrgOrAll',
      method: 'GET',
      server: 'user'
    },
    // 跨级发货
    allLowerOrg: {
      path: '/organization/allLowerOrg',
      method: 'GET',
      server: 'user'
    },
    // 工厂用户查询下面所有的经销商
    factoryAndDealer: {
      path: '/organization/factoryAndDealer',
      method: 'GET',
      server: 'user'
    },
    // 查询父对象
    selectById: {
      path: '/organization/selectById/',
      method: 'GET',
      server: 'user'
    }
  }
};

/***/ })

},["r+E3"]);
//# sourceMappingURL=scanOrderIn.63c8e64e2c285801d5ba.js.map